<?php
require_once 'config.php';
require_once 'auth.php';

requireLogin();

$user = getCurrentUser();
$userId = $user['id'];

// Get plan from URL
$plan = $_GET['plan'] ?? 'monthly';

// Plan pricing in INR
$plans = [
    'monthly' => [
        'name' => 'Monthly Premium',
        'price' => 29,
        'duration' => '1 month',
        'icon' => 'calendar',
        'features' => ['No ads', 'HD quality', 'Watch history', 'Continue watching', 'Email notifications']
    ],
    'quarterly' => [
        'name' => 'Quarterly Premium',
        'price' => 69,
        'duration' => '3 months',
        'icon' => 'calendar-days',
        'features' => ['No ads', 'HD quality', 'Watch history', 'Continue watching', 'Email notifications', 'Save 23%']
    ],
    'semi_annually' => [
        'name' => 'Semi-Annual Premium',
        'price' => 99,
        'duration' => '6 months',
        'icon' => 'calendar-range',
        'features' => ['No ads', 'HD quality', 'Watch history', 'Continue watching', 'Email notifications', 'Verified badge', 'Save 43%']
    ],
    'yearly' => [
        'name' => 'Yearly Premium',
        'price' => 149,
        'duration' => '1 year',
        'icon' => 'calendar-check',
        'features' => ['No ads', 'HD quality', 'Watch history', 'Continue watching', 'Email notifications', 'Verified badge', 'Custom frame', 'Save 57%']
    ],
    'lifetime' => [
        'name' => 'Permanent Premium',
        'price' => 499,
        'duration' => 'Lifetime',
        'icon' => 'crown',
        'features' => ['No ads', 'HD quality', 'Watch history', 'Continue watching', 'Email notifications', 'Verified badge', 'Custom frame', 'Priority support', 'All future features']
    ]
];

if (!isset($plans[$plan])) {
    header('Location: membership.php');
    exit;
}

$selectedPlan = $plans[$plan];

$page_title = 'Payment - ' . $selectedPlan['name'];
require_once 'header.php';
?>

<style>
/* ========================================
   PAYMENT PAGE - COMPLETE RESPONSIVE CSS
   ======================================== */

/* Reset */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

/* Base Styles */
body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
    line-height: 1.6;
    color: #333;
    background: #f8f9fa;
}

body.dark-mode {
    background: #0a0a0a;
    color: #fff;
}


</style>

<div class="payment-container">
    <div class="payment-card">
        <div class="payment-header">
            <h1><i data-lucide="credit-card"></i> Complete Your Purchase</h1>
            <p>Secure payment processing for your premium membership</p>
        </div>
        
        <div class="plan-summary">
            <div class="plan-summary-header">
                <div class="plan-icon">
                    <i data-lucide="<?php echo $selectedPlan['icon']; ?>"></i>
                </div>
                <div>
                    <h3><?php echo $selectedPlan['name']; ?></h3>
                    <div class="plan-duration"><?php echo $selectedPlan['duration']; ?></div>
                </div>
            </div>
            
            <div class="plan-price">
                ₹<?php echo number_format($selectedPlan['price']); ?>
            </div>
            
            <ul class="plan-features">
                <?php foreach ($selectedPlan['features'] as $feature): ?>
                    <li>
                        <i data-lucide="check-circle"></i>
                        <span><?php echo $feature; ?></span>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
        
        <div class="payment-methods">
            <h3><i data-lucide="wallet"></i> Select Payment Method</h3>
            
            <div class="contact-info">
                <h4><i data-lucide="info"></i> How to Complete Payment</h4>
                <p><strong>To activate your premium membership:</strong></p>
                <ol>
                    <li>Contact us via Telegram: <a href="https://t.me/novadonghuaadmin" target="_blank"><i data-lucide="send"></i> @novadonghuaadmin</a></li>
                    <li>Mention your username: <strong><?php echo htmlspecialchars($user['username']); ?></strong></li>
                    <li>Specify the plan: <strong><?php echo $selectedPlan['name']; ?></strong></li>
                    <li>We'll provide payment instructions (UPI, PayPal, Bank Transfer, Crypto)</li>
                    <li>Your membership will be activated within 1 hours after confirmation</li>
                </ol>
            </div>
            
            <div class="payment-options">
                <div class="payment-option" onclick="selectPayment(this)">
                    <i data-lucide="send"></i>
                    <span>Telegram</span>
                </div>
                <div class="payment-option" onclick="selectPayment(this)">
                    <i data-lucide="smartphone"></i>
                    <span>UPI</span>
                </div>
                <div class="payment-option" onclick="selectPayment(this)">
                    <i data-lucide="credit-card"></i>
                    <span>Card</span>
                </div>
                <div class="payment-option" onclick="selectPayment(this)">
                    <i data-lucide="bitcoin"></i>
                    <span>Crypto</span>
                </div>
            </div>
        </div>
        
        <a href="https://t.me/novadonghuaadmin" target="_blank" class="btn-proceed">
            <i data-lucide="send"></i> Contact on Telegram
        </a>
        
        <div style="text-align: center;">
            <a href="membership.php" class="btn-back">
                <i data-lucide="arrow-left"></i> Back to Plans
            </a>
        </div>
    </div>
</div>

<script>
function selectPayment(element) {
    document.querySelectorAll('.payment-option').forEach(opt => {
        opt.classList.remove('selected');
    });
    element.classList.add('selected');
}
</script>

<?php require_once 'footer.php'; ?>