<?php
http_response_code(404);
include __DIR__ . '/header.php';
?>
<svg viewBox="0 0 400 300" xmlns="http://www.w3.org/2000/svg" style="width: 100%; height: auto; max-width: 500px;">
  <defs>
    <linearGradient id="bgGradient" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#667eea;stop-opacity:1" />
      <stop offset="100%" style="stop-color:#764ba2;stop-opacity:1" />
    </linearGradient>
    <filter id="shadow">
      <feDropShadow dx="0" dy="4" stdDeviation="8" flood-opacity="0.3"/>
    </filter>
  </defs>
  
  <!-- Background Circle -->
  <circle cx="200" cy="150" r="140" fill="url(#bgGradient)" opacity="0.1"/>
  
  <!-- Main 404 Text -->
  <text x="200" y="170" font-family="Arial, sans-serif" font-size="120" font-weight="bold" fill="url(#bgGradient)" text-anchor="middle" filter="url(#shadow)">
    404
  </text>
  
  <!-- Magnifying Glass -->
  <g transform="translate(280, 80)">
    <circle cx="0" cy="0" r="25" fill="none" stroke="#667eea" stroke-width="6"/>
    <line x1="18" y1="18" x2="35" y2="35" stroke="#667eea" stroke-width="6" stroke-linecap="round"/>
    <text x="0" y="8" font-family="Arial, sans-serif" font-size="24" fill="#667eea" text-anchor="middle">?</text>
  </g>
  
  <!-- Sad Face in the "0" -->
  <g transform="translate(200, 150)">
    <circle cx="-45" cy="-15" r="4" fill="#764ba2"/>
    <circle cx="45" cy="-15" r="4" fill="#764ba2"/>
    <path d="M -20 15 Q 0 5 20 15" stroke="#764ba2" stroke-width="3" fill="none" stroke-linecap="round"/>
  </g>
  
  <!-- Decorative Elements -->
  <circle cx="80" cy="80" r="6" fill="#667eea" opacity="0.4">
    <animate attributeName="cy" values="80;75;80" dur="2s" repeatCount="indefinite"/>
  </circle>
  <circle cx="320" cy="220" r="8" fill="#764ba2" opacity="0.4">
    <animate attributeName="cy" values="220;215;220" dur="2.5s" repeatCount="indefinite"/>
  </circle>
  <circle cx="100" cy="240" r="5" fill="#667eea" opacity="0.3">
    <animate attributeName="cy" values="240;235;240" dur="3s" repeatCount="indefinite"/>
  </circle>
  
  <!-- Page Not Found Text -->
  <text x="200" y="240" font-family="Arial, sans-serif" font-size="18" fill="#667eea" text-anchor="middle" opacity="0.8">
    Page Not Found
  </text>
  
  <a href="/" target="_self">
  <g cursor="pointer" id="homeButton">
    <rect x="140" y="260" width="120" height="35" rx="18"
          fill="url(#bgGradient)" opacity="0.9">
      <animate attributeName="opacity" values="0.9;1;0.9"
               dur="2s" repeatCount="indefinite"/>
    </rect>

    <g transform="translate(155, 270)">
      <path d="M 8 8 L 8 14 L 4 14 L 4 8 L 0 8 L 6 2 L 12 8 Z"
            fill="white"/>
      <rect x="5" y="10" width="2" height="4"
            fill="url(#bgGradient)"/>
    </g>

    <text x="200" y="283"
          font-family="Arial, sans-serif"
          font-size="16"
          font-weight="600"
          fill="white"
          text-anchor="middle">
      Go Home
    </text>
  </g>
</a>
  
  <!-- Anime Character -->
  <g transform="translate(320, 50)">
    <!-- Head -->
    <circle cx="0" cy="0" r="20" fill="#FFD4A3"/>
    
    <!-- Hair -->
    <path d="M -18 -8 Q -20 -18 -12 -22 Q -5 -24 0 -20 Q 5 -24 12 -22 Q 20 -18 18 -8" fill="#4A4A4A"/>
    <circle cx="-10" cy="-15" r="6" fill="#4A4A4A"/>
    <circle cx="10" cy="-15" r="6" fill="#4A4A4A"/>
    
    <!-- Eyes (anime style) -->
    <ellipse cx="-6" cy="-2" rx="3" ry="5" fill="#2C3E50"/>
    <ellipse cx="6" cy="-2" rx="3" ry="5" fill="#2C3E50"/>
    <circle cx="-5" cy="-3" r="1.5" fill="white"/>
    <circle cx="7" cy="-3" r="1.5" fill="white"/>
    
    <!-- Mouth (small surprised) -->
    <ellipse cx="0" cy="6" rx="3" ry="4" fill="#FF6B6B"/>
    
    <!-- Blush -->
    <ellipse cx="-12" cy="3" rx="3" ry="2" fill="#FFB6C1" opacity="0.6"/>
    <ellipse cx="12" cy="3" rx="3" ry="2" fill="#FFB6C1" opacity="0.6"/>
    
    <!-- Body -->
    <rect x="-12" y="18" width="24" height="20" rx="3" fill="#667eea"/>
    
    <!-- Arms -->
    <rect x="-18" y="20" width="6" height="15" rx="3" fill="#FFD4A3"/>
    <rect x="12" y="20" width="6" height="15" rx="3" fill="#FFD4A3"/>
    
    <!-- Waving hand animation -->
    <g transform="translate(15, 25)">
      <ellipse cx="0" cy="0" rx="4" ry="3" fill="#FFD4A3">
        <animateTransform attributeName="transform" type="rotate" values="0 0 0;20 0 0;-20 0 0;0 0 0" dur="1s" repeatCount="indefinite"/>
      </ellipse>
    </g>
    
    <!-- Speech bubble -->
    <g transform="translate(35, -10)">
      <ellipse cx="0" cy="0" rx="22" ry="12" fill="white" stroke="#667eea" stroke-width="2"/>
      <polygon points="-15,8 -18,15 -12,10" fill="white" stroke="#667eea" stroke-width="2"/>
      <text x="0" y="4" font-family="Arial, sans-serif" font-size="10" fill="#667eea" text-anchor="middle" font-weight="600">
        Oops!
      </text>
    </g>
  </g>
</svg>
<?php include __DIR__ . '/footer.php'; ?>