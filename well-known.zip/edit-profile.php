<?php
require_once 'config.php';
require_once 'auth.php';

// Require login to access profile editing
requireLogin();

$user = getCurrentUser();
$userId = $user['id'];

$success = '';
$error = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullName = sanitize($_POST['full_name'] ?? '');
    $bio = sanitize($_POST['bio'] ?? '');
    $profile_picture = $user['profile_picture']; // Keep existing by default
    
    // Handle profile picture upload
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $max_size = 5 * 1024 * 1024; // 5MB
        
        if (!in_array($_FILES['profile_picture']['type'], $allowed_types)) {
            $error = 'Invalid file type. Only JPG, PNG, GIF, and WebP are allowed.';
        } elseif ($_FILES['profile_picture']['size'] > $max_size) {
            $error = 'File too large. Maximum size is 5MB.';
        } else {
            // Create uploads directory if it doesn't exist
            $upload_dir = 'uploads/profiles/';
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }
            
            // Generate unique filename
            $file_extension = pathinfo($_FILES['profile_picture']['name'], PATHINFO_EXTENSION);
            $new_filename = 'profile_' . $userId . '_' . time() . '.' . $file_extension;
            $upload_path = $upload_dir . $new_filename;
            
            // Delete old profile picture if it exists
            if (!empty($user['profile_picture']) && file_exists($user['profile_picture'])) {
                unlink($user['profile_picture']);
            }
            
            // Move uploaded file
            if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $upload_path)) {
                $profile_picture = $upload_path;
            } else {
                $error = 'Failed to upload profile image';
            }
        }
    }
    
    // Update user profile
    if (empty($error)) {
        try {
            $stmt = $pdo->prepare("
                UPDATE users 
                SET full_name = ?, bio = ?, profile_picture = ?
                WHERE id = ?
            ");
            
            if ($stmt->execute([$fullName, $bio, $profile_picture, $userId])) {
                $success = 'Profile updated successfully!';
                // Refresh user data
                $_SESSION['user'] = null; // Clear cached user data
                $user = getCurrentUser();
            } else {
                $error = 'Failed to update profile';
            }
        } catch(PDOException $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}

$page_title = 'Edit Profile';
require_once 'header.php';
?>

<style>
.edit-profile-container {
    max-width: 800px;
    margin: 50px auto;
    padding: 20px;
}

.edit-profile-card {
    background: white;
    border-radius: 15px;
    padding: 40px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.1);
}

body.dark-mode .edit-profile-card {
    background: rgba(255,255,255,0.05);
    border: 1px solid rgba(255,255,255,0.1);
}

.edit-profile-header {
    text-align: center;
    margin-bottom: 40px;
}

.edit-profile-header h1 {
    font-size: 32px;
    margin-bottom: 10px;
    color: #333;
}

body.dark-mode .edit-profile-header h1 {
    color: #fff;
}

.edit-profile-header p {
    color: #666;
}

body.dark-mode .edit-profile-header p {
    color: #ccc;
}

.avatar-upload-section {
    text-align: center;
    margin-bottom: 40px;
}

.current-avatar {
    width: 150px;
    height: 150px;
    border-radius: 50%;
    object-fit: cover;
    border: 5px solid #667eea;
    margin-bottom: 20px;
    display: inline-block;
    box-shadow: 0 5px 20px rgba(102,126,234,0.3);
}

body.dark-mode .current-avatar {
    border-color: #00ff9d;
}

.avatar-upload-btn {
    position: relative;
    display: inline-block;
}

.avatar-upload-btn input[type="file"] {
    display: none;
}

.avatar-upload-label {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    padding: 12px 30px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border-radius: 8px;
    cursor: pointer;
    font-weight: 600;
    transition: all 0.3s;
}

.avatar-upload-label:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(102,126,234,0.3);
}

body.dark-mode .avatar-upload-label {
    background: linear-gradient(135deg, #00ff9d 0%, #0066ff 100%);
}

.file-info {
    margin-top: 10px;
    font-size: 13px;
    color: #999;
}

.form-group {
    margin-bottom: 25px;
}

.form-group label {
    display: block;
    font-weight: 600;
    margin-bottom: 10px;
    color: #333;
}

body.dark-mode .form-group label {
    color: #fff;
}

.form-group input,
.form-group textarea {
    width: 100%;
    padding: 12px 15px;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    font-size: 15px;
    transition: all 0.3s;
    box-sizing: border-box;
}

body.dark-mode .form-group input,
body.dark-mode .form-group textarea {
    background: rgba(255,255,255,0.05);
    border-color: rgba(255,255,255,0.1);
    color: #fff;
}

.form-group input:focus,
.form-group textarea:focus {
    outline: none;
    border-color: #667eea;
}

body.dark-mode .form-group input:focus,
body.dark-mode .form-group textarea:focus {
    border-color: #00ff9d;
}

.form-group textarea {
    resize: vertical;
    min-height: 100px;
}

.char-counter {
    text-align: right;
    font-size: 13px;
    color: #999;
    margin-top: 5px;
}

.form-actions {
    display: flex;
    gap: 15px;
    justify-content: center;
    margin-top: 30px;
}

.btn-submit,
.btn-cancel {
    padding: 12px 40px;
    border-radius: 8px;
    font-weight: 600;
    text-decoration: none;
    border: none;
    cursor: pointer;
    transition: all 0.3s;
    font-size: 15px;
    display: inline-flex;
    align-items: center;
    gap: 8px;
}

.btn-submit {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
}

.btn-submit:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(102,126,234,0.3);
}

body.dark-mode .btn-submit {
    background: linear-gradient(135deg, #00ff9d 0%, #0066ff 100%);
}

.btn-cancel {
    background: #f0f0f0;
    color: #666;
}

.btn-cancel:hover {
    background: #e0e0e0;
}

body.dark-mode .btn-cancel {
    background: rgba(255,255,255,0.05);
    color: #ccc;
}

body.dark-mode .btn-cancel:hover {
    background: rgba(255,255,255,0.1);
}

.alert {
    padding: 15px 20px;
    border-radius: 8px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
    animation: slideDown 0.3s ease;
}

@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.alert.success {
    background: #d4edda;
    border-left: 4px solid #28a745;
    color: #155724;
}

.alert.error {
    background: #f8d7da;
    border-left: 4px solid #dc3545;
    color: #721c24;
}

body.dark-mode .alert.success {
    background: rgba(40, 167, 69, 0.2);
    color: #00ff9d;
}

body.dark-mode .alert.error {
    background: rgba(220, 53, 69, 0.2);
    color: #ff6b6b;
}

@media (max-width: 768px) {
    .edit-profile-container {
        padding: 15px;
    }
    
    .edit-profile-card {
        padding: 25px;
    }
    
    .form-actions {
        flex-direction: column;
    }
    
    .btn-submit,
    .btn-cancel {
        width: 100%;
        justify-content: center;
    }
}
</style>

<div class="edit-profile-container">
    <div class="edit-profile-card">
        <div class="edit-profile-header">
            <h1><i class="fas fa-user-edit"></i> Edit Profile</h1>
            <p>Update your profile information</p>
        </div>
        
        <?php if ($success): ?>
            <div class="alert success">
                <i class="fas fa-check-circle"></i>
                <?php echo $success; ?>
            </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert error">
                <i class="fas fa-exclamation-circle"></i>
                <?php echo $error; ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" enctype="multipart/form-data" id="editProfileForm">
            <div class="avatar-upload-section">
                <img src="<?php echo !empty($user['profile_picture']) ? $user['profile_picture'] : 'uploads/default-avatar.png'; ?>" 
                     alt="Profile Picture" 
                     class="current-avatar"
                     id="avatarPreview">
                
                <div class="avatar-upload-btn">
                    <input type="file" 
                           id="profilePictureInput" 
                           name="profile_picture" 
                           accept="image/jpeg,image/png,image/gif,image/webp"
                           onchange="previewAvatar(this)">
                    <label for="profilePictureInput" class="avatar-upload-label">
                        <i class="fas fa-camera"></i> Change Avatar
                    </label>
                </div>
                <div class="file-info">
                    Max 5MB • JPG, PNG, GIF, WebP
                </div>
            </div>
            
            <div class="form-group">
                <label for="full_name">
                    <i class="fas fa-user"></i> Full Name
                </label>
                <input type="text" 
                       id="full_name" 
                       name="full_name" 
                       value="<?php echo htmlspecialchars($user['full_name'] ?? ''); ?>"
                       placeholder="Enter your full name"
                       maxlength="100">
            </div>
            
            <div class="form-group">
                <label for="bio">
                    <i class="fas fa-info-circle"></i> Bio
                </label>
                <textarea id="bio" 
                          name="bio" 
                          placeholder="Tell us about yourself"
                          maxlength="500"
                          oninput="updateCharCount(this)"><?php echo htmlspecialchars($user['bio'] ?? ''); ?></textarea>
                <div class="char-counter">
                    <span id="bioCharCount"><?php echo strlen($user['bio'] ?? ''); ?></span>/500
                </div>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn-submit">
                    <i class="fas fa-save"></i> Save Changes
                </button>
                <a href="profile.php" class="btn-cancel">
                    <i class="fas fa-times"></i> Cancel
                </a>
            </div>
        </form>
    </div>
</div>

<script>
function previewAvatar(input) {
    if (input.files && input.files[0]) {
        // Check file size
        if (input.files[0].size > 5 * 1024 * 1024) {
            alert('File is too large. Maximum size is 5MB.');
            input.value = '';
            return;
        }
        
        const reader = new FileReader();
        
        reader.onload = function(e) {
            document.getElementById('avatarPreview').src = e.target.result;
        };
        
        reader.readAsDataURL(input.files[0]);
    }
}

function updateCharCount(textarea) {
    const count = textarea.value.length;
    document.getElementById('bioCharCount').textContent = count;
}

// Initialize character count
document.addEventListener('DOMContentLoaded', function() {
    const bioTextarea = document.getElementById('bio');
    if (bioTextarea) {
        updateCharCount(bioTextarea);
    }
});
</script>

<?php require_once 'footer.php'; ?>