<?php
require_once 'config.php';

function displayAd($ad_type) {
    // Check if user is premium (no ads for premium users)
    if (isset($_SESSION['user_id']) && isUserPremium($_SESSION['user_id'])) {
        return ''; // No ads for premium users
    }
    
    // If no user logged in or user is not premium, show ads
    $ad_code = getSiteSetting('ad_' . $ad_type, '');
    
    if (!empty($ad_code)) {
        return $ad_code;
    }
    
    return '';
}

// Function to show ads in specific locations
function showHeaderAd() {
    return displayAd('header');
}

function showSidebarAd() {
    return displayAd('sidebar');
}

function showBeforeContentAd() {
    return displayAd('before_content');
}

function showAfterContentAd() {
    return displayAd('after_content');
}

function showBeforePlayerAd() {
    return displayAd('before_player');
}

function showAfterPlayerAd() {
    return displayAd('after_player');
}

function showPopupAd() {
    return displayAd('popup');
}
?>