<?php
require_once 'config.php';
require_once 'auth.php';
require_once 'require_auth.php';  // This checks authentication

// Require login to access profile
requireLogin();

$user = getCurrentUser();
$userId = $user['id'];

// Get user profile data from database
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$userId]);
$userProfile = $stmt->fetch();

// Get membership status using the helper functions from config.php
$membershipStatus = getUserMembershipStatus($userId);
$expiryDate = getMembershipExpiryDate($userId);

// Get continue watching (last 10 anime with progress)
$stmt = $pdo->prepare("
    SELECT w.*, a.title, a.slug as anime_slug, a.poster, e.episode_number, e.slug as episode_slug
    FROM watch_history w
    JOIN episodes e ON w.episode_id = e.id
    JOIN anime a ON e.anime_id = a.id
    WHERE w.user_id = ?
    AND w.id IN (
        SELECT MAX(w2.id)
        FROM watch_history w2
        JOIN episodes e2 ON w2.episode_id = e2.id
        WHERE w2.user_id = ?
        GROUP BY e2.anime_id
    )
    ORDER BY w.last_watched DESC
    LIMIT 10
");
$stmt->execute([$userId, $userId]);
$continueWatching = $stmt->fetchAll();

// Get watch history (last 50)
$stmt = $pdo->prepare("
    SELECT w.*, a.title, a.slug as anime_slug, a.poster, e.episode_number, e.slug as episode_slug
    FROM watch_history w
    JOIN episodes e ON w.episode_id = e.id
    JOIN anime a ON e.anime_id = a.id
    WHERE w.user_id = ?
    ORDER BY w.last_watched DESC
    LIMIT 50
");
$stmt->execute([$userId]);
$watchHistory = $stmt->fetchAll();

// Get notifications
$stmt = $pdo->prepare("
    SELECT n.*, a.title, a.slug, e.episode_number
    FROM notifications n
    JOIN anime a ON n.anime_id = a.id
    LEFT JOIN episodes e ON n.episode_id = e.id
    WHERE n.user_id = ?
    ORDER BY n.created_at DESC
    LIMIT 20
");
$stmt->execute([$userId]);
$notifications = $stmt->fetchAll();

$page_title = 'My Profile';
require_once 'header.php';
?>

<style>
/* Profile Container */
.profile-container {
    max-width: 1400px;
    margin: 0 auto;
    padding: 30px 20px;
}

/* Profile Header */
.profile-header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    padding: 40px;
    margin-bottom: 30px;
    display: flex;
    align-items: center;
    gap: 30px;
    box-shadow: 0 10px 40px rgba(102, 126, 234, 0.3);
    position: relative;
    overflow: hidden;
}

.profile-header::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
    animation: pulse-profile 4s ease-in-out infinite;
}

@keyframes pulse-profile {
    0%, 100% { transform: scale(1); opacity: 0.5; }
    50% { transform: scale(1.1); opacity: 0.3; }
}

.profile-avatar-container {
    position: relative;
    flex-shrink: 0;
    z-index: 2;
}

.profile-page-avatar {
    width: 150px;
    height: 150px;
    border-radius: 50%;
    border: 5px solid white;
    box-shadow: 0 8px 30px rgba(0,0,0,0.3);
    object-fit: cover;
}

.avatar-frame {
    position: absolute;
    top: -10px;
    left: -10px;
    right: -10px;
    bottom: -10px;
    border-radius: 50%;
    background: linear-gradient(45deg, #FFD700, #FFA500, #FFD700);
    animation: rotate-frame 3s linear infinite;
    z-index: 1;
}

@keyframes rotate-frame {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}

.verified-badge {
    position: absolute;
    bottom: 5px;
    right: 5px;
    background: #1DA1F2;
    color: white;
    width: 35px;
    height: 35px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    border: 3px solid white;
    box-shadow: 0 2px 10px rgba(0,0,0,0.3);
    z-index: 3;
}

.profile-info {
    color: white;
    flex: 1;
    z-index: 2;
}

.profile-info h1 {
    font-size: 32px;
    margin-bottom: 8px;
    display: flex;
    align-items: center;
    gap: 12px;
    flex-wrap: wrap;
}

.member-badge {
    background: rgba(255,255,255,0.2);
    padding: 5px 15px;
    border-radius: 20px;
    font-size: 14px;
    font-weight: 600;
    backdrop-filter: blur(10px);
}

.profile-meta {
    display: flex;
    gap: 25px;
    margin-top: 15px;
    flex-wrap: wrap;
}

.meta-item {
    display: flex;
    align-items: center;
    gap: 8px;
}

.profile-actions {
    display: flex;
    gap: 12px;
    margin-top: 20px;
    flex-wrap: wrap;
}

.btn-profile {
    padding: 10px 25px;
    border-radius: 8px;
    text-decoration: none;
    font-weight: 600;
    transition: all 0.3s;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    border: none;
    cursor: pointer;
}

.btn-edit {
    background: white;
    color: #667eea;
}

.btn-edit:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 20px rgba(255,255,255,0.3);
}

.btn-logout {
    background: rgba(231, 76, 60, 0.9);
    color: white;
    backdrop-filter: blur(10px);
}

.btn-logout:hover {
    background: rgba(231, 76, 60, 1);
    transform: translateY(-2px);
    box-shadow: 0 5px 20px rgba(231, 76, 60, 0.4);
}

/* Data Management Section */
.data-management {
    background: white;
    border-radius: 15px;
    padding: 30px;
    margin-bottom: 30px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.1);
}

.data-management h2 {
    font-size: 24px;
    margin-bottom: 10px;
    display: flex;
    align-items: center;
    gap: 10px;
    color: #333;
}

.data-management h2 i {
    color: #667eea;
}

.data-management p {
    color: #666;
    margin-bottom: 25px;
}

.data-actions {
    display: flex;
    gap: 15px;
    flex-wrap: wrap;
}

.btn-data {
    padding: 12px 30px;
    border-radius: 8px;
    font-weight: 600;
    transition: all 0.3s;
    display: inline-flex;
    align-items: center;
    gap: 10px;
    border: none;
    cursor: pointer;
    font-size: 15px;
}

.btn-export {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    box-shadow: 0 5px 15px rgba(102,126,234,0.3);
}

.btn-export:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(102,126,234,0.5);
}

.btn-import {
    background: #f8f9fa;
    color: #667eea;
    border: 2px solid #667eea;
}

.btn-import:hover {
    background: #667eea;
    color: white;
}

#importFileInput {
    display: none;
}

.import-info {
    background: #f0f4ff;
    border-left: 4px solid #667eea;
    padding: 15px;
    border-radius: 8px;
    margin-top: 20px;
    display: none;
}

.import-info.show {
    display: block;
}

.import-info h4 {
    margin: 0 0 10px 0;
    color: #667eea;
}

.import-info ul {
    margin: 0;
    padding-left: 20px;
    color: #666;
}

/* Profile Tabs */
.profile-tabs {
    display: flex;
    gap: 10px;
    margin-bottom: 30px;
    flex-wrap: wrap;
    background: white;
    padding: 15px;
    border-radius: 12px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
}

.tab-btn {
    padding: 12px 25px;
    background: transparent;
    border: 2px solid transparent;
    border-radius: 8px;
    cursor: pointer;
    font-weight: 600;
    transition: all 0.3s;
    display: flex;
    align-items: center;
    gap: 8px;
    color: #666;
}

.tab-btn:hover {
    background: #f8f9fa;
    color: #667eea;
    transform: translateY(-2px);
}

.tab-btn.active {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
}

.tab-btn i {
    font-size: 16px;
}

.tab-count {
    font-size: 13px;
    opacity: 0.8;
}

.notification-badge {
    background: #ff4757;
    color: white;
    padding: 3px 8px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 700;
    margin-left: 5px;
    animation: pulse-badge 2s infinite;
}

@keyframes pulse-badge {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.1); }
}

.tab-content {
    display: none;
}

.tab-content.active {
    display: block;
}

/* Anime Grid */
.profile-anime-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
    gap: 20px;
    margin-bottom: 50px;
}

.profile-anime-card {
    text-decoration: none;
    color: #333;
    position: relative;
}

.profile-anime-card-image {
    position: relative;
    padding-top: 140%;
    overflow: hidden;
    background: #f0f0f0;
    border-radius: 12px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.15);
}

.profile-anime-card-image img {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.3s;
}

.profile-anime-card:hover .profile-anime-card-image img {
    transform: scale(1.1);
}

.profile-anime-card-info {
    padding: 12px 0;
}

.profile-anime-card-title {
    font-size: 14px;
    font-weight: 700;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
    min-height: 40px;
    line-height: 1.4;
    text-align: center;
}

.profile-episode-badge {
    position: absolute;
    bottom: 0;
    right: 0;
    background: linear-gradient(135deg, #ff0000 30%, #3a0000 90%);
    color: #fff;
    padding: 0.35em 1em 0.5em 0.5em;
    border-radius: 8px 6px 0 0;
    font-size: 0.85rem;
    font-weight: 700;
    z-index: 2;
}

/* History & Notification Lists */
.history-list,
.notification-list {
    background: white;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 5px 20px rgba(0,0,0,0.1);
}

.history-item,
.notification-item {
    display: flex;
    align-items: center;
    gap: 20px;
    padding: 20px;
    border-bottom: 1px solid #f0f0f0;
    transition: background 0.3s;
}

.history-item:hover,
.notification-item:hover {
    background: #f9f9f9;
}

.history-item:last-child,
.notification-item:last-child {
    border-bottom: none;
}

.history-thumbnail {
    width: 80px;
    height: 110px;
    border-radius: 8px;
    object-fit: cover;
    flex-shrink: 0;
}

.history-info,
.notification-content {
    flex: 1;
}

.history-title,
.notification-text {
    font-weight: 600;
    color: #333;
    margin-bottom: 5px;
}

.history-episode {
    color: #667eea;
    font-size: 14px;
    margin-bottom: 5px;
}

.history-date,
.notification-time {
    color: #999;
    font-size: 13px;
}

.notification-item.unread {
    background: #f0f4ff;
}

.notification-icon {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    flex-shrink: 0;
}

.btn-continue {
    padding: 8px 20px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    text-decoration: none;
    border-radius: 6px;
    font-weight: 600;
    transition: all 0.3s;
    display: inline-flex;
    align-items: center;
    gap: 8px;
}

.btn-continue:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(102,126,234,0.3);
}

/* MAIN WRAPPER (auto light/dark mode) */
.membership-status-card {
    padding: 50px 20px;
    margin: 40px auto;

    background: var(--ms-bg);
    box-shadow: var(--ms-shadow);

    text-align: center;
    transition: .3s ease;
}

/* LIGHT + DARK MODE VARIABLES */
:root {
    --ms-bg: linear-gradient(145deg, #ffffff, #f2f2f2);
    --ms-shadow: 0 10px 40px rgba(0,0,0,0.1);

    --ms-txt-grad: linear-gradient(90deg, #ffcc00, #ff8a00, #ff3e3e);

    --ms-badge-grad: linear-gradient(90deg,#6a5af9,#8a44ff,#ff3e88);
    --ms-feature-bg: rgba(0,0,0,0.02);
}

body.dark :root {
    --ms-bg: linear-gradient(145deg, #1a1a1a, #0e0e0e);
    --ms-shadow: 0 10px 40px rgba(0,0,0,0.4);

    --ms-feature-bg: rgba(255,255,255,0.05);
}

/* HEADER */
.membership-header h2 {
    margin: 0;
    font-size: 32px;
    font-weight: 800;

    background: var(--ms-txt-grad);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

.membership-header h2 i {
    font-size: 32px;
    background: var(--ms-txt-grad);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

/* LIFETIME BADGE */
.membership-badge {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    margin: 25px auto;
    padding: 14px 40px;
    font-size: 20px;
    font-weight: 800;
    border-radius: 40px;

    background: var(--ms-badge-grad);
    color: white;
    box-shadow: 0 10px 25px rgba(255, 0, 140, 0.35);
    border: none; /* remove border */
}

/* FEATURE GRID */
.membership-features {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 18px;
    margin-top: 30px;
}

/* FEATURE ITEM (NO BORDER) */
.feature-item {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 12px;

    padding: 16px;
    border-radius: 14px;
    font-weight: 600;

    background: var(--ms-feature-bg);
    box-shadow: 0 4px 15px rgba(0,0,0,0.08);

    transition: .3s ease;
}

/* HOVER */
.feature-item:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 20px rgba(0,0,0,0.2);
}

/* ICON */
.feature-item i {
    font-size: 20px;
    background: var(--ms-badge-grad);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

/* PREMIUM BUTTON */
.btn-upgrade.premium,
.btn-upgrade{
    margin-top: 35px;
    padding: 14px 35px;
    border-radius: 12px;
    font-size: 18px;
    font-weight: 700;
    color: white;

    background: linear-gradient(135deg,#6a5af9,#8a44ff,#ff3e88,#ff6a00);

    text-decoration: none;
    transition: 0.3s ease;
}

.btn-upgrade.premium:hover {
    transform: translateY(-4px);
    box-shadow: 0 14px 40px rgba(255, 0, 100, 0.6);
}

/* Empty State */
.empty-state {
    text-align: center;
    padding: 60px 20px;
    color: #999;
}

.empty-state i {
    font-size: 64px;
    margin-bottom: 20px;
    opacity: 0.3;
}

/* Toast */
.toast {
    position: fixed;
    bottom: 30px;
    right: 30px;
    background: white;
    padding: 15px 20px;
    border-radius: 8px;
    box-shadow: 0 5px 25px rgba(0,0,0,0.2);
    display: flex;
    align-items: center;
    gap: 12px;
    z-index: 10001;
    transform: translateY(100px);
    opacity: 0;
    transition: all 0.3s;
}

.toast.show {
    transform: translateY(0);
    opacity: 1;
}

.toast.success {
    border-left: 4px solid #00cc66;
}

.toast.error {
    border-left: 4px solid #e74c3c;
}

.toast i {
    font-size: 20px;
}

.toast.success i {
    color: #00cc66;
}

.toast.error i {
    color: #e74c3c;
}

/* Dark Mode */
body.dark-mode .data-management,
body.dark-mode .profile-tabs,
body.dark-mode .history-list,
body.dark-mode .notification-list,
body.dark-mode .membership-status-card {
    background: rgba(255,255,255,0.05);
    border: 1px solid rgba(255,255,255,0.1);
}

body.dark-mode .data-management h2,
body.dark-mode .membership-header h2 {
    color: #fff;
}

body.dark-mode .btn-export {
    background: linear-gradient(135deg, #00ff9d 0%, #0066ff 100%);
}

body.dark-mode .btn-import {
    background: rgba(255,255,255,0.05);
    color: #00ff9d;
    border-color: #00ff9d;
}

body.dark-mode .btn-import:hover {
    background: #00ff9d;
    color: #000;
}

body.dark-mode .tab-btn.active {
    background: linear-gradient(135deg, #00ff9d 0%, #0066ff 100%);
    color: #000;
}

body.dark-mode .profile-anime-card-title {
    color: #fff;
}

body.dark-mode .history-title,
body.dark-mode .notification-text {
    color: #fff;
}

body.dark-mode .toast {
    background: rgba(255,255,255,0.05);
    color: #fff;
}

/* Responsive */
@media (max-width: 768px) {
    .profile-header {
        flex-direction: column;
        text-align: center;
        padding: 30px 20px;
    }
    
    .profile-info h1 {
        font-size: 24px;
        justify-content: center;
    }
    
    .profile-meta {
        justify-content: center;
    }
    
    .profile-actions {
        justify-content: center;
    }
    
    .profile-anime-grid {
        grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
        gap: 15px;
    }
    
    .data-actions {
        flex-direction: column;
    }
    
    .btn-data {
        width: 100%;
        justify-content: center;
    }
    
    .history-item {
        flex-direction: column;
        text-align: center;
    }
    
    .tab-btn {
        padding: 10px 15px;
        font-size: 14px;
    }
}

@media (max-width: 480px) {
    .profile-page-avatar {
        width: 120px;
        height: 120px;
    }
    
    .profile-info h1 {
        font-size: 20px;
    }
    
    .profile-anime-grid {
        grid-template-columns: repeat(2, 1fr);
        gap: 12px;
    }
}

.profile-container {
    padding-left: 0 !important;
    padding-right: 0 !important;
    margin-left: 0 !important;
    margin-right: 0 !important;
}

/* Lucide Icons */
.lucide {
    width: 1em;
    height: 1em;
}

/* Custom spin animation for Lucide */
@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

.spin {
    animation: spin 1s linear infinite;
}
</style>

<!-- Add React Lucide CDN -->
<script src="https://unpkg.com/lucide@latest/dist/umd/lucide.js"></script>

<div class="profile-container">
    <!-- Profile Header -->
    <div class="profile-header">
        <div class="profile-avatar-container">
            <?php if($userProfile['has_custom_frame'] ?? false): ?>
                <div class="avatar-frame"></div>
            <?php endif; ?>
            <img src="<?php echo getImageUrl($userProfile['profile_picture'], 'uploads/default-avatar.png'); ?>" 
                 alt="Profile Picture" 
                 class="profile-page-avatar">
            <?php if($userProfile['is_verified'] ?? false): ?>
                <div class="verified-badge">
                    <i data-lucide="check"></i>
                </div>
            <?php endif; ?>
        </div>
        
        <div class="profile-info">
            <h1>
                <?php echo htmlspecialchars($userProfile['full_name'] ?: $userProfile['username']); ?>
                <?php if(($userProfile['role'] ?? '') === 'admin'): ?>
                    <span class="member-badge"><i data-lucide="crown"></i> ADMIN</span>
                <?php elseif($userProfile['is_verified'] ?? false): ?>
                    <span class="member-badge"><i data-lucide="star"></i> MEMBER</span>
                <?php endif; ?>
            </h1>
            <div class="profile-meta">
                <div class="meta-item">
                    <i data-lucide="user"></i>
                    <span>@<?php echo htmlspecialchars($userProfile['username']); ?></span>
                </div>
                <div class="meta-item">
                    <i data-lucide="calendar"></i>
                    <span>Joined <?php echo date('M Y', strtotime($userProfile['created_at'])); ?></span>
                </div>
                <div class="meta-item">
                    <i data-lucide="film"></i>
                    <span><?php echo count($watchHistory); ?> Watched</span>
                </div>
            </div>
            
            <div class="profile-actions">
                <a href="/edit-profile.php" class="btn-profile btn-edit">
                    <i data-lucide="edit"></i> Edit Profile
                </a>
                <a href="/logout.php" class="btn-profile btn-logout" onclick="return confirm('Are you sure you want to logout?')">
                    <i data-lucide="log-out"></i> Logout
                </a>
            </div>
        </div>
    </div>
    
    <!-- Data Management Section -->
    <div class="data-management">
        <h2><i data-lucide="database"></i> Data Management</h2>
        <p>Export your watch history, or import data from a backup file.</p>
        
        <div class="data-actions">
            <button class="btn-data btn-export" onclick="exportData()">
                <i data-lucide="download"></i> Export My Data
            </button>
            <button class="btn-data btn-import" onclick="document.getElementById('importFileInput').click()">
                <i data-lucide="upload"></i> Import Data
            </button>
            <input type="file" id="importFileInput" accept=".json" onchange="importData(event)">
        </div>
        
        <div class="import-info" id="importInfo">
            <h4><i data-lucide="info"></i> Import Information</h4>
            <ul>
                <li><strong>Watch History:</strong> <span id="importWatchCount">0</span> entries</li>
            </ul>
        </div>
    </div>
    
    <!-- Profile Tabs -->
    <div class="profile-tabs">
        <button class="tab-btn active" onclick="switchTab(event, 'continue')">
            <i data-lucide="play-circle"></i> Continue Watching
        </button>
        <button class="tab-btn" onclick="switchTab(event, 'history')">
            <i data-lucide="history"></i> Watch History
        </button>
        <button class="tab-btn" onclick="switchTab(event, 'notifications')">
            <i data-lucide="bell"></i> Notifications
            <?php 
            $unreadCount = array_filter($notifications, function($n) { return !$n['is_read']; });
            if(count($unreadCount) > 0): 
            ?>
                <span class="notification-badge"><?php echo count($unreadCount); ?></span>
            <?php endif; ?>
        </button>
    </div>
    
    <!-- Continue Watching Tab -->
    <div id="continue-tab" class="tab-content active">
        <?php if(count($continueWatching) > 0): ?>
            <div class="profile-anime-grid">
                <?php foreach($continueWatching as $anime): ?>
                    <a href="/watch/<?php echo $anime['episode_slug']; ?>" class="profile-anime-card">
                        <div class="profile-anime-card-image">
                            <img src="<?php echo getImageUrl($anime['poster'], 'uploads/default-poster.jpg'); ?>" 
                                 alt="<?php echo htmlspecialchars($anime['title']); ?>">
                            <div class="profile-episode-badge">
                                <i data-lucide="play-circle"></i> EP <?php echo $anime['episode_number']; ?>
                            </div>
                        </div>
                        <div class="profile-anime-card-info">
                            <div class="profile-anime-card-title">
                                <?php echo htmlspecialchars($anime['title']); ?>
                            </div>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <i data-lucide="film"></i>
                <h3>No anime to continue</h3>
                <p>Start watching some anime to see them here!</p>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Watch History Tab -->
    <div id="history-tab" class="tab-content">
        <?php if(count($watchHistory) > 0): ?>
            <div class="history-list">
                <?php foreach($watchHistory as $item): ?>
                    <div class="history-item">
                        <img src="<?php echo getImageUrl($item['poster'], 'uploads/default-poster.jpg'); ?>" 
                             alt="<?php echo htmlspecialchars($item['title']); ?>" 
                             class="history-thumbnail">
                        <div class="history-info">
                            <div class="history-title"><?php echo htmlspecialchars($item['title']); ?></div>
                            <div class="history-episode">
                                <i data-lucide="play-circle"></i> Episode <?php echo $item['episode_number']; ?>
                            </div>
                            <div class="history-date">
                                <i data-lucide="clock"></i> <?php echo date('M d, Y g:i A', strtotime($item['last_watched'])); ?>
                            </div>
                        </div>
                        <div class="history-actions">
                            <a href="/watch/<?php echo $item['episode_slug']; ?>" class="btn-continue">
                                <i data-lucide="play"></i> Watch Again
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <i data-lucide="history"></i>
                <h3>No watch history</h3>
                <p>Your watch history will appear here!</p>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Notifications Tab -->
    <div id="notifications-tab" class="tab-content">
        <?php if(count($notifications) > 0): ?>
            <div class="notification-list">
                <?php foreach($notifications as $notif): ?>
                    <div class="notification-item <?php echo !$notif['is_read'] ? 'unread' : ''; ?>">
                        <div class="notification-icon">
                            <i data-lucide="bell"></i>
                        </div>
                        <div class="notification-content">
                            <div class="notification-text">
                                <strong><?php echo htmlspecialchars($notif['title']); ?></strong>
                                <?php if($notif['episode_number'] ?? false): ?>
                                    - Episode <?php echo $notif['episode_number']; ?> is now available!
                                <?php endif; ?>
                            </div>
                            <div class="notification-time">
                                <i data-lucide="clock"></i> <?php echo date('M d, Y g:i A', strtotime($notif['created_at'])); ?>
                            </div>
                        </div>
                        <?php if($notif['episode_id'] ?? false): ?>
                            <a href="/watch/<?php echo $notif['slug']; ?>" class="btn-continue">
                                <i data-lucide="play"></i> Watch Now
                            </a>
                        <?php else: ?>
                            <a href="/anime/<?php echo $notif['slug']; ?>" class="btn-continue">
                                <i data-lucide="eye"></i> View
                            </a>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <i data-lucide="bell"></i>
                <h3>No notifications</h3>
                <p>You'll be notified when followed anime get new episodes!</p>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Membership Status Section -->
    <div class="membership-status-card">
        <div class="membership-header">
            <h2><i data-lucide="crown"></i> Membership Status</h2>
        </div>
        
        <?php if ($membershipStatus === 'lifetime'): ?>
            <div class="membership-content">
                <div class="membership-badge">
                    <i data-lucide="infinity"></i> Lifetime Premium
                </div>
                <div class="membership-features">
                    <div class="feature-item">
                        <i data-lucide="square"></i>
                        <span>Ad-Free Experience</span>
                    </div>
                    <div class="feature-item">
                        <i data-lucide="check-circle"></i>
                        <span>Verified Badge</span>
                    </div>
                    <div class="feature-item">
                        <i data-lucide="image"></i>
                        <span>Custom Profile Frame</span>
                    </div>
                    <div class="feature-item">
                        <i data-lucide="headphones"></i>
                        <span>Priority Support</span>
                    </div>
                </div>
            </div>
        <?php elseif ($membershipStatus === 'active'): ?>
            <div class="membership-content">
                <div class="membership-badge">
                    <i data-lucide="star"></i> Premium Member
                </div>
                <p style="margin: 0 0 20px 0; padding: 12px 18px; background: white; border-radius: 8px; color: #333;">
                    Expires: <strong><?php echo date('F d, Y', strtotime($expiryDate)); ?></strong>
                </p>
                <div class="membership-features">
                    <div class="feature-item">
                        <i data-lucide="square"></i>
                        <span>Ad-Free Experience</span>
                    </div>
                    <div class="feature-item">
                        <i data-lucide="history"></i>
                        <span>Unlimited Watch History</span>
                    </div>
                </div>
                <a href="/membership.php" class="btn-upgrade">
                    <i data-lucide="arrow-up"></i> Upgrade to Lifetime
                </a>
            </div>
        <?php else: ?>
            <div class="membership-content">
                <div class="membership-badge">
                    <i data-lucide="user"></i> Free Member
                </div>
                <p style="margin-bottom: 18px; font-size: 15px; font-weight: 600; color: #495057;">Upgrade to Premium and enjoy:</p>
                <div class="membership-features">
                    <div class="feature-item">
                        <i data-lucide="square"></i>
                        <span>Ad-Free Streaming</span>
                    </div>
                    <div class="feature-item">
                        <i data-lucide="check-circle"></i>
                        <span>Verified Badge</span>
                    </div>
                    <div class="feature-item">
                        <i data-lucide="image"></i>
                        <span>Custom Profile Frame</span>
                    </div>
                    <div class="feature-item">
                        <i data-lucide="headphones"></i>
                        <span>Priority Support</span>
                    </div>
                    <div class="feature-item">
                        <i data-lucide="history"></i>
                        <span>Unlimited Watch History</span>
                    </div>
                </div>
                <a href="/membership.php" class="btn-upgrade premium">
                    <i data-lucide="crown"></i> Upgrade to Premium
                </a>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
// Initialize Lucide icons
lucide.createIcons();

// Tab Switching
function switchTab(event, tab) {
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
    
    event.currentTarget.classList.add('active');
    document.getElementById(tab + '-tab').classList.add('active');
}

// Export Data
async function exportData() {
    showLoading('Exporting your data...');

    try {
        const response = await fetch('api.php?action=export_data');
        const result = await response.json();

        if (result.success) {
            const dataStr = JSON.stringify(result, null, 2);
            const dataBlob = new Blob([dataStr], { type: 'application/json' });
            const url = URL.createObjectURL(dataBlob);

            const link = document.createElement('a');
            link.href = url;
            link.download = `yumestream_backup_${Date.now()}.json`;
            document.body.appendChild(link);
            link.click();
            link.remove();

            URL.revokeObjectURL(url);
            hideLoading();
            showToast('Data exported successfully!', 'success');
        } else {
            hideLoading();
            showToast('Export failed: ' + (result.message || 'Unknown error'), 'error');
        }
    } catch (error) {
        hideLoading();
        showToast('Export failed: ' + error.message, 'error');
        console.error('Export error:', error);
    }
}

// Import Data
async function importData(event) {
    const file = event.target.files[0];
    if (!file) return;

    showLoading('Importing your data...');

    try {
        const text = await file.text();
        const data = JSON.parse(text);

        if (!data || !data.data || !data.data.watch_history) {
            throw new Error('Invalid backup file format');
        }

        const watchCount = data.data.watch_history.length;
        document.getElementById('importWatchCount').textContent = watchCount;
        document.getElementById('importInfo').classList.add('show');

        const confirmed = confirm(
            `Import ${watchCount} watch history entries?\n\n` +
            `Existing data will be merged.`
        );

        if (!confirmed) {
            hideLoading();
            event.target.value = '';
            return;
        }

        const response = await fetch('api.php?action=import_data', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });

        const result = await response.json();

        if (result.success) {
            hideLoading();
            showToast(
                `Import successful! Added ${result.imported.watch_history} entries.`,
                'success'
            );

            setTimeout(() => location.reload(), 2000);
        } else {
            hideLoading();
            showToast('Import failed: ' + (result.message || 'Unknown error'), 'error');
        }
    } catch (error) {
        hideLoading();
        showToast('Import failed: ' + error.message, 'error');
        console.error('Import error:', error);
    }

    event.target.value = '';
}

// Loading Overlay
function showLoading(text = 'Processing...') {
    let overlay = document.getElementById('loadingOverlay');
    if (!overlay) {
        overlay = document.createElement('div');
        overlay.id = 'loadingOverlay';
        overlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.8);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 10000;
            opacity: 0;
            transition: opacity 0.3s;
        `;
        overlay.innerHTML = `
            <div style="background: white; padding: 30px; border-radius: 15px; text-align: center;">
                <i data-lucide="loader" class="spin" style="font-size: 48px; color: #667eea; margin-bottom: 15px;"></i>
                <div id="loadingText" style="font-size: 18px; font-weight: 600; color: #333;">${text}</div>
            </div>
        `;
        document.body.appendChild(overlay);
        // Re-initialize Lucide icons for the loading spinner
        lucide.createIcons();
    }
    
    document.getElementById('loadingText').textContent = text;
    setTimeout(() => overlay.style.opacity = '1', 10);
}

function hideLoading() {
    const overlay = document.getElementById('loadingOverlay');
    if (overlay) {
        overlay.style.opacity = '0';
        setTimeout(() => overlay.remove(), 300);
    }
}

// Toast Notification
function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `
        <i data-lucide="${type === 'success' ? 'check-circle' : 'alert-circle'}"></i>
        <span>${message}</span>
    `;

    document.body.appendChild(toast);
    // Re-initialize Lucide icons for the toast
    lucide.createIcons();
    
    setTimeout(() => toast.classList.add('show'), 100);
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
    }, 5000);
}
</script>

<?php require_once 'footer.php'; ?>