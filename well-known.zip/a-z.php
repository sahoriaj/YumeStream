<?php
require_once 'config.php';

$page_title = 'A-Z List';

// Get selected letter (default: A)
$selectedLetter = isset($_GET['letter']) ? strtoupper($_GET['letter']) : 'A';

// Validate letter
if(!preg_match('/^[A-Z0-9#]$/', $selectedLetter)) {
    $selectedLetter = 'A';
}

// Get anime by letter
if($selectedLetter === '#') {
    // Get anime starting with numbers or special characters
    $stmt = $pdo->prepare("SELECT * FROM anime WHERE title REGEXP '^[^A-Za-z]' ORDER BY title ASC");
    $stmt->execute();
} else {
    $stmt = $pdo->prepare("SELECT * FROM anime WHERE title LIKE ? ORDER BY title ASC");
    $stmt->execute([$selectedLetter . '%']);
}
$animeList = $stmt->fetchAll();

// Get all letters with anime count
$letters = range('A', 'Z');
$letters[] = '#';
$letterCounts = [];

foreach($letters as $letter) {
    if($letter === '#') {
        $count = $pdo->query("SELECT COUNT(*) FROM anime WHERE title REGEXP '^[^A-Za-z]'")->fetchColumn();
    } else {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM anime WHERE title LIKE ?");
        $stmt->execute([$letter . '%']);
        $count = $stmt->fetchColumn();
    }
    $letterCounts[$letter] = $count;
}

// Helper function to get latest episode number
function getLatestEpisodeNumber($pdo, $anime_id) {
    $stmt = $pdo->prepare("SELECT MAX(episode_number) FROM episodes WHERE anime_id = ?");
    $stmt->execute([$anime_id]);
    return $stmt->fetchColumn();
}

// Helper function to get latest episode slug
function getLatestEpisodeSlug($pdo, $anime_id) {
    $stmt = $pdo->prepare("SELECT slug FROM episodes WHERE anime_id = ? ORDER BY episode_number DESC LIMIT 1");
    $stmt->execute([$anime_id]);
    $result = $stmt->fetchColumn();
    return $result ? $result : null;
}

require_once 'header.php';
?>

<style>
    .page-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: #fff;
        padding: 40px 0;
        text-align: center;
        border-radius: 15px;
        margin-bottom: 30px;
        box-shadow: 0 10px 30px rgba(102,126,234,0.3);
    }
    
    .page-header h1 {
        font-size: 36px;
        margin-bottom: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 15px;
    }
    
    .page-header p {
        opacity: 0.9;
        font-size: 16px;
    }
    
    /* Alphabet Filter */
    .alphabet-filter {
        background: #fff;
        border-radius: 15px;
        padding: 25px;
        margin-bottom: 30px;
        box-shadow: 0 5px 20px rgba(0,0,0,0.1);
    }
    
    .filter-title {
        font-size: 18px;
        font-weight: 600;
        margin-bottom: 15px;
        display: flex;
        align-items: center;
        gap: 10px;
        color: #333;
    }
    
    .filter-title i {
        color: #667eea;
    }
    
    .letters-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(45px, 1fr));
        gap: 10px;
    }
    
    .letter-btn {
        padding: 12px;
        background: #f8f9fa;
        border: 2px solid #e0e0e0;
        border-radius: 10px;
        text-decoration: none;
        color: #333;
        text-align: center;
        font-weight: 600;
        font-size: 16px;
        transition: all 0.3s;
        position: relative;
        cursor: pointer;
    }
    
    .letter-btn:hover {
        background: #667eea;
        color: #fff;
        border-color: #667eea;
        transform: translateY(-3px);
        box-shadow: 0 5px 15px rgba(102,126,234,0.3);
    }
    
    .letter-btn.active {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: #fff;
        border-color: #667eea;
        box-shadow: 0 5px 15px rgba(102,126,234,0.4);
    }
    
    .letter-btn.disabled {
        opacity: 0.3;
        cursor: not-allowed;
        pointer-events: none;
    }
    
    .letter-count {
        position: absolute;
        top: -8px;
        right: -8px;
        background: #FF416C;
        color: #fff;
        border-radius: 50%;
        width: 20px;
        height: 20px;
        font-size: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        box-shadow: 0 2px 8px rgba(255,65,108,0.4);
    }
    
    /* Results Section */
    .results-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
        padding: 15px 20px;
        background: #fff;
        border-radius: 12px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    }
    
    .results-header h2 {
        font-size: 24px;
        display: flex;
        align-items: center;
        gap: 10px;
        color: #333;
    }
    
    .results-count {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: #fff;
        padding: 8px 20px;
        border-radius: 20px;
        font-weight: 600;
        font-size: 14px;
    }
    
    /* ============================================
   STATUS RIBBON - TEXT PERFECTLY CENTERED (SHIFTED DOWN)
   ============================================ */

/* IMPORTANT: Make sure parent .anime-card has overflow: visible */
.anime-card {
  position: relative;
  overflow: visible; /* CRITICAL */
}

.badge-container {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 6;
  pointer-events: none;
  overflow: visible;
}

.status-badge {
  position: absolute;
  top: 12px;
  left: -25px;
  
  width: 130px;
  height: 24px;
  
  /* CENTERING WITH ADJUSTMENT */
  display: flex;
  align-items: center;
  justify-content: center;
  
  font-size: 9px;
  font-weight: 800;
  letter-spacing: 1.3px;
  text-transform: uppercase;
  color: #ffffff;
  text-shadow: 0 2px 4px rgba(0, 0, 0, 0.6);
  
  background: linear-gradient(135deg, #8b5cf6, #7c3aed);
  transform: rotate(-45deg);
  transform-origin: center center;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.4);
  
  padding: 0;
  padding-top: 2px; /* ✅ TEXT KO NICHE SHIFT */
  margin: 0;
  border-radius: 0;
  
  /* FORCE PROPER LINE HEIGHT */
  line-height: 1.2;
  
  /* Ensure text doesn't wrap */
  white-space: nowrap;
  overflow: visible;
}

/* Status colors */
.status-badge.ongoing {
  background: linear-gradient(135deg, #8b5cf6, #7c3aed);
}

.status-badge.completed {
  background: linear-gradient(135deg, #ef4444, #dc2626);
}

/* ============================================
   RESPONSIVE BREAKPOINTS
   ============================================ */

/* Large Desktop (1200px+) */
@media (min-width: 1200px) {
  .status-badge {
    top: 14px;
    left: -23px;
    width: 135px;
    height: 26px;
    font-size: 9.5px;
    padding-top: 2px;
  }
}

/* Desktop (992px - 1199px) */
@media (min-width: 992px) and (max-width: 1199px) {
  .status-badge {
    top: 12px;
    left: -25px;
    width: 130px;
    height: 24px;
    font-size: 9px;
    padding-top: 2px;
  }
}

/* Tablet (768px - 991px) */
@media (min-width: 768px) and (max-width: 991px) {
  .status-badge {
    top: 11px;
    left: -27px;
    width: 120px;
    height: 22px;
    font-size: 8.5px;
    letter-spacing: 1.1px;
    padding-top: 2px;
  }
}

/* Mobile Landscape / Small Tablet (481px - 767px) */
@media (min-width: 481px) and (max-width: 767px) {
  .status-badge {
    top: 10px;
    left: -29px;
    width: 115px;
    height: 21px;
    font-size: 8px;
    letter-spacing: 1px;
    padding-top: 1.5px;
  }
}

/* Mobile Portrait (376px - 480px) */
@media (min-width: 376px) and (max-width: 480px) {
  .status-badge {
    top: 9px;
    left: -31px;
    width: 110px;
    height: 20px;
    font-size: 7.5px;
    letter-spacing: 0.9px;
    padding-top: 1.5px;
  }
}

/* Small Mobile (321px - 375px) */
@media (min-width: 321px) and (max-width: 375px) {
  .status-badge {
    top: 8px;
    left: -33px;
    width: 105px;
    height: 19px;
    font-size: 7px;
    letter-spacing: 0.8px;
    padding-top: 1px;
  }
}

/* Very Small Mobile (< 320px) */
@media (max-width: 320px) {
  .status-badge {
    top: 7px;
    left: -35px;
    width: 100px;
    height: 18px;
    font-size: 6.5px;
    letter-spacing: 0.7px;
    padding-top: 1px;
  }
}

/* ============================================
   DYNAMIC ADJUSTMENT BASED ON CARD SIZE
   ============================================ */

/* For very small cards */
.anime-card[data-size="small"] .status-badge,
.anime-grid[data-grid-size="small"] .status-badge {
  left: -35px;
  width: 100px;
  height: 18px;
  font-size: 6.5px;
  padding-top: 1px;
}

/* For medium cards */
.anime-card[data-size="medium"] .status-badge,
.anime-grid[data-grid-size="medium"] .status-badge {
  left: -28px;
  width: 115px;
  height: 21px;
  font-size: 8px;
  padding-top: 1.5px;
}

/* For large cards */
.anime-card[data-size="large"] .status-badge,
.anime-grid[data-grid-size="large"] .status-badge {
  left: -23px;
  width: 135px;
  height: 26px;
  font-size: 9.5px;
  padding-top: 2px;
}
    
    /* Dark Mode */
    body.dark-mode {
        background: #0c0c0c;
        color: #e0e0e0;
    }
    
    body.dark-mode .page-header {
        background: linear-gradient(45deg, #1a0033, #000);
        box-shadow: 0 0 30px rgba(0, 255, 157, 0.2);
    }
    
    body.dark-mode .search-filter-section,
    body.dark-mode .stats-bar,
    body.dark-mode .empty-state {
        background: linear-gradient(45deg, #1a0033, #000);
        box-shadow: 0 0 20px rgba(0, 255, 157, 0.15);
    }
    
    body.dark-mode .search-box input {
        background: rgba(255,255,255,0.05);
        border-color: rgba(255,255,255,0.1);
        color: #fff;
    }
    
    body.dark-mode .search-box input::placeholder {
        color: #888;
    }
    
    body.dark-mode .search-box button {
        background: linear-gradient(135deg, #00ff9d 0%, #0066ff 100%);
    }
    
    body.dark-mode .clear-search {
        background: #ff4444;
    }
    
    body.dark-mode .stats-info {
        color: #ccc;
    }
    
    body.dark-mode .stats-info i {
        color: #00ff9d;
    }
    
    body.dark-mode .total-count {
        background: linear-gradient(135deg, #00ff9d 0%, #0066ff 100%);
    }
    
    body.dark-mode .anime-card-title {
        color: #fff;
    }
    
    body.dark-mode .play-icon {
        background: rgba(0, 255, 157, 0.95);
        color: #000;
    }
    
    body.dark-mode .anime-card-image {
        box-shadow: 0 5px 20px rgba(0, 255, 157, 0.2);
    }
    
    body.dark-mode .pagination a,
    body.dark-mode .pagination span {
        background: rgba(255,255,255,0.05);
        color: #eee;
        box-shadow: 0 2px 8px rgba(0, 255, 157, 0.2);
    }
    
    body.dark-mode .pagination a:hover {
        background: #00ff9d;
        color: #000;
    }
    
    body.dark-mode .pagination .active {
        background: linear-gradient(135deg, #00ff9d 0%, #0066ff 100%);
    }
    
    body.dark-mode .empty-state i {
        color: #333;
    }
    
    body.dark-mode .empty-state h3 {
        color: #bbb;
    }
    
    body.dark-mode .empty-state p {
        color: #777;
    }
    
    .anime-card-title {
    font-size: 13px;
    font-weight: 600;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
    min-height: 36px;
    line-height: 1.35;
    color: #ffffff;
    text-align: center;
    margin: 0;
    padding: 0 3px;
    text-shadow: 1px 1px 3px rgba(0,0,0,0.8);
}

/* Card Info */
.anime-card-info {
    padding: 12px 6px 8px;
    background: transparent;
}
</style>

<main class="main-content">
    <div class="container">
   
        
        <!-- Alphabet Filter -->
        <div class="alphabet-filter">
            <div class="filter-title">
                <i data-lucide="filter"></i> Select a Letter
            </div>
            <div class="letters-grid">
                <?php foreach($letters as $letter): ?>
                    <a href="/az-list/<?php echo $letter; ?>" 
                       class="letter-btn <?php echo $selectedLetter === $letter ? 'active' : ''; ?> <?php echo $letterCounts[$letter] == 0 ? 'disabled' : ''; ?>">
                        <?php echo $letter; ?>
                        <?php if($letterCounts[$letter] > 0): ?>
                            <span class="letter-count"><?php echo $letterCounts[$letter]; ?></span>
                        <?php endif; ?>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
        
        <!-- Results Header -->
        <div class="results-header">
            <h2>
                <i data-lucide="arrow-right"></i>
                Anime starting with "<?php echo $selectedLetter; ?>"
            </h2>
            <span class="results-count">
                <?php echo count($animeList); ?> Result<?php echo count($animeList) != 1 ? 's' : ''; ?>
            </span>
        </div>
        
        <!-- Anime Grid -->
        <?php if(count($animeList) > 0): ?>
            <div class="anime-grid">
                <?php foreach($animeList as $anime): ?>
                    <?php 
                    $latestEpisode = getLatestEpisodeNumber($pdo, $anime['id']);
                    $latestEpisodeSlug = getLatestEpisodeSlug($pdo, $anime['id']);
                    $cardLink = $latestEpisodeSlug ? "https://yumestream.in/watch/" . $latestEpisodeSlug : "https://yumestream.in/anime/" . $anime['slug'];
                    ?>
                    <a href="<?php echo $cardLink; ?>" class="anime-card">
                        <div class="anime-card-image">
                            <img src="<?php echo getPosterUrl($anime['poster']); ?>" 
                                 alt="<?php echo htmlspecialchars($anime['title']); ?>"
                                 onerror="this.src='uploads/default.jpg'">
                            
                            <div class="play-overlay">
                                <div class="play-icon">
                                    <i data-lucide="play"></i>
                                </div>
                            </div>
                            
                            <!-- Badge Container - Top Left -->
<div class="badge-container">
    <span class="status-badge <?php echo $anime['status']; ?>">
        <?php echo ucfirst($anime['status']); ?>
    </span>
</div>
                            
                            <!-- Feature Badge - Top Right -->
                            <?php if($anime['is_hot']): ?>
                                <span class="feature-badge hot">
                                    <i data-lucide="flame"></i>
                                </span>
                            <?php elseif($anime['is_new']): ?>
                                <span class="feature-badge new">
                                    <i data-lucide="zap"></i>
                                </span>
                            <?php endif; ?>
                            
                            <!-- Episode Badge - Bottom Right -->
                            <?php if($latestEpisode): ?>
<span class="episode-badge">
    Ep <?php echo $latestEpisode; ?>
</span>

                            <?php endif; ?>
                        </div>
                        <div class="anime-card-info">
                            <div class="anime-card-title"><?php echo htmlspecialchars($anime['title']); ?></div>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <i data-lucide="inbox"></i>
                <h3>No Anime Found</h3>
                <p>There are no anime starting with "<?php echo $selectedLetter; ?>" yet.</p>
            </div>
        <?php endif; ?>
    </div>
</main>

<?php require_once 'footer.php'; ?>