<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - Yumestream</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        
        .container {
            background: white;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            width: 100%;
            max-width: 420px;
        }
        
        .logo {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .logo h1 {
            color: #667eea;
            font-size: 32px;
            margin-bottom: 5px;
        }
        
        .logo p {
            color: #666;
            font-size: 14px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 500;
            font-size: 14px;
        }
        
        input[type="email"] {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s;
        }
        
        input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 10px rgba(102,126,234,0.2);
        }
        
        .btn {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        
        .btn:hover:not(:disabled) {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }

        .btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }
        
        .alert {
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .alert-error {
            background: #fee;
            color: #c33;
            border: 1px solid #fcc;
        }
        
        .alert-success {
            background: #efe;
            color: #3c3;
            border: 1px solid #cfc;
        }
        
        .login-link {
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
            color: #666;
        }
        
        .login-link a {
            color: #667eea;
            text-decoration: none;
            font-weight: 600;
        }
        
        .login-link a:hover {
            text-decoration: underline;
        }

        .spinner {
            border: 2px solid #f3f3f3;
            border-top: 2px solid #667eea;
            border-radius: 50%;
            width: 16px;
            height: 16px;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .hidden {
            display: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">
            <h1>Yumestream</h1>
            <p>Enter your email to reset your password</p>
        </div>
        
        <div id="alertBox" class="hidden"></div>
        
        <form id="resetForm">
            <div class="form-group">
                <label>Email Address</label>
                <input type="email" id="email" required placeholder="Enter your email">
            </div>
            
            <button type="submit" class="btn" id="resetBtn">
                <span>Send Reset Link</span>
            </button>
        </form>
        
        <div class="login-link">
            Remember your password? <a href="login.php">Login here</a>
        </div>
    </div>

    <script type="module">
        import { initializeApp } from "https://www.gstatic.com/firebasejs/12.6.0/firebase-app.js";
        import { getAnalytics } from "https://www.gstatic.com/firebasejs/12.6.0/firebase-analytics.js";
        import { 
            getAuth, 
            sendPasswordResetEmail
        } from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";

        // Firebase configuration
        const firebaseConfig = {
            apiKey: "AIzaSyDgqpr976h-uGvfOCROX0V6cMaiWP1hOlc",
            authDomain: "login-signup-7cb63.firebaseapp.com",
            projectId: "login-signup-7cb63",
            storageBucket: "login-signup-7cb63.firebasestorage.app",
            messagingSenderId: "428131759010",
            appId: "1:428131759010:web:dcaed1cf0f280d885b78fb",
            measurementId: "G-8236JK3ZYL"
        };

        // Initialize Firebase
        const app = initializeApp(firebaseConfig);
        const analytics = getAnalytics(app);
        const auth = getAuth(app);

        const resetForm = document.getElementById('resetForm');
        const resetBtn = document.getElementById('resetBtn');
        const alertBox = document.getElementById('alertBox');
        const emailInput = document.getElementById('email');

        function showAlert(message, type = 'error') {
            alertBox.className = `alert alert-${type}`;
            alertBox.innerHTML = `
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    ${type === 'error' ? '<circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/>' : '<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>'}
                </svg>
                ${message}
            `;
            alertBox.classList.remove('hidden');
            
            setTimeout(() => {
                alertBox.classList.add('hidden');
            }, 8000);
        }

        function setLoading(button, isLoading) {
            if (isLoading) {
                button.disabled = true;
                const text = button.querySelector('span');
                if (text) text.textContent = 'Sending...';
                const spinner = document.createElement('div');
                spinner.className = 'spinner';
                button.insertBefore(spinner, button.firstChild);
            } else {
                button.disabled = false;
                const spinner = button.querySelector('.spinner');
                if (spinner) spinner.remove();
                const text = button.querySelector('span');
                if (text) text.textContent = 'Send Reset Link';
            }
        }

        resetForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const email = emailInput.value;
            setLoading(resetBtn, true);

            try {
                await sendPasswordResetEmail(auth, email);
                
                showAlert('Password reset link sent! Check your email.', 'success');
                emailInput.value = '';
                
                setTimeout(() => {
                    window.location.href = 'login.php';
                }, 3000);
                
            } catch (error) {
                console.error('Reset error:', error);
                let errorMessage = 'Failed to send reset email.';
                
                switch (error.code) {
                    case 'auth/user-not-found':
                        errorMessage = 'No account found with this email.';
                        break;
                    case 'auth/invalid-email':
                        errorMessage = 'Invalid email address.';
                        break;
                    case 'auth/too-many-requests':
                        errorMessage = 'Too many requests. Please try again later.';
                        break;
                }
                
                showAlert(errorMessage, 'error');
            } finally {
                setLoading(resetBtn, false);
            }
        });
    </script>
</body>
</html>