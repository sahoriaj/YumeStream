<?php
// require_auth.php - Include this at the top of protected pages
require_once 'config.php';
require_once 'auth.php';

// Check if user is logged in
if (!isLoggedIn()) {
    // Store current URL for redirect after login
    $currentUrl = $_SERVER['REQUEST_URI'];
    $redirectUrl = urlencode($currentUrl);
    header('Location: login.php?redirect=' . $redirectUrl);
    exit();
}

// Get current user info (available in all protected pages)
$currentUser = getCurrentUser();
?>