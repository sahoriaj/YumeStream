<?php
require_once 'config.php';
require_once 'auth.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$idToken = $data['idToken'] ?? '';
$displayName = $data['displayName'] ?? '';

if (empty($idToken)) {
    echo json_encode(['success' => false, 'message' => 'No token provided']);
    exit;
}

try {
    // Verify the Firebase ID token using Firebase Admin SDK or API
    // For now, we'll decode it (in production, you should verify with Firebase Admin SDK)
    $tokenParts = explode('.', $idToken);
    if (count($tokenParts) !== 3) {
        throw new Exception('Invalid token format');
    }
    
    $payload = json_decode(base64_decode(str_replace(['-', '_'], ['+', '/'], $tokenParts[1])), true);
    
    if (!$payload || !isset($payload['user_id']) || !isset($payload['email'])) {
        throw new Exception('Invalid token payload');
    }
    
    $firebaseUid = $payload['user_id'];
    $email = $payload['email'];
    $emailVerified = $payload['email_verified'] ?? false;
    
    // Check if user exists in database
    $stmt = $pdo->prepare("SELECT * FROM users WHERE firebase_uid = ? OR email = ? LIMIT 1");
    $stmt->execute([$firebaseUid, $email]);
    $user = $stmt->fetch();
    
    if ($user) {
        // Update existing user
        $stmt = $pdo->prepare("UPDATE users SET firebase_uid = ?, last_login = NOW(), email_verified = ? WHERE id = ?");
        $stmt->execute([$firebaseUid, $emailVerified ? 1 : 0, $user['id']]);
        
        $userId = $user['id'];
        $username = $user['username'];
        $fullName = $user['full_name'] ?: $displayName;
        $role = $user['role'];
    } else {
        // Create new user
        $username = explode('@', $email)[0];
        
        // Make sure username is unique
        $baseUsername = $username;
        $counter = 1;
        while (true) {
            $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
            $stmt->execute([$username]);
            if (!$stmt->fetch()) {
                break;
            }
            $username = $baseUsername . $counter;
            $counter++;
        }
        
        $fullName = $displayName ?: $username;
        
        $stmt = $pdo->prepare("INSERT INTO users (username, email, firebase_uid, full_name, role, status, email_verified, created_at) VALUES (?, ?, ?, ?, 'user', 'active', ?, NOW())");
        $stmt->execute([$username, $email, $firebaseUid, $fullName, $emailVerified ? 1 : 0]);
        
        $userId = $pdo->lastInsertId();
        $role = 'user';
    }
    
    // Set PHP session
    $_SESSION['user_id'] = $userId;
    $_SESSION['username'] = $username;
    $_SESSION['email'] = $email;
    $_SESSION['role'] = $role;
    $_SESSION['full_name'] = $fullName;
    $_SESSION['firebase_uid'] = $firebaseUid;
    $_SESSION['logged_in'] = true;
    
    echo json_encode([
        'success' => true,
        'message' => 'Authentication successful',
        'user' => [
            'id' => $userId,
            'username' => $username,
            'email' => $email,
            'role' => $role,
            'full_name' => $fullName
        ]
    ]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Authentication failed: ' . $e->getMessage()]);
}
?>