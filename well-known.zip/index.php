<?php
require_once 'config.php';

// Get hot anime
$hotAnime = $pdo->query("SELECT * FROM anime WHERE is_hot = 1 ORDER BY update_date DESC LIMIT 4")->fetchAll();

// Get recently updated anime
$recentAnime = $pdo->query("SELECT * FROM anime ORDER BY update_date DESC LIMIT 15")->fetchAll();

// Helper function to get latest episode number
function getLatestEpisodeNumber($pdo, $anime_id) {
    $stmt = $pdo->prepare("SELECT MAX(episode_number) FROM episodes WHERE anime_id = ?");
    $stmt->execute([$anime_id]);
    return $stmt->fetchColumn();
}

// Helper function to get latest episode slug
function getLatestEpisodeSlug($pdo, $anime_id) {
    $stmt = $pdo->prepare("SELECT slug FROM episodes WHERE anime_id = ? ORDER BY episode_number DESC LIMIT 1");
    $stmt->execute([$anime_id]);
    $result = $stmt->fetchColumn();
    return $result ? $result : null;
}

// NOTE: getPosterUrl() is now in config.php - DO NOT define it here again

$page_title = 'Yumestream';
require_once 'header.php';
?>
<style>
    /* ============================================
   STATUS RIBBON - TEXT PERFECTLY CENTERED (SHIFTED DOWN)
   ============================================ */

/* IMPORTANT: Make sure parent .anime-card has overflow: visible */
.anime-card {
  position: relative;
  overflow: visible; /* CRITICAL */
}

.badge-container {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 6;
  pointer-events: none;
  overflow: visible;
}

.status-badge {
  position: absolute;
  top: 12px;
  left: -25px;
  
  width: 130px;
  height: 24px;
  
  /* CENTERING WITH ADJUSTMENT */
  display: flex;
  align-items: center;
  justify-content: center;
  
  font-size: 9px;
  font-weight: 800;
  letter-spacing: 1.3px;
  text-transform: uppercase;
  color: #ffffff;
  text-shadow: 0 2px 4px rgba(0, 0, 0, 0.6);
  
  background: linear-gradient(135deg, #8b5cf6, #7c3aed);
  transform: rotate(-45deg);
  transform-origin: center center;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.4);
  
  padding: 0;
  padding-top: 2px; /* ✅ TEXT KO NICHE SHIFT */
  margin: 0;
  border-radius: 0;
  
  /* FORCE PROPER LINE HEIGHT */
  line-height: 1.2;
  
  /* Ensure text doesn't wrap */
  white-space: nowrap;
  overflow: visible;
}

/* Status colors */
.status-badge.ongoing {
  background: linear-gradient(135deg, #8b5cf6, #7c3aed);
}

.status-badge.completed {
  background: linear-gradient(135deg, #ef4444, #dc2626);
}

/* ============================================
   RESPONSIVE BREAKPOINTS
   ============================================ */

/* Large Desktop (1200px+) */
@media (min-width: 1200px) {
  .status-badge {
    top: 14px;
    left: -23px;
    width: 135px;
    height: 26px;
    font-size: 9.5px;
    padding-top: 2px;
  }
}

/* Desktop (992px - 1199px) */
@media (min-width: 992px) and (max-width: 1199px) {
  .status-badge {
    top: 12px;
    left: -25px;
    width: 130px;
    height: 24px;
    font-size: 9px;
    padding-top: 2px;
  }
}

/* Tablet (768px - 991px) */
@media (min-width: 768px) and (max-width: 991px) {
  .status-badge {
    top: 11px;
    left: -27px;
    width: 120px;
    height: 22px;
    font-size: 8.5px;
    letter-spacing: 1.1px;
    padding-top: 2px;
  }
}

/* Mobile Landscape / Small Tablet (481px - 767px) */
@media (min-width: 481px) and (max-width: 767px) {
  .status-badge {
    top: 15px;
    left: -29px;
    width: 115px;
    height: 21px;
    font-size: 8px;
    letter-spacing: 1px;
    padding-top: 1.5px;
  }
}

/* Mobile Portrait (376px - 480px) */
@media (min-width: 376px) and (max-width: 480px) {
  .status-badge {
    top: 9px;
    left: -31px;
    width: 110px;
    height: 20px;
    font-size: 7.5px;
    letter-spacing: 0.9px;
    padding-top: 1.5px;
  }
}

/* Small Mobile (321px - 375px) */
@media (min-width: 321px) and (max-width: 375px) {
  .status-badge {
    top: 8px;
    left: -33px;
    width: 105px;
    height: 19px;
    font-size: 7px;
    letter-spacing: 0.8px;
    padding-top: 1px;
  }
}

/* Very Small Mobile (< 320px) */
@media (max-width: 320px) {
  .status-badge {
    top: 7px;
    left: -35px;
    width: 100px;
    height: 18px;
    font-size: 6.5px;
    letter-spacing: 0.7px;
    padding-top: 1px;
  }
}

/* ============================================
   DYNAMIC ADJUSTMENT BASED ON CARD SIZE
   ============================================ */

/* For very small cards */
.anime-card[data-size="small"] .status-badge,
.anime-grid[data-grid-size="small"] .status-badge {
  left: -35px;
  width: 100px;
  height: 18px;
  font-size: 6.5px;
  padding-top: 1px;
}

/* For medium cards */
.anime-card[data-size="medium"] .status-badge,
.anime-grid[data-grid-size="medium"] .status-badge {
  left: -28px;
  width: 115px;
  height: 21px;
  font-size: 8px;
  padding-top: 1.5px;
}

/* For large cards */
.anime-card[data-size="large"] .status-badge,
.anime-grid[data-grid-size="large"] .status-badge {
  left: -23px;
  width: 135px;
  height: 26px;
  font-size: 9.5px;
  padding-top: 2px;
}
</style>
<main class="main-content">
    <div class="container">
        
        <?php if(count($hotAnime) > 0): ?>
        <div class="section-header">
            <h2>
                <i data-lucide="flame" style="width:20px;height:20px;margin-right:6px;"></i>
                Hot Series
            </h2>

            <a href="page.php" class="view-all">
                View All
                <i data-lucide="chevron-right" style="width:18px;height:18px;margin-left:6px;"></i>
            </a>
        </div>
        
        <div class="anime-grid">
            <?php foreach($hotAnime as $index => $anime): ?>
    <?php 
    $latestEpisode = getLatestEpisodeNumber($pdo, $anime['id']);
    $latestEpisodeSlug = getLatestEpisodeSlug($pdo, $anime['id']);
    $cardLink = $latestEpisodeSlug ? "https://yumestream.in/watch/" . $latestEpisodeSlug : "https://yumestream.in/anime/" . $anime['slug'];
    ?>
    <a href="<?php echo $cardLink; ?>" class="anime-card">
        <div class="anime-card-image">
            <img 
    src="/assets/loader.gif"
    data-src="<?php echo getPosterUrl($anime['poster']); ?>"
    alt="<?php echo htmlspecialchars($anime['title']); ?>"
    <?php if($index === 0) echo 'fetchpriority="high"'; else echo 'loading="lazy"'; ?>
    width="200"
    height="280"
    onerror="this.src='uploads/default.jpg'">

            
            <div class="play-overlay">
                <div class="play-icon">
                    <i data-lucide="play"></i>
                </div>
            </div>
            
            <div class="badge-container">
    <span class="status-badge <?php echo $anime['status']; ?>">
        <?php echo ucfirst($anime['status']); ?>
    </span>
</div>
            
       <span class="feature-badge hot">
    <i data-lucide="flame" class="fire-icon"></i>
</span>
            
            <?php if($latestEpisode): ?>
                <span class="episode-badge">
                    Ep <?php echo $latestEpisode; ?>
                </span>
            <?php endif; ?>
        </div>
        <div class="anime-card-info">
            <div class="anime-card-title"><?php echo htmlspecialchars($anime['title']); ?></div>
        </div>
    </a>
<?php endforeach; ?>
        </div>
        <?php endif; ?>
        
        <div class="section-header">
            <h2>
                <i data-lucide="clock" style="width:20px;height:20px;margin-right:6px;"></i>
                Recently Updated
            </h2>

            <a href="page.php" class="view-all">
                View All
                <i data-lucide="chevron-right" style="width:18px;height:18px;margin-left:6px;"></i>
            </a>
        </div>

        
        <div class="anime-grid">
            <?php foreach($recentAnime as $anime): ?>
                <?php 
                $latestEpisode = getLatestEpisodeNumber($pdo, $anime['id']);
                $latestEpisodeSlug = getLatestEpisodeSlug($pdo, $anime['id']);
                $cardLink = $latestEpisodeSlug ? "https://yumestream.in/watch/" . $latestEpisodeSlug : "https://yumestream.in/anime/" . $anime['slug'];
                ?>
                <a href="<?php echo $cardLink; ?>" class="anime-card">
                    <div class="anime-card-image">
                        <img 
    src="/assets/loader.gif"
    data-src="<?php echo getPosterUrl($anime['poster']); ?>"
    alt="<?php echo htmlspecialchars($anime['title']); ?>"
    loading="lazy"
    width="200"
    height="280"
    onerror="this.src='uploads/default.jpg'">

                        
                        <div class="play-overlay">
                            <div class="play-icon">
                                <i data-lucide="play"></i>
                            </div>
                        </div>
                        
      <div class="badge-container">
    <span class="status-badge <?php echo $anime['status']; ?>">
        <?php
            if ($anime['status'] === 'ongoing') {
                echo 'ONGOING';
            } elseif ($anime['status'] === 'completed') {
                echo 'COMPLETED';
            }
        ?>
    </span>
</div>
                        
               <?php if($anime['is_hot']): ?>
    <span class="feature-badge hot">
        <i data-lucide="flame" class="fire-icon"></i>
    </span>

<?php elseif($anime['is_new']): ?>
    <span class="feature-badge new">
    <i data-lucide="sparkles" class="sparkle-icon"></i>
</span>
<?php endif; ?>

                        
                        <?php if($latestEpisode): ?>
                            <span class="episode-badge">
                                Ep <?php echo $latestEpisode; ?>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="anime-card-info">
                        <div class="anime-card-title"><?php echo htmlspecialchars($anime['title']); ?></div>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
</main>
<script>
document.addEventListener("DOMContentLoaded", () => {
    const imgs = Array.from(document.querySelectorAll("img[data-src]"));
    let i = 0;

    function loadNext() {
        if (i >= imgs.length) return;

        const img = imgs[i];
        const realSrc = img.getAttribute("data-src");
        const temp = new Image();

        temp.onload = () => {
            img.src = realSrc;
            i++;
            loadNext(); // load next image only after this one finishes
        };

        temp.onerror = () => {
            img.src = "uploads/default.jpg";
            i++;
            loadNext();
        };

        temp.src = realSrc;
    }

    loadNext();
});
</script>


<?php require_once 'footer.php'; ?>