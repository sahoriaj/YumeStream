<?php
header('Content-Type: text/html; charset=UTF-8');
require_once 'config.php';
require_once 'auth.php';

$slug = $_GET['slug'] ?? '';

if(empty($slug)) {
    header('Location: index.php');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM anime WHERE slug = ?");
$stmt->execute([$slug]);
$anime = $stmt->fetch();

if(!$anime) {
    header('Location: index.php');
    exit;
}

// Fetch characters and staff
$stmt = $pdo->prepare("SELECT * FROM anime_characters WHERE anime_id = ? ORDER BY role DESC LIMIT 20");
$stmt->execute([$anime['id']]);
$characters = $stmt->fetchAll();

$stmt = $pdo->prepare("SELECT * FROM anime_staff WHERE anime_id = ? LIMIT 20");
$stmt->execute([$anime['id']]);
$staff = $stmt->fetchAll();

// Get episodes - MOVED OUTSIDE THE CONDITION
$stmt = $pdo->prepare("SELECT * FROM episodes WHERE anime_id = ? ORDER BY episode_number ASC");
$stmt->execute([$anime['id']]);
$episodes = $stmt->fetchAll();

$backgroundUrl = !empty($anime['background_image']) ? getPosterUrl($anime['background_image']) : getPosterUrl($anime['poster']);
$posterUrl = getPosterUrl($anime['poster']);

$page_title = $anime['title']; // Just anime title, no site name
require_once 'header.php';
?>

<style>
/* =====================================================
   NORMAL LUCIDE OUTLINE ICONS ONLY
   ===================================================== */

[data-lucide] {
  width: 22px;
  height: 22px;
  stroke: currentColor;
  stroke-width: 2;
  fill: none;
  vertical-align: middle;
  display: inline-block;
  transition: transform .2s ease;
}

body.dark-mode [data-lucide] {
  stroke: currentColor;
}

.icon-sm [data-lucide] { width: 16px; height: 16px; }
.icon-md [data-lucide] { width: 18px; height: 18px; }
.icon-lg [data-lucide] { width: 26px; height: 26px; }

@media (max-width: 768px) {
  [data-lucide] {
    width: 18px;
    height: 18px;
  }
}

/* =====================================================
   YOUR EXISTING PAGE CSS BELOW (UNCHANGED)
   ===================================================== */

.hero-banner { display: none; }
.poster-card { position: relative; text-align: center; overflow: visible !important; margin-bottom: 100px; }
.anime-detail-content { display: grid; grid-template-columns: 250px 1fr; gap: 30px; margin-bottom: 40px; }
.poster-image { width: 35%; border-radius: 12px; box-shadow: 0 10px 40px rgba(0,0,0,0.5); transition: transform 0.3s; position: relative; z-index: 2; display: block; margin: 0 auto; bottom: -90px; }

.poster-badge { 
    position: absolute; 
    top: 10px; 
    right: 10px; 
    background: linear-gradient(135deg, #FF416C, #FF4B2B); 
    color: #fff; 
    padding: 8px 15px; 
    border-radius: 20px; 
    font-size: 12px; 
    font-weight: 700; 
    text-transform: uppercase; 
    box-shadow: 0 4px 15px rgba(255,65,108,0.4); 
    display: flex; 
    align-items: center; 
    gap: 5px; 
    z-index: 3; 
}

.poster-card::before { 
    content: ''; 
    position: absolute; 
    top: 0; 
    left: 0; 
    width: 100%; 
    height: 100%; 
    background-image: inherit; 
    background-size: cover; 
    background-position: center; 
    background-repeat: no-repeat;
    filter: blur(40px); 
    opacity: 0.6; 
    z-index: -1; 
}

@media (min-width: 769px) {
    .poster-card {
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 300px;
        margin-bottom: 150px;
        background-size: cover !important;
        background-position: center !important;
        background-repeat: no-repeat !important;
    }
    
    .poster-card::before {
        width: 100%;
        height: 100%;
    }
    
    .poster-image {
        width: 170px;
        bottom: -90px;
        transform: translateY(50px);
    }
    
    .poster-badge {
        right: calc(100% - 125px);
    }
    
    .anime-detail-content {
        display: block;
    }
}

.anime-info { color: #fff; overflow-x: hidden; }

/* -------------------------------------------------- */
.anime-title {
    font-size: 36px;
    font-weight: 700;
    text-align: center;
    margin-top: 50px;
}
/* -------------------------------------------------- */

.anime-subtitle { font-size: 16px; color: #aaa; text-align: center; display: flex; justify-content: center; gap: 5px; }

.action-buttons { display: flex; justify-content: center; gap: 15px; margin-bottom: 30px; }

.btn-play {
  background: linear-gradient(135deg, #FF416C, #FF4B2B);
  color: #fff;
  padding: 12px 30px;
  border-radius: 8px;
  font-weight: 600;
  display: flex;
  align-items: center;
  gap: 8px;
  border: none;
}

.btn-bookmark {
  background: linear-gradient(45deg, cyan, #00251c);
  color: #fff;
  padding: 12px 25px;
  border-radius: 8px;
  display: flex;
  font-weight: 600;
  align-items: center;
  gap: 8px;
  border: none;
}

.btn-bookmark.bookmarked {
  background: linear-gradient(135deg, #667eea, #764ba2);
}

.meta-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; margin-bottom: 30px; }
.meta-item { display: flex; align-items: center; gap: 10px; }
.meta-label { color: #888; font-size: 14px; min-width: 100px; }
.meta-value { color: #fff; font-weight: 500; }
.status-badge {
    background: none;
    border: none;
    color: inherit;
    font-size: 15px;
    font-weight: 700;
    text-transform: uppercase;
}

.status-badge.completed {
    background: none;
    border: none;
    color: inherit;
}

.tags-section {
    margin-bottom: 30px;
}
.tags-list { display: flex; gap: 10px; flex-wrap: wrap; justify-content: center; }
.tag { 
    background: linear-gradient(45deg, #4100cd, #0e002d); 
    color: #fff !important; 
    padding: 6px 15px; 
    border-radius: 20px; 
    font-size: 13px; 
    border: none; 
    box-shadow: 0px 6px 15px -2px #662bff; 
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 5px;
    transition: all 0.3s ease;
    cursor: pointer;
}

.synopsis-section {
    background: #fff;
    border-radius: 14px;
    padding: 18px 20px;
    margin-bottom: 30px;
}

.synopsis-section h3 {
    margin-bottom: 12px;
}

.synopsis-section p {
    font-size: 14px;
    line-height: 1.55;
    margin-bottom: 8px;
    text-indent: 0;
}


body.dark-mode .synopsis-section {
    background: rgba(255,255,255,0.05);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255,255,255,0.1);
    color: #ccc;
    box-shadow: 0 0 15px rgba(0,255,157,0.05);
}

body.dark-mode .synopsis-section h3 {
    color: #00ff9d;
}

body.dark-mode .synopsis-section p {
    color: #ccc;
}
.episodes-section { background: rgba(255,255,255,0.05); padding: 30px; border-radius: 12px; backdrop-filter: blur(10px); }
.episodes-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; flex-wrap: wrap; gap: 15px; }
.episodes-header h3 { color: #fff; font-size: 22px; display: flex; align-items: center; gap: 10px; }
.sort-btn { background: linear-gradient(45deg, #4100cd, #0e002d); color: #fff; padding: 10px 20px; border-radius: 8px; border: none; cursor: pointer; display: flex; align-items: center; gap: 8px; font-size: 14px; transition: all 0.3s; box-shadow: 0px 6px 15px -2px #662bff; }
.episodes-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(80px, 1fr)); gap: 12px; }
.episode-btn {
  background: linear-gradient(45deg, red, #000);
  color: #fff;
  padding: 12px;
  border-radius: 8px;
  text-decoration: none;
  text-align: center;
  font-weight: 600;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  font-size: 14px;
  box-shadow: 0px 6px 15px -2px red;
}
.episode-btn:active {
  transform: scale(0.96);
  box-shadow: 0px 4px 10px -2px red;
}

.social-share {
    margin-top: 30px;
    padding-top: 20px;
    border-top: 1px solid rgba(0,0,0,0.1);
}

.social-share h4 {
    color: #222;
    font-size: 16px;
    margin-bottom: 15px;
    text-align: center;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
}

body.dark-mode .social-share {
    border-top: 1px solid rgba(255,255,255,0.1);
}

body.dark-mode .social-share h4 {
    color: #fff;
}
.social-buttons { display: flex; margin-bottom: 10px; gap: 10px; flex-wrap: wrap; justify-content: center; }
.social-btn { width: 45px; height: 45px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 18px; transition: all 0.3s; text-decoration: none; }
.social-btn.facebook { background: #1877F2; }
.social-btn.twitter { background: #1DA1F2; }
.social-btn.telegram { background: #0088cc; }
.social-btn.discord { background: #5865F2; }

.breadcrumb {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 5px;
    font-size: 15px;
    background: #fff;
    color: #333;
    padding: 12px 20px;
    border-radius: 8px;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
    margin-top: 25px;
    margin-bottom: 25px;
    transition: background 0.4s ease, color 0.4s ease, box-shadow 0.4s ease;
}

.breadcrumb a {
    color: #667eea;
    text-decoration: none;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 2px;
    transition: color 0.3s ease;
}

.breadcrumb i {
    color: #999;
    font-size: 13px;
}

.breadcrumb span {
    color: #666;
    font-weight: 500;
}

.rating-section { background: linear-gradient(135deg, #FF416C, #FF4B2B); padding: 15px; border-radius: 12px; text-align: center; box-shadow: 0 5px 20px rgba(255,65,108,0.4); display: inline-block; margin: 0 auto; }
.rating-score { font-size: 32px; font-weight: 700; color: #fff; margin-bottom: 0; line-height: 1; }
.rating-stars { font-size: 16px; color: #FFD700; margin-bottom: 5px; }
.rating-label { font-size: 12px; color: rgba(255,255,255,0.9); }
.rating-container { display: flex; justify-content: center; margin-bottom: 30px; }

body:not(.dark-mode) .anime-detail-container { background: #f5f5f5; }
body:not(.dark-mode) .anime-info, body:not(.dark-mode) .synopsis-section, body:not(.dark-mode) .episodes-section { background: #fff; color: #333; }
body:not(.dark-mode) .anime-title, body:not(.dark-mode) .episodes-header h3, body:not(.dark-mode) .synopsis-section h3 { color: #333 !important; }
body:not(.dark-mode) .meta-value, body:not(.dark-mode) .meta-label { color: #333; }
body:not(.dark-mode) .meta-label { color: #666; }
body:not(.dark-mode) .synopsis-section p { color: #555; }
body:not(.dark-mode) .anime-subtitle { color: #666; }
body:not(.dark-mode) .tag { background: linear-gradient(45deg, #4100cd, #0e002d); color: #fff; border: none; box-shadow: 0px 6px 15px -2px #662bff; }
body:not(.dark-mode) .sort-btn { background: linear-gradient(45deg, #4100cd, #0e002d); color: #fff; border: none; box-shadow: 0px 6px 15px -2px #662bff; }
body:not(.dark-mode) .btn-bookmark { background: linear-gradient(45deg, cyan, #00251c); color: #fff; box-shadow: 0px 6px 15px -2px cyan; border: none; }
body.dark-mode .breadcrumb {
    background: linear-gradient(45deg, #1a0033, #000);
    color: #eee;
    box-shadow: 0 5px 20px rgba(0, 255, 157, 0.15);
}

body.dark-mode .breadcrumb a {
    color: #00ff9d;
}

body.dark-mode .breadcrumb i {
    color: #00ff9d;
}

body.dark-mode .breadcrumb span {
    color: #ccc;
}

/* Login Modal Styles */
.login-modal {
    display: none;
    position: fixed;
    z-index: 10000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.8);
    backdrop-filter: blur(5px);
}

.login-modal-content {
    background: #fff;
    margin: 5% auto;
    padding: 40px;
    border-radius: 15px;
    width: 90%;
    max-width: 450px;
    box-shadow: 0 10px 40px rgba(0,0,0,0.3);
    animation: slideDown 0.3s ease;
}

@keyframes slideDown {
    from {
        transform: translateY(-50px);
        opacity: 0;
    }
    to {
        transform: translateY(0);
        opacity: 1;
    }
}

.login-modal-header {
    text-align: center;
    margin-bottom: 25px;
}

.login-modal-header h2 {
    color: #667eea;
    font-size: 24px;
    margin-bottom: 8px;
}

.login-modal-header p {
    color: #666;
    font-size: 14px;
}

.login-modal-close {
    position: absolute;
    right: 20px;
    top: 20px;
    font-size: 28px;
    font-weight: bold;
    color: #999;
    cursor: pointer;
    transition: all 0.3s;
}

.login-modal-buttons {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.modal-btn {
    padding: 14px;
    border-radius: 8px;
    text-decoration: none;
    text-align: center;
    font-weight: 600;
    font-size: 15px;
    transition: all 0.3s;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
}

.modal-btn-primary {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: #fff;
    box-shadow: 0 5px 20px rgba(102,126,234,0.3);
}

.modal-btn-secondary {
    background: #f8f9fa;
    color: #667eea;
    border: 2px solid #667eea;
}

body.dark-mode .login-modal-content {
    background: linear-gradient(45deg, #1a0033, #000);
    border: 1px solid rgba(0,255,157,0.2);
}

body.dark-mode .login-modal-header h2 {
    color: #00ff9d;
}

body.dark-mode .login-modal-header p {
    color: #ccc;
}

body.dark-mode .modal-btn-primary {
    background: linear-gradient(135deg, #00ff9d 0%, #0066ff 100%);
}

body.dark-mode .modal-btn-secondary {
    background: rgba(255,255,255,0.05);
    color: #00ff9d;
    border-color: #00ff9d;
}

@media (max-width: 768px) {
    .anime-detail-content { grid-template-columns: 1fr; }
    .anime-title { font-size: 24px; }
    .meta-grid { grid-template-columns: 1fr; }
    .episodes-grid { grid-template-columns: repeat(auto-fill, minmax(60px, 1fr)); }
}

/* Notification Styles */
.notification {
    position: fixed;
    top: 20px;
    right: 20px;
    background: #fff;
    padding: 15px 20px;
    border-radius: 8px;
    box-shadow: 0 5px 25px rgba(0,0,0,0.2);
    display: flex;
    align-items: center;
    gap: 12px;
    z-index: 10001;
    transform: translateX(400px);
    transition: transform 0.3s ease;
    min-width: 250px;
}

.notification.show {
    transform: translateX(0);
}

.notification-success {
    border-left: 4px solid #00cc66;
}

.notification-success i {
    color: #00cc66;
    font-size: 20px;
}

.notification-info {
    border-left: 4px solid #667eea;
}

.notification-info i {
    color: #667eea;
    font-size: 20px;
}

.notification span {
    color: #333;
    font-weight: 500;
    font-size: 14px;
}

body.dark-mode .notification {
    background: linear-gradient(45deg, #1a0033, #000);
    border: 1px solid rgba(0,255,157,0.2);
}

body.dark-mode .notification span {
    color: #fff;
}

body.dark-mode .notification-success {
    border-left-color: #00ff9d;
}

body.dark-mode .notification-success i {
    color: #00ff9d;
}

body.dark-mode .notification-info {
    border-left-color: #00c3ff;
}

body.dark-mode .notification-info i {
    color: #00c3ff;
}

@media (max-width: 768px) {
    .notification {
        right: 10px;
        left: 10px;
        min-width: auto;
    }
}
.btn-play {
    text-decoration: none !important;
    border: none !important;
}

.btn-play svg {
    display: block !important;
}

/* ================================
   CRITICAL FIX: TAB CONTENT VISIBILITY
================================ */

.tab-content {
    display: none; /* Hide all tabs by default */
}

.tab-content.active {
    display: block; /* Only show active tab */
}

/* ================================
   CAST & CREW SECTION
================================ */

.cast-crew-section {
    background: linear-gradient(135deg, rgba(102,126,234,0.12), rgba(118,75,162,0.12));
    padding: 20px;
    border-radius: 18px;
    margin-bottom: 25px;
    border: 1px solid rgba(255,255,255,0.1);
    backdrop-filter: blur(12px);
    box-shadow: 0 8px 30px rgba(0,0,0,0.2);
}

/* Tabs Container - Split Layout */
.cast-tabs {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 16px;
    padding-bottom: 12px;
    border-bottom: 1px solid rgba(255,255,255,0.1);
}

.tabs-left {
    display: flex;
    gap: 10px;
}

.tab-btn {
    background: none;
    border: none;
    color: rgba(255,255,255,0.6);
    font-size: 14px;
    font-weight: 600;
    padding: 6px 14px;
    cursor: pointer;
    position: relative;
    display: flex;
    align-items: center;
    gap: 6px;
    transition: color 0.3s ease;
}

.tab-btn.active {
    color: #fff;
}

.tab-btn.active::after {
    content: "";
    position: absolute;
    bottom: -1px;
    left: 0;
    right: 0;
    height: 2px;
    background: linear-gradient(135deg,#ff416c,#ff4b2b);
    border-radius: 2px;
}

.tab-count {
    font-size: 11px;
    padding: 2px 6px;
    border-radius: 10px;
    background: rgba(255,255,255,0.12);
}

.tab-btn.active .tab-count {
    background: linear-gradient(135deg,#ff416c,#ff4b2b);
}

/* Slider Controls */
.slider-controls {
    display: flex;
    gap: 8px;
}

.slider-btn {
    width: 38px;
    height: 38px;
    border-radius: 12px;
    border: none;
    cursor: pointer;
    background: linear-gradient(135deg,#667eea,#764ba2);
    color: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 4px 15px rgba(102,126,234,0.4);
    transition: opacity 0.3s ease;
}

.slider-btn:disabled {
    opacity: 0.35;
    cursor: not-allowed;
}

/* Slider Container */
.slider-container {
    overflow: hidden;
    padding: 4px 0;
}

.slider-track {
    display: flex;
    gap: 18px;
    overflow-x: auto;
    overflow-y: hidden;
    scroll-behavior: smooth;
    padding: 4px 4px;
}

.slider-track::-webkit-scrollbar {
    height: 6px;
}

.slider-track::-webkit-scrollbar-thumb {
    border-radius: 6px;
    background: linear-gradient(135deg,#667eea,#764ba2);
}

/* Person Card */
.person-card {
    min-width: 130px;
    max-width: 130px;
    text-align: center;
    flex-shrink: 0;
    transition: transform 0.25s ease;
}

/* Badge */
.person-badge {
    position: absolute;
    bottom: 2px;
    left: 50%;
    transform: translateX(-50%);
    font-size: 10px;
    padding: 4px 10px;
    border-radius: 14px;
    background: linear-gradient(135deg,#ff416c,#ff4b2b);
    color: #fff;
    font-weight: 700;
    white-space: nowrap;
    z-index: 10;
}

/* Image Wrapper */
.person-image-wrapper {
    width: 95px;
    height: 95px;
    margin: 0 auto 10px;
    border-radius: 50%;
    padding: 4px;
    overflow: visible;
    background: linear-gradient(135deg,#ff416c,#ff4b2b);
    box-shadow: 0 8px 25px rgba(255,65,108,0.45);
    position: relative;
}

.person-card.staff .person-image-wrapper {
    width: 85px;
    height: 85px;
    background: linear-gradient(135deg,#667eea,#764ba2);
}

.person-image-wrapper img {
    width: 100%;
    height: 100%;
    border-radius: 50%;
    object-fit: cover;
}

.person-card.staff .person-badge {
    background: linear-gradient(135deg,#667eea,#764ba2);
}

/* Person Info */
.person-info {
    padding: 0 4px;
    min-height: 60px;
}

.person-name {
    font-size: 14px;
    font-weight: 700;
    color: #fff;
    margin-bottom: 6px;
    line-height: 1.3;
    word-wrap: break-word;
    overflow-wrap: break-word;
}

.person-role {
    font-size: 12px;
    color: #00ff9d;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 4px;
    flex-wrap: wrap;
    line-height: 1.4;
    word-wrap: break-word;
    overflow-wrap: break-word;
}

.person-card.staff .person-role {
    color: #00c3ff;
}

/* Empty State */
.empty-state {
    text-align: center;
    padding: 40px 20px;
    color: rgba(255,255,255,0.6);
}

.empty-state i {
    font-size: 48px;
    margin-bottom: 15px;
    opacity: 0.5;
}

.empty-state h4 {
    color: #fff;
    font-size: 18px;
    margin-bottom: 8px;
}

.empty-state p {
    font-size: 14px;
}

/* Light Mode */
body:not(.dark-mode) .cast-crew-section {
    background: rgba(102,126,234,0.08);
    border-color: rgba(102,126,234,0.2);
}

body:not(.dark-mode) .section-header h3,
body:not(.dark-mode) .person-name {
    color: #333;
}

body:not(.dark-mode) .tab-btn {
    color: rgba(0,0,0,0.6);
}

body:not(.dark-mode) .tab-btn.active {
    color: #333;
}

body:not(.dark-mode) .person-role {
    color: #667eea;
}

body:not(.dark-mode) .empty-state {
    color: rgba(0,0,0,0.6);
}

body:not(.dark-mode) .empty-state h4 {
    color: #333;
}

/* Mobile Responsive */
@media (max-width: 768px) {
    .cast-crew-section {
        padding: 16px;
    }

    .cast-tabs {
        flex-direction: column;
        align-items: stretch;
        gap: 10px;
    }

    .tabs-left {
        justify-content: center;
        width: 100%;
    }

    .slider-controls {
        justify-content: center;
        width: 100%;
    }

    .person-card {
        min-width: 120px;
        max-width: 120px;
    }

    .person-image-wrapper {
        width: 85px;
        height: 85px;
    }

    .person-card.staff .person-image-wrapper {
        width: 75px;
        height: 75px;
    }

    .person-name {
        font-size: 13px;
    }

    .person-role {
        font-size: 11px;
    }
}
</style>

<!-- LOGIN MODAL -->
<div id="loginModal" class="login-modal">
    <div class="login-modal-content">
        <span class="login-modal-close" onclick="closeLoginModal()">&times;</span>
        <div class="login-modal-header">
            <h2><i data-lucide="lock"></i> Login Required</h2>
            <p>Please login to use this feature</p>
        </div>

        <div class="login-modal-buttons">
            <a href="/login.php" class="modal-btn modal-btn-primary">
                <i data-lucide="log-in"></i>
                Login to Continue
            </a>

            <a href="/signup.php" class="modal-btn modal-btn-secondary">
                <i data-lucide="user-plus"></i>
                Create New Account
            </a>
        </div>
    </div>
</div>

<div class="hero-banner" style="background-image:url('<?php echo $posterUrl ?>')"></div>

<main class="anime-detail-container">
<div class="container">

    <div class="breadcrumb">
        <a href="/"><i data-lucide="home"></i> Home</a>
        <i data-lucide="chevron-right"></i>
        <span><?php echo htmlspecialchars($anime['title']); ?></span>
    </div>

    <div class="poster-card" style="background-image:url('<?php echo $backgroundUrl ?>')">
        <img src="<?php echo $posterUrl ?>" class="poster-image">

        <?php if($anime['is_hot']): ?>
        <div class="poster-badge">
            <i data-lucide="flame"></i> POPULAR
        </div>
        <?php endif ?>
    </div>

    <h1 class="anime-title"><?php echo htmlspecialchars($anime['title']); ?></h1>

    <?php if(!empty($anime['zh_name'])): ?>
    <div class="anime-subtitle">
        <i data-lucide="languages"></i>
        <?php echo htmlspecialchars($anime['zh_name']); ?>
    </div>
    <?php endif; ?>

    <div class="action-buttons">
        <?php if(count($episodes) > 0): ?>
        <a href="/watch/<?php echo $episodes[0]['slug'] ?>" class="btn-play">
            <i data-lucide="play-circle"></i> Play Now
        </a>
        <?php endif; ?>

        <button class="btn-bookmark" id="bookmarkBtn" onclick="toggleBookmark()">
            <i data-lucide="bookmark-plus"></i>
            <span id="bookmarkText">Bookmark</span>
        </button>
    </div>

    <!-- Rating -->
    <?php if(!empty($anime['rating'])): ?>
    <div class="rating-container">
        <div class="rating-section">
            <div class="rating-stars">
                <?php
                $rating = floatval($anime['rating']) / 2;
                $full = floor($rating);
                $half = ($rating - $full) >= 0.5;

                for($i=0; $i < $full; $i++) echo '<i data-lucide="star"></i>';
                if($half) echo '<i data-lucide="star-half"></i>';
                for($i=$full+($half?1:0); $i < 5; $i++) echo '<i data-lucide="star"></i>';
                ?>
            </div>
            <div class="rating-label">Rating <?php echo $anime['rating']; ?></div>
        </div>
    </div>
    <?php endif; ?>

    <!-- META -->
    <div class="meta-grid">

        <div class="meta-item">
            <span class="meta-label"><i data-lucide="tv"></i> Network:</span>
            <span class="meta-value"><?php echo $anime['network']; ?></span>
        </div>

        <div class="meta-item">
            <span class="meta-label"><i data-lucide="film"></i> Episodes:</span>
            <span class="meta-value">
    <?php 
        // Get last 2 episodes
        $latestEpisodes = array_slice(array_reverse($episodes), 0, 2);

        // Extract episode numbers
        $episodeNumbers = array_map(fn($ep) => $ep['episode_number'], $latestEpisodes);

        // Show them in ascending order
        echo implode(', ', array_reverse($episodeNumbers));
    ?>
</span>

        </div>

        <div class="meta-item">
            <span class="meta-label"><i data-lucide="info"></i> Status:</span>
            <span class="meta-value"><?php echo ucfirst($anime['status']); ?></span>
        </div>

        <?php if($anime['released_date']): ?>
        <div class="meta-item">
            <span class="meta-label"><i data-lucide="calendar-days"></i> Released:</span>
            <span class="meta-value"><?php echo date("M d, Y", strtotime($anime['released_date'])); ?></span>
        </div>
        <?php endif; ?>

        <?php if($anime['duration']): ?>
        <div class="meta-item">
            <span class="meta-label"><i data-lucide="clock"></i> Duration:</span>
            <span class="meta-value"><?php echo $anime['duration']; ?></span>
        </div>
        <?php endif; ?>

        <?php if($anime['country']): ?>
        <div class="meta-item">
            <span class="meta-label"><i data-lucide="globe-2"></i> Country:</span>
            <span class="meta-value"><?php echo $anime['country']; ?></span>
        </div>
        <?php endif; ?>

        <?php if($anime['type']): ?>
        <div class="meta-item">
            <span class="meta-label"><i data-lucide="ticket"></i> Type:</span>
            <span class="meta-value"><?php echo $anime['type']; ?></span>
        </div>
        <?php endif; ?>

        <?php if($anime['studio']): ?>
        <div class="meta-item">
            <span class="meta-label"><i data-lucide="building"></i> Studio:</span>
            <span class="meta-value"><?php echo $anime['studio']; ?></span>
        </div>
        <?php endif; ?>

    </div>

 <!-- GENRES -->
    <div class="tags-list">
        <?php foreach(explode(",", $anime['genres']) as $g): 
            $genreSlug = trim($g);
        ?>
            <a href="/genre.php?slug=<?php echo urlencode($genreSlug); ?>" class="tag">
                <i data-lucide="tag"></i> <?php echo htmlspecialchars($genreSlug); ?>
            </a>
        <?php endforeach ?>
    </div>

    <!-- ================================
         CAST & CREW SECTION
    ================================ -->
    <?php if(count($characters) > 0 || count($staff) > 0): ?>
    <div class="cast-crew-section">
        <div class="cast-tabs">
            <div class="tabs-left">
                <button class="tab-btn active" onclick="switchTab('characters')">
                    <i data-lucide="user"></i>
                    <span>Characters</span>
                    <span class="tab-count"><?php echo count($characters); ?></span>
                </button>
                <button class="tab-btn" onclick="switchTab('staff')">
                    <i data-lucide="briefcase"></i>
                    <span>Staff</span>
                    <span class="tab-count"><?php echo count($staff); ?></span>
                </button>
            </div>
            
            <div class="slider-controls">
                <button class="slider-btn" onclick="scrollCurrentSlider(-1)">
                    <i data-lucide="chevron-left"></i>
                </button>
                <button class="slider-btn" onclick="scrollCurrentSlider(1)">
                    <i data-lucide="chevron-right"></i>
                </button>
            </div>
        </div>
        
        <!-- Characters Tab -->
        <div id="charactersTab" class="tab-content active">
            <?php if(count($characters) > 0): ?>
            <div class="slider-container">
                <div class="slider-track" id="charactersSlider">
                    <?php foreach($characters as $char): ?>
                    <div class="person-card character">
                        <div class="person-image-wrapper">
                            <img src="<?php echo htmlspecialchars($char['image_url']); ?>" 
                                 alt="<?php echo htmlspecialchars($char['name']); ?>"
                                 onerror="this.src='<?php echo SITE_URL; ?>/uploads/default.jpg'">
                            <span class="person-badge"><?php echo htmlspecialchars($char['role']); ?></span>
                        </div>
                        <div class="person-info">
                            <div class="person-name"><?php echo htmlspecialchars($char['name']); ?></div>
                            <?php if(!empty($char['voice_actor'])): ?>
                            <div class="person-role">
                                <i data-lucide="mic"></i>
                                <span><?php echo htmlspecialchars($char['voice_actor']); ?></span>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php else: ?>
            <div class="empty-state">
                <i data-lucide="user-x"></i>
                <h4>No Characters Available</h4>
                <p>Character information will be added soon</p>
            </div>
            <?php endif; ?>
        </div>
        
        <!-- Staff Tab -->
        <div id="staffTab" class="tab-content">
            <?php if(count($staff) > 0): ?>
            <div class="slider-container">
                <div class="slider-track" id="staffSlider">
                    <?php foreach($staff as $staff_member): ?>
                    <div class="person-card staff">
                        <div class="person-image-wrapper">
                            <img src="<?php echo htmlspecialchars($staff_member['image_url']); ?>" 
                                 alt="<?php echo htmlspecialchars($staff_member['name']); ?>"
                                 onerror="this.src='<?php echo SITE_URL; ?>/uploads/default.jpg'">
                            <span class="person-badge">Staff</span>
                        </div>
                        <div class="person-info">
                            <div class="person-name"><?php echo htmlspecialchars($staff_member['name']); ?></div>
                            <div class="person-role">
                                <span><?php echo htmlspecialchars($staff_member['role']); ?></span>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php else: ?>
            <div class="empty-state">
                <i data-lucide="briefcase-x"></i>
                <h4>No Staff Information Available</h4>
                <p>Staff information will be added soon</p>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
    <!-- END CAST & CREW SECTION -->

    <!-- Synopsis -->
    <?php if($anime['synopsis']): ?>
    <div class="synopsis-section">
        <h3><i data-lucide="align-left"></i> Synopsis</h3>
        <p><?php echo nl2br(htmlspecialchars($anime['synopsis'])) ?></p>
    </div>
    <?php endif; ?>

    <!-- Episodes -->
    <?php if(count($episodes)): ?>
    <div class="episodes-section">
        <div class="episodes-header">
            <h3><i data-lucide="list"></i> Episodes</h3>

            <button class="sort-btn" onclick="toggleOrder()">
    <i data-lucide="arrow-up-down"></i>
    <span id="orderText">Reverse Order</span>
</button>

        </div>

        <div class="episodes-grid" id="episodesGrid">
            <?php foreach($episodes as $ep): ?>
            <a href="/watch/<?php echo $ep['slug'] ?>" class="episode-btn">
                <i data-lucide="play"></i>
                <?php echo $ep['episode_number'] ?>
            </a>
            <?php endforeach ?>
        </div>
    </div>
    <?php endif; ?>

</div>
</main>
<script>
// ===============================
// ANIME DATA
// ===============================
const animeData = {
    id: <?php echo $anime['id']; ?>,
    title: <?php echo json_encode($anime['title']); ?>,
    slug: <?php echo json_encode($anime['slug']); ?>,
    poster: <?php echo json_encode(getPosterUrl($anime['poster'])); ?>
};

let isUserLoggedIn = <?php echo isLoggedIn() ? 'true' : 'false'; ?>;

// ===============================
// BOOKMARK STORAGE FUNCTIONS
// ===============================
function getBookmarks() {
    const bookmarks = localStorage.getItem('animeBookmarks');
    return bookmarks ? JSON.parse(bookmarks) : [];
}

function isBookmarked() {
    return getBookmarks().some(b => b.id == animeData.id);
}

// ===============================
// UPDATE BOOKMARK BUTTON
// ===============================
function updateBookmarkButton() {
    const btn = document.getElementById('bookmarkBtn');
    const text = document.getElementById('bookmarkText');
    const icon = btn.querySelector('i');

    if (!isUserLoggedIn) {
        btn.classList.remove('bookmarked');
        text.textContent = "Bookmark";
        icon.setAttribute("data-lucide", "bookmark-plus");
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
        return;
    }

    if (isBookmarked()) {
        btn.classList.add('bookmarked');
        text.textContent = "Bookmarked";
        icon.setAttribute("data-lucide", "bookmark-check");
    } else {
        btn.classList.remove('bookmarked');
        text.textContent = "Bookmark";
        icon.setAttribute("data-lucide", "bookmark-plus");
    }

    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
}

// ===============================
// TOGGLE BOOKMARK (ADD/REMOVE)
// ===============================
function toggleBookmark() {
    if (!isUserLoggedIn) {
        showLoginModal();
        return;
    }

    let bookmarks = getBookmarks();

    if (isBookmarked()) {
        // Remove
        bookmarks = bookmarks.filter(b => b.id != animeData.id);
        localStorage.setItem('animeBookmarks', JSON.stringify(bookmarks));
        updateBookmarkButton();
        showNotification("Removed from bookmarks", "info");
    } else {
        // Add
        bookmarks.push({
            id: animeData.id,
            title: animeData.title,
            slug: animeData.slug,
            poster: animeData.poster,
            bookmarkedAt: new Date().toLocaleDateString()
        });

        localStorage.setItem('animeBookmarks', JSON.stringify(bookmarks));
        updateBookmarkButton();
        showNotification("Added to bookmarks", "success");
    }
    
    // Dispatch event for other pages to listen
    window.dispatchEvent(new Event('bookmarksChanged'));
}

// ===============================
// NOTIFICATION POPUP
// ===============================
function showNotification(message, type) {
    const box = document.createElement('div');
    box.className = `notification notification-${type}`;

    const iconName =
        type === "success" ? "check-circle" :
        type === "error"   ? "alert-circle" : "info";

    box.innerHTML = `
        <i data-lucide="${iconName}"></i>
        <span>${message}</span>
    `;

    document.body.appendChild(box);
    
    // Initialize Lucide icons for the notification
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
    
    setTimeout(() => box.classList.add('show'), 50);

    setTimeout(() => {
        box.classList.remove('show');
        setTimeout(() => box.remove(), 300);
    }, 2500);
}

// ===============================
// CHECK LOGIN STATUS
// ===============================
async function checkLoginStatus() {
    try {
        const response = await fetch('/check_login.php');
        const data = await response.json();
        isUserLoggedIn = data.logged_in;
        updateBookmarkButton();
    } catch (error) {
        console.error("Login check error:", error);
        // If check fails, assume logged out
        isUserLoggedIn = false;
        updateBookmarkButton();
    }
}

// ===============================
// LOGIN MODAL
// ===============================
function showLoginModal() {
    document.getElementById('loginModal').style.display = 'block';
    document.body.style.overflow = 'hidden';
    
    // Reinitialize icons in modal
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
}

function closeLoginModal() {
    document.getElementById('loginModal').style.display = 'none';
    document.body.style.overflow = 'auto';
}

window.onclick = function(e) {
    const modal = document.getElementById('loginModal');
    if (e.target === modal) closeLoginModal();
};

// ===============================
// EPISODE ORDER TOGGLE
// ===============================
function toggleOrder() {
    const grid = document.getElementById("episodesGrid");
    if (!grid) return;

    const items = Array.from(grid.querySelectorAll(".episode-btn"));
    if (items.length === 0) return;

    const reversed = items.reverse();
    grid.innerHTML = "";
    reversed.forEach(item => grid.appendChild(item));

    const t = document.getElementById("orderText");
    t.textContent = t.textContent === "Reverse Order" ? "Normal Order" : "Reverse Order";

    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
}

// ===============================
// TAB SWITCHING FOR CAST & CREW
// ===============================
let currentActiveSlider = 'charactersSlider';

function switchTab(tabName) {
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });

    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
    });

    const selectedTab = document.getElementById(tabName + 'Tab');
    if (selectedTab) {
        selectedTab.classList.add('active');
    }

    if (event && event.target) {
        event.target.closest('.tab-btn').classList.add('active');
    }

    if (tabName === 'characters') {
        currentActiveSlider = 'charactersSlider';
    } else if (tabName === 'staff') {
        currentActiveSlider = 'staffSlider';
    }

    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
}

// ===============================
// SLIDER SCROLL
// ===============================
function scrollCurrentSlider(direction) {
    const slider = document.getElementById(currentActiveSlider);
    
    if (!slider) {
        console.error('Slider not found:', currentActiveSlider);
        return;
    }
    
    const cards = slider.querySelectorAll('.person-card');
    if (cards.length === 0) return;
    
    const cardWidth = cards[0].offsetWidth;
    const gap = 18;
    const cardsToScroll = 3;
    const scrollAmount = (cardWidth + gap) * cardsToScroll;
    
    slider.scrollBy({
        left: direction * scrollAmount,
        behavior: 'smooth'
    });
}

// ===============================
// INITIALIZE ON PAGE LOAD
// ===============================
document.addEventListener("DOMContentLoaded", function() {
    // Initialize Lucide icons first
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
    
    // Initialize login status and update bookmark button
    updateBookmarkButton();
    
    // Check login status from server
    checkLoginStatus();
    
    // Ensure Characters tab is active by default
    const charactersTab = document.getElementById('charactersTab');
    if (charactersTab) {
        charactersTab.classList.add('active');
    }
    
    const staffTab = document.getElementById('staffTab');
    if (staffTab) {
        staffTab.classList.remove('active');
    }
    
    const firstTabBtn = document.querySelector('.tab-btn');
    if (firstTabBtn) {
        firstTabBtn.classList.add('active');
    }
});
</script>
<?php require_once 'footer.php'; ?>
