<?php
require_once '../config.php';

if(!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$success = '';
$error = '';

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = sanitize($_POST['title']);
    $zh_name = sanitize($_POST['zh_name']);
    $synopsis = sanitize($_POST['synopsis']);
    $type = sanitize($_POST['type']);
    $status = $_POST['status'];
    $network = sanitize($_POST['network']);
    $duration = sanitize($_POST['duration']);
    $studio = sanitize($_POST['studio']);
    $country = sanitize($_POST['country']);
    $rating = floatval($_POST['rating']);
    $genres = sanitize($_POST['genres']);
    $released_date = $_POST['released_date'];
    $is_hot = isset($_POST['is_hot']) ? 1 : 0;
    $is_new = isset($_POST['is_new']) ? 1 : 0;
    $slug = createSlug($title);
    
    // Handle poster - either file upload or URL
    $poster = '';
    $poster_url = sanitize($_POST['poster_url'] ?? '');
    
    if(isset($_FILES['poster']) && $_FILES['poster']['error'] === UPLOAD_ERR_OK) {
        $poster = uploadImage($_FILES['poster']);
        if(!$poster) {
            $error = 'Failed to upload poster image';
        }
    } elseif(!empty($poster_url)) {
        if(filter_var($poster_url, FILTER_VALIDATE_URL)) {
            $poster = $poster_url;
        } else {
            $error = 'Invalid poster URL';
        }
    } else {
        $error = 'Please upload a poster image or provide a poster URL';
    }
    
    // Handle background image - either file upload or URL
    $background_image = '';
    $background_url = sanitize($_POST['background_url'] ?? '');
    
    if(isset($_FILES['background_image']) && $_FILES['background_image']['error'] === UPLOAD_ERR_OK) {
        $background_image = uploadImage($_FILES['background_image']);
        if(!$background_image) {
            $error = 'Failed to upload background image';
        }
    } elseif(!empty($background_url)) {
        if(filter_var($background_url, FILTER_VALIDATE_URL)) {
            $background_image = $background_url;
        } else {
            $error = 'Invalid background URL';
        }
    }
    // Note: background_image can be empty, poster will be used as fallback
    
    if(!$error) {
        try {
            $stmt = $pdo->prepare("INSERT INTO anime (title, zh_name, slug, synopsis, poster, background_image, status, type, network, duration, studio, country, rating, genres, released_date, is_hot, is_new, update_date) 
                                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
            $stmt->execute([$title, $zh_name, $slug, $synopsis, $poster, $background_image, $status, $type, $network, $duration, $studio, $country, $rating, $genres, $released_date, $is_hot, $is_new]);
            $success = 'Anime added successfully!';
            $_POST = array();
        } catch(PDOException $e) {
            $error = 'Error: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Anime - Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f7fa;
        }
        
        .admin-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .admin-header-content {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .admin-logo {
            color: #fff;
            font-size: 24px;
            font-weight: bold;
        }
        
        .back-btn {
            color: #fff;
            text-decoration: none;
            background: rgba(255,255,255,0.2);
            padding: 10px 20px;
            border-radius: 8px;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .back-btn:hover {
            background: rgba(255,255,255,0.3);
        }
        
        .container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 0 20px;
        }
        
        .form-card {
            background: #fff;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            margin-bottom: 20px;
        }
        
        .form-card h2 {
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
            color: #333;
            padding-bottom: 15px;
            border-bottom: 2px solid #f0f0f0;
        }
        
        .form-card h2 i {
            color: #667eea;
        }
        
        .alert {
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .alert.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .form-group label i {
            color: #667eea;
        }
        
        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 15px;
            font-family: inherit;
            transition: all 0.3s;
        }
        
        .form-group textarea {
            min-height: 150px;
            resize: vertical;
        }
        
        .form-group input:focus,
        .form-group textarea:focus,
        .form-group select:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 10px rgba(102,126,234,0.2);
        }
        
        .form-row {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
        }
        
        .form-row-3 {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
        }
        
        .checkbox-group {
            display: flex;
            gap: 30px;
            margin-top: 10px;
        }
        
        .checkbox-label {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
        }
        
        .checkbox-label input {
            width: auto;
            cursor: pointer;
        }
        
        .btn {
            padding: 15px 35px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #fff;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(102,126,234,0.4);
        }
        
        .help-text {
            font-size: 13px;
            color: #666;
            margin-top: 5px;
        }
        
        .upload-badge {
            display: inline-block;
            background: linear-gradient(135deg, #00c6ff 0%, #0072ff 100%);
            color: #fff;
            padding: 5px 12px;
            border-radius: 15px;
            font-size: 12px;
            font-weight: 600;
            margin-left: 10px;
        }
        
        .image-type-badge {
            display: inline-block;
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: #fff;
            padding: 5px 12px;
            border-radius: 15px;
            font-size: 12px;
            font-weight: 600;
            margin-left: 10px;
        }
        
        @media (max-width: 768px) {
            .form-row, .form-row-3 {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <header class="admin-header">
        <div class="admin-header-content">
            <div class="admin-logo">
                <i class="fas fa-plus-circle"></i> Add New Anime
            </div>
            <a href="index.php" class="back-btn">
                <i class="fas fa-arrow-left"></i> Back to Dashboard
            </a>
        </div>
    </header>
    
    <div class="container">
        <?php if($success): ?>
            <div class="alert success">
                <i class="fas fa-check-circle"></i> <?php echo $success; ?>
            </div>
        <?php endif; ?>
        
        <?php if($error): ?>
            <div class="alert error">
                <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" enctype="multipart/form-data">
            <!-- Basic Information -->
            <div class="form-card">
                <h2><i class="fas fa-info-circle"></i> Basic Information</h2>
                
                <div class="form-group">
                    <label><i class="fas fa-heading"></i> Title *</label>
                    <input type="text" name="title" required value="<?php echo $_POST['title'] ?? ''; ?>">
                </div>
                
                <div class="form-group">
                    <label><i class="fas fa-language"></i> Chinese Name</label>
                    <input type="text" name="zh_name" value="<?php echo $_POST['zh_name'] ?? ''; ?>">
                </div>
                
                <div class="form-group">
                    <label><i class="fas fa-align-left"></i> Synopsis</label>
                    <textarea name="synopsis"><?php echo $_POST['synopsis'] ?? ''; ?></textarea>
                </div>
            </div>
            
            <!-- Media Details -->
            <div class="form-card">
                <h2><i class="fas fa-film"></i> Media Details</h2>
                
                <div class="form-row">
                    <div class="form-group">
                        <label><i class="fas fa-tag"></i> Type</label>
                        <input type="text" name="type" placeholder="e.g. TV Series, Movie, OVA" value="<?php echo $_POST['type'] ?? ''; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-info-circle"></i> Status *</label>
                        <select name="status" required>
                            <option value="ongoing">Ongoing</option>
                            <option value="completed">Completed</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-row-3">
                    <div class="form-group">
                        <label><i class="fas fa-tv"></i> Network</label>
                        <input type="text" name="network" placeholder="e.g. Tencent Video, Youku" value="<?php echo $_POST['network'] ?? ''; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-clock"></i> Duration</label>
                        <input type="text" name="duration" placeholder="e.g. 20 min per ep" value="<?php echo $_POST['duration'] ?? ''; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-user"></i> Studio</label>
                        <input type="text" name="studio" placeholder="e.g. Motion Magic" value="<?php echo $_POST['studio'] ?? ''; ?>">
                    </div>
                </div>
                
                <div class="form-row-3">
                    <div class="form-group">
                        <label><i class="fas fa-globe"></i> Country</label>
                        <input type="text" name="country" placeholder="e.g. China, Japan, South Korea" value="<?php echo $_POST['country'] ?? ''; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-star"></i> Rating</label>
                        <input type="number" name="rating" step="0.1" min="0" max="10" placeholder="9.2" value="<?php echo $_POST['rating'] ?? ''; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-calendar"></i> Released Date</label>
                        <input type="date" name="released_date" value="<?php echo $_POST['released_date'] ?? ''; ?>">
                    </div>
                </div>
                
                <div class="form-group">
                    <label><i class="fas fa-tags"></i> Genres</label>
                    <input type="text" name="genres" placeholder="Action, Adventure, Fantasy, Martial Art, Romance" value="<?php echo $_POST['genres'] ?? ''; ?>">
                    <div class="help-text">Separate multiple genres with commas</div>
                </div>
            </div>
            
            <!-- Poster Upload -->
            <div class="form-card">
                <h2>
                    <i class="fas fa-image"></i> Poster Image *
                    <span class="upload-badge"><i class="fas fa-upload"></i> Local Upload</span>
                    <span class="image-type-badge">Vertical/Portrait</span>
                </h2>
                
                <div class="form-group">
                    <label><i class="fas fa-upload"></i> Upload Poster Image</label>
                    <input type="file" name="poster" accept="image/*">
                    <div class="help-text">
                        <i class="fas fa-info-circle"></i> Recommended: Vertical poster (e.g., 300x450px). Will be uploaded to: <strong><?php echo SITE_URL; ?>/uploads/</strong>
                    </div>
                </div>
                
                <div class="form-group">
                    <label><i class="fas fa-link"></i> Or use Poster URL</label>
                    <input type="url" name="poster_url" placeholder="https://example.com/poster.jpg">
                    <div class="help-text">Enter a direct image URL if you don't want to upload a file</div>
                </div>
                
                <div class="help-text" style="margin-top: 10px; padding: 10px; background: #fff3cd; border-radius: 8px; color: #856404;">
                    <i class="fas fa-exclamation-triangle"></i> <strong>Required:</strong> Either upload a file OR provide a URL for the poster image.
                </div>
            </div>
            
            <!-- Background Image Upload -->
            <div class="form-card">
                <h2>
                    <i class="fas fa-panorama"></i> Background Image
                    <span class="upload-badge"><i class="fas fa-upload"></i> Local Upload</span>
                    <span class="image-type-badge">Horizontal/Landscape</span>
                </h2>
                
                <div class="form-group">
                    <label><i class="fas fa-upload"></i> Upload Background Image (Optional)</label>
                    <input type="file" name="background_image" accept="image/*">
                    <div class="help-text">
                        <i class="fas fa-info-circle"></i> Recommended: Wide background banner (e.g., 1920x1080px). Will be uploaded to: <strong><?php echo SITE_URL; ?>/uploads/</strong>
                        <br><strong>Note:</strong> If no background is uploaded, the poster image will be used as background.
                    </div>
                </div>
                
                <div class="form-group">
                    <label><i class="fas fa-link"></i> Or use Background URL</label>
                    <input type="url" name="background_url" placeholder="https://example.com/background.jpg">
                    <div class="help-text">Enter a direct image URL for the background</div>
                </div>
            </div>
            
            <!-- Tags -->
            <div class="form-card">
                <h2><i class="fas fa-bookmark"></i> Tags & Features</h2>
                
                <div class="form-group">
                    <div class="checkbox-group">
                        <label class="checkbox-label">
                            <input type="checkbox" name="is_hot">
                            <span><i class="fas fa-fire"></i> Hot/Popular Series</span>
                        </label>
                        <label class="checkbox-label">
                            <input type="checkbox" name="is_new">
                            <span><i class="fas fa-bolt"></i> New Release</span>
                        </label>
                    </div>
                </div>
            </div>
            
            <button type="submit" class="btn">
                <i class="fas fa-save"></i> Add Anime
            </button>
        </form>
    </div>
</body>
</html>