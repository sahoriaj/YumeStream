<?php
require_once '../config.php';

if(!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

// Handle delete episode
if(isset($_POST['delete_episode'])) {
    $episode_id = isset($_POST['episode_id']) ? (int)$_POST['episode_id'] : 0;
    
    if($episode_id > 0) {
        try {
            // Delete associated servers and download links first
            $pdo->prepare("DELETE FROM servers WHERE episode_id = ?")->execute([$episode_id]);
            $pdo->prepare("DELETE FROM download_links WHERE episode_id = ?")->execute([$episode_id]);
            
            // Delete the episode
            $pdo->prepare("DELETE FROM episodes WHERE id = ?")->execute([$episode_id]);
            
            $_SESSION['success'] = 'Episode deleted successfully!';
        } catch(PDOException $e) {
            $_SESSION['error'] = 'Error deleting episode: ' . $e->getMessage();
        }
    }
    
    // Redirect back to episodes list
    $redirect = 'episodes-list.php';
    if(isset($_POST['anime_id']) && $_POST['anime_id'] > 0) {
        $redirect .= '?anime_id=' . (int)$_POST['anime_id'];
    }
    header('Location: ' . $redirect);
    exit;
}

// Get anime_id from URL if provided
$anime_id = isset($_GET['anime_id']) ? (int)$_GET['anime_id'] : 0;

// Search functionality
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$perPage = 50;
$offset = ($page - 1) * $perPage;

// Build query based on filters
$whereClause = '';
$params = [];
$animeDetails = null;

if($anime_id > 0) {
    $whereClause = "WHERE e.anime_id = ?";
    $params[] = $anime_id;
    
    // Get anime details
    $stmt = $pdo->prepare("SELECT * FROM anime WHERE id = ?");
    $stmt->execute([$anime_id]);
    $animeDetails = $stmt->fetch();
    
    if(!$animeDetails) {
        $_SESSION['error'] = 'Anime not found';
        header('Location: anime-list.php');
        exit;
    }
}

// Add search to where clause
if(!empty($search)) {
    if($whereClause) {
        $whereClause .= " AND (e.episode_number LIKE ? OR e.title LIKE ? OR a.title LIKE ?)";
    } else {
        $whereClause = "WHERE (e.episode_number LIKE ? OR e.title LIKE ? OR a.title LIKE ?)";
    }
    $searchParam = "%$search%";
    $params[] = $searchParam;
    $params[] = $searchParam;
    $params[] = $searchParam;
}

// Get total count
$countSql = "SELECT COUNT(*) FROM episodes e JOIN anime a ON e.anime_id = a.id $whereClause";
$countStmt = $pdo->prepare($countSql);
$countStmt->execute($params);
$totalEpisodes = $countStmt->fetchColumn();
$totalPages = ceil($totalEpisodes / $perPage);

// Get episodes list with anime info
$sql = "SELECT e.*, a.title as anime_title, a.slug as anime_slug, a.poster as anime_poster,
        (SELECT COUNT(*) FROM servers WHERE episode_id = e.id) as server_count,
        (SELECT COUNT(*) FROM download_links WHERE episode_id = e.id) as download_count
        FROM episodes e 
        JOIN anime a ON e.anime_id = a.id 
        $whereClause
        ORDER BY e.anime_id DESC, e.episode_number ASC 
        LIMIT ? OFFSET ?";

$stmt = $pdo->prepare($sql);
$stmt->execute(array_merge($params, [$perPage, $offset]));
$episodes = $stmt->fetchAll();

$success = $_SESSION['success'] ?? '';
$error = $_SESSION['error'] ?? '';
unset($_SESSION['success'], $_SESSION['error']);

$page_title = 'Manage Episodes - Admin';
require_once 'header.php';
?>

<style>
    .page-header-section {
        background: #fff;
        padding: 25px;
        border-radius: 15px;
        margin-bottom: 30px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.08);
    }
    
    .page-header-section h1 {
        font-size: 28px;
        color: #333;
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 10px;
    }
    
    .page-header-section h1 i {
        color: #667eea;
    }
    
    .anime-info-box {
        display: flex;
        align-items: center;
        gap: 20px;
        padding: 20px;
        background: #f8f9fa;
        border-radius: 12px;
        margin-top: 15px;
    }
    
    .anime-info-box img {
        width: 80px;
        height: 110px;
        object-fit: cover;
        border-radius: 8px;
        box-shadow: 0 3px 10px rgba(0,0,0,0.2);
    }
    
    .anime-info-text h2 {
        font-size: 22px;
        margin-bottom: 8px;
        color: #333;
    }
    
    .anime-info-text p {
        color: #666;
        font-size: 14px;
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 5px;
    }
    
    .search-bar {
        background: #fff;
        padding: 20px;
        border-radius: 15px;
        margin-bottom: 20px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.08);
    }
    
    .search-form {
        display: flex;
        gap: 10px;
        align-items: stretch;
    }
    
    .search-form input {
        flex: 1;
        padding: 12px 20px;
        border: 2px solid #e0e0e0;
        border-radius: 10px;
        font-size: 15px;
        transition: all 0.3s;
    }
    
    .search-form input:focus {
        outline: none;
        border-color: #667eea;
        box-shadow: 0 0 10px rgba(102,126,234,0.2);
    }
    
    .search-form button,
    .search-form a {
        padding: 12px 30px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: #fff;
        border: none;
        border-radius: 10px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s;
        display: flex;
        align-items: center;
        gap: 8px;
        text-decoration: none;
        white-space: nowrap;
    }
    
    .search-form button:hover,
    .search-form a:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(102,126,234,0.4);
    }
    
    .search-form .clear-btn {
        background: #f44336;
    }
    
    .search-form .clear-btn:hover {
        box-shadow: 0 5px 15px rgba(244,67,54,0.4);
    }
    
    .episodes-table {
        background: #fff;
        border-radius: 15px;
        overflow: hidden;
        box-shadow: 0 5px 15px rgba(0,0,0,0.08);
    }
    
    table {
        width: 100%;
        border-collapse: collapse;
    }
    
    thead {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: #fff;
    }
    
    th {
        padding: 15px;
        text-align: left;
        font-weight: 600;
    }
    
    tbody tr {
        border-bottom: 1px solid #f0f0f0;
        transition: all 0.3s;
    }
    
    tbody tr:hover {
        background: #f8f9fa;
    }
    
    td {
        padding: 15px;
    }
    
    .episode-number {
        font-size: 18px;
        font-weight: bold;
        color: #667eea;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    
    .anime-name {
        font-size: 13px;
        color: #999;
        margin-top: 5px;
    }
    
    .episode-title {
        color: #333;
        font-weight: 500;
    }
    
    .episode-title.untitled {
        color: #999;
        font-style: italic;
    }
    
    .badge {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        padding: 5px 12px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
        margin-right: 5px;
        margin-bottom: 5px;
    }
    
    .badge.servers {
        background: #e3f2fd;
        color: #1976d2;
    }
    
    .badge.downloads {
        background: #fff3e0;
        color: #f57c00;
    }
    
    .badge.combined {
        background: #f3e5f5;
        color: #7b1fa2;
    }
    
    .action-btns {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
    }
    
    .action-btn {
        width: 35px;
        height: 35px;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.3s;
        text-decoration: none;
        color: #fff;
        font-size: 14px;
    }
    
    .action-btn.view {
        background: #2196f3;
    }
    
    .action-btn.edit {
        background: #ff9800;
    }
    
    .action-btn.delete {
        background: #f44336;
    }
    
    .action-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 10px rgba(0,0,0,0.2);
    }
    
    .pagination {
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 10px;
        margin-top: 30px;
        flex-wrap: wrap;
    }
    
    .pagination a,
    .pagination span {
        padding: 10px 15px;
        background: #fff;
        border-radius: 8px;
        text-decoration: none;
        color: #333;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        transition: all 0.3s;
        display: flex;
        align-items: center;
        gap: 5px;
    }
    
    .pagination a:hover {
        background: #667eea;
        color: #fff;
        transform: translateY(-2px);
    }
    
    .pagination .active {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: #fff;
        font-weight: 600;
    }
    
    .pagination .disabled {
        opacity: 0.5;
        cursor: not-allowed;
    }
    
    .empty-state {
        text-align: center;
        padding: 80px 20px;
    }
    
    .empty-state i {
        font-size: 80px;
        color: #667eea;
        margin-bottom: 25px;
        opacity: 0.5;
    }
    
    .empty-state h3 {
        font-size: 28px;
        color: #333;
        margin-bottom: 15px;
        font-weight: 600;
    }
    
    .empty-state p {
        color: #666;
        margin-bottom: 30px;
        font-size: 16px;
        line-height: 1.6;
    }
    
    .add-btn {
        background: linear-gradient(135deg, #4ECDC4 0%, #44A08D 100%);
        color: #fff;
        text-decoration: none;
        padding: 15px 30px;
        border-radius: 10px;
        display: inline-flex;
        align-items: center;
        gap: 10px;
        font-weight: 600;
        font-size: 16px;
        transition: all 0.3s;
    }
    
    .add-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 25px rgba(78,205,196,0.4);
    }
    
    /* ===== Make episode cards compact ===== */
@media (max-width: 1024px) {

  .episode-card {
    padding: 12px 14px;
    margin-bottom: 10px;
    border-radius: 10px;
  }

  .episode-card-header {
    margin-bottom: 8px;
  }

  .episode-card-number {
    font-size: 18px;
    gap: 6px;
  }

  .episode-card-title {
    font-size: 14px;
    margin-bottom: 8px;
    line-height: 1.4;
  }

  .episode-card-meta {
    gap: 6px;
    padding-bottom: 8px;
    margin-bottom: 10px;
  }

  .badge {
    padding: 4px 8px;
    font-size: 11px;
    border-radius: 14px;
  }

  /* ===== Action buttons smaller ===== */
  .episode-card-actions {
    grid-template-columns: repeat(3, 1fr);
    gap: 6px;
  }

  .episode-card .action-btn {
    height: 36px;
    font-size: 14px;
    border-radius: 6px;
  }

  .episode-card .action-btn i {
    width: 18px;
    height: 18px;
  }
}

/* ===== Extra small phones ===== */
@media (max-width: 576px) {
  .episode-card-actions {
    grid-template-columns: repeat(3, 1fr);
  }

  .episode-card-number {
    font-size: 16px;
  }

  .episode-card-title {
    font-size: 13px;
  }
}
    
    @media (min-width: 1025px) {
        .episodes-table .mobile-cards {
            display: none;
        }
    }
    
    @media (max-width: 576px) {
        .page-header-section h1 {
            font-size: 20px;
        }
        
        .anime-info-box img {
            width: 100px;
            height: 140px;
        }
        
        .episode-card-actions {
            grid-template-columns: 1fr;
        }
    }
</style>

<div class="admin-container">
    <?php if($animeDetails): ?>
    <div class="page-header-section">
        <h1>
            <i data-lucide="film"></i> 
            Episodes for: <?php echo htmlspecialchars($animeDetails['title']); ?>
        </h1>
        <div class="anime-info-box">
            <?php 
            $posterPath = getImageUrl($animeDetails['poster']);
            ?>
            <img src="<?php echo htmlspecialchars($posterPath); ?>" 
                 alt="<?php echo htmlspecialchars($animeDetails['title']); ?>"
                 onerror="this.src='<?php echo SITE_URL; ?>/uploads/default.jpg'">
            <div class="anime-info-text">
                <h2><?php echo htmlspecialchars($animeDetails['title']); ?></h2>
                <?php if(!empty($animeDetails['zh_name'])): ?>
                    <p><i data-lucide="languages"></i> <?php echo htmlspecialchars($animeDetails['zh_name']); ?></p>
                <?php endif; ?>
                <p>
                    <i data-lucide="info"></i> 
                    <?php echo ucfirst($animeDetails['status']); ?>
                    <?php if(!empty($animeDetails['type'])): ?>
                        | <?php echo htmlspecialchars($animeDetails['type']); ?>
                    <?php endif; ?>
                </p>
                <p><i data-lucide="play-circle"></i> Total Episodes: <strong><?php echo $totalEpisodes; ?></strong></p>
            </div>
        </div>
    </div>
    <?php else: ?>
    <div class="page-header-section">
        <h1>
            <i data-lucide="film"></i> 
            All Episodes (<?php echo $totalEpisodes; ?>)
        </h1>
    </div>
    <?php endif; ?>
    
    <?php if($totalEpisodes > 0 || $search): ?>
    <div class="search-bar">
        <form method="GET" class="search-form">
            <?php if($anime_id): ?>
            <input type="hidden" name="anime_id" value="<?php echo $anime_id; ?>">
            <?php endif; ?>
            <input type="text" 
                   name="search" 
                   placeholder="Search by episode number or title..." 
                   value="<?php echo htmlspecialchars($search); ?>">
            <button type="submit">
                <i data-lucide="search"></i> Search
            </button>
            <?php if($search): ?>
            <a href="?<?php echo $anime_id ? 'anime_id='.$anime_id : ''; ?>" class="clear-btn">
                <i data-lucide="x"></i> Clear
            </a>
            <?php endif; ?>
        </form>
    </div>
    <?php endif; ?>
    
    <?php if($success): ?>
        <div class="alert success">
            <i data-lucide="check-circle"></i> <?php echo htmlspecialchars($success); ?>
        </div>
    <?php endif; ?>
    
    <?php if($error): ?>
        <div class="alert error">
            <i data-lucide="alert-circle"></i> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>
    
    <?php if(count($episodes) > 0): ?>
    <div class="episodes-table">
        <!-- Desktop Table View -->
        <table>
            <thead>
                <tr>
                    <th>Episode</th>
                    <th>Title</th>
                    <th>Info</th>
                    <th>Created</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($episodes as $episode): ?>
                <?php
                $isCombined = !empty($episode['episode_letter']) && strpos($episode['episode_letter'], '-') === 0;
                $episodeDisplay = 'Episode ' . $episode['episode_number'];
                if($isCombined) {
                    $episodeDisplay .= $episode['episode_letter'];
                }
                ?>
                <tr>
                    <td>
                        <div class="episode-number">
                            <i data-lucide="play"></i>
                            <?php echo htmlspecialchars($episode['episode_number'] . ($episode['episode_letter'] ?? '')); ?>
                        </div>
                        <?php if(!$anime_id): ?>
                        <div class="anime-name">
                            <?php echo htmlspecialchars($episode['anime_title']); ?>
                        </div>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="episode-title <?php echo empty($episode['title']) ? 'untitled' : ''; ?>">
                            <?php echo !empty($episode['title']) ? htmlspecialchars($episode['title']) : 'Untitled Episode'; ?>
                        </div>
                    </td>
                    <td>
                        <span class="badge servers">
                            <i data-lucide="server"></i>
                            <?php echo $episode['server_count']; ?>
                        </span>
                        <?php if($episode['download_count'] > 0): ?>
                        <span class="badge downloads">
                            <i data-lucide="download"></i>
                            <?php echo $episode['download_count']; ?>
                        </span>
                        <?php endif; ?>
                        <?php if($isCombined): ?>
                        <span class="badge combined">
                            <i data-lucide="layers"></i>
                            Combined
                        </span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php echo date('M d, Y', strtotime($episode['created_at'])); ?>
                    </td>
                    <td>
                        <div class="action-btns">
                            <a href="<?php echo SITE_URL; ?>/watch/<?php echo urlencode($episode['slug']); ?>" 
                               target="_blank" 
                               class="action-btn view" 
                               title="Watch Episode">
                                <i data-lucide="eye"></i>
                            </a>
                            <a href="episode-edit.php?id=<?php echo $episode['id']; ?>" 
                               class="action-btn edit" 
                               title="Edit Episode">
                                <i data-lucide="edit"></i>
                            </a>
                            <button onclick="confirmDelete(<?php echo $episode['id']; ?>, '<?php echo addslashes($episodeDisplay); ?>', <?php echo $anime_id; ?>)" 
                                    class="action-btn delete" 
                                    title="Delete Episode">
                                <i data-lucide="trash-2"></i>
                            </button>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    
    <?php if($totalPages > 1): ?>
    <div class="pagination">
        <?php if($page > 1): ?>
            <a href="?page=<?php echo $page - 1; ?><?php echo $anime_id ? '&anime_id='.$anime_id : ''; ?><?php echo $search ? '&search='.urlencode($search) : ''; ?>">
                <i data-lucide="chevron-left"></i> Previous
            </a>
        <?php else: ?>
            <span class="disabled">
                <i data-lucide="chevron-left"></i> Previous
            </span>
        <?php endif; ?>
        
        <?php
        $start = max(1, $page - 2);
        $end = min($totalPages, $page + 2);
        
        for($i = $start; $i <= $end; $i++):
        ?>
            <a href="?page=<?php echo $i; ?><?php echo $anime_id ? '&anime_id='.$anime_id : ''; ?><?php echo $search ? '&search='.urlencode($search) : ''; ?>" 
               class="<?php echo $i === $page ? 'active' : ''; ?>">
                <?php echo $i; ?>
            </a>
        <?php endfor; ?>
        
        <?php if($page < $totalPages): ?>
            <a href="?page=<?php echo $page + 1; ?><?php echo $anime_id ? '&anime_id='.$anime_id : ''; ?><?php echo $search ? '&search='.urlencode($search) : ''; ?>">
                Next <i data-lucide="chevron-right"></i>
            </a>
        <?php else: ?>
            <span class="disabled">
                Next <i data-lucide="chevron-right"></i>
            </span>
        <?php endif; ?>
    </div>
    <?php endif; ?>
    
    <?php else: ?>
    <div class="episodes-table">
        <div class="empty-state">
            <i data-lucide="video-off"></i>
            <h3>No Episodes Found</h3>
            <p>
                <?php 
                if($search) {
                    echo 'No episodes match your search criteria.<br>Try adjusting your search terms.';
                } elseif($anime_id) {
                    echo 'This anime doesn\'t have any episodes yet.<br>Click the button below to add the first episode!';
                } else {
                    echo 'No episodes found in the database.<br>Start by adding episodes to your anime.';
                }
                ?>
            </p>
            <?php if($anime_id && !$search): ?>
            <a href="episode-add.php?anime_id=<?php echo $anime_id; ?>" class="add-btn">
                <i data-lucide="plus-circle"></i> Add First Episode
            </a>
            <?php elseif($search): ?>
            <a href="?<?php echo $anime_id ? 'anime_id='.$anime_id : ''; ?>" class="add-btn" style="background: #667eea;">
                <i data-lucide="rotate-ccw"></i> Clear Search
            </a>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
</div>

<script>
    function confirmDelete(id, episodeNum, animeId) {
        if(confirm('Are you sure you want to delete ' + episodeNum + '?\n\nThis will also delete all servers and download links associated with this episode.')) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = 'episodes-list.php?id=' + id + (animeId ? '&anime_id=' + animeId : '');
            
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'delete_episode';
            input.value = '1';
            
            form.appendChild(input);
            document.body.appendChild(form);
            form.submit();
        }
    }
</script>

<?php require_once 'footer.php'; ?>