<?php
require_once '../config.php';
$page_title = 'Admin Dashboard';
include 'header.php';
// Handle delete request
if(isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    try {
        $pdo->beginTransaction();
        $pdo->prepare("DELETE FROM episodes WHERE anime_id = ?")->execute([$delete_id]);
        $pdo->prepare("DELETE FROM anime WHERE id = ?")->execute([$delete_id]);
        $pdo->commit();
        header('Location: index.php?deleted=1');
        exit;
    } catch(Exception $e) {
        $pdo->rollBack();
        $error = "Error deleting anime";
    }
}
// Get statistics
$totalAnime = $pdo->query("SELECT COUNT(*) FROM anime")->fetchColumn();
$totalEpisodes = $pdo->query("SELECT COUNT(*) FROM episodes")->fetchColumn();
$hotAnime = $pdo->query("SELECT COUNT(*) FROM anime WHERE is_hot = 1")->fetchColumn();
$newAnime = $pdo->query("SELECT COUNT(*) FROM anime WHERE is_new = 1")->fetchColumn();
// Handle search
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$searchQuery = '';
$params = [];
if($search) {
    $searchQuery = " WHERE title LIKE ?";
    $params[] = "%$search%";
}
// Get recent anime with search
$stmt = $pdo->prepare("SELECT * FROM anime" . $searchQuery . " ORDER BY created_at DESC LIMIT 20");
$stmt->execute($params);
$recentAnime = $stmt->fetchAll();
?>
<div class="admin-container">
    <?php if(isset($_GET['deleted'])): ?>
        <div class="alert success">
            <i data-lucide="check-circle"></i>
            Anime deleted successfully!
        </div>
    <?php endif; ?>
    
    <?php if(isset($error)): ?>
        <div class="alert error">
            <i data-lucide="alert-circle"></i>
            <?php echo $error; ?>
        </div>
    <?php endif; ?>
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon purple">
                <i data-lucide="clapperboard"></i>
            </div>
            <div class="stat-info">
                <h3><?php echo $totalAnime; ?></h3>
                <p>Total Anime</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon orange">
                <i data-lucide="play"></i>
            </div>
            <div class="stat-info">
                <h3><?php echo $totalEpisodes; ?></h3>
                <p>Total Episodes</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon red">
                <i data-lucide="flame"></i>
            </div>
            <div class="stat-info">
                <h3><?php echo $hotAnime; ?></h3>
                <p>Hot Series</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon green">
                <i data-lucide="zap"></i>
            </div>
            <div class="stat-info">
                <h3><?php echo $newAnime; ?></h3>
                <p>New Series</p>
            </div>
        </div>
    </div>
    
    <div class="recent-table">
        <div class="table-header">
            <h2><i data-lucide="database"></i> Recent Anime</h2>
            <form method="GET" class="search-box">
                <input type="text" name="search" class="search-input" placeholder="Search anime..." value="<?php echo htmlspecialchars($search); ?>">
                <button type="submit" class="search-btn">
                    <i data-lucide="search"></i> Search
                </button>
                <?php if($search): ?>
                    <a href="index.php" class="search-btn" style="background: #6c757d;">
                        <i data-lucide="x"></i> Clear
                    </a>
                <?php endif; ?>
            </form>
        </div>
        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Status</th>
                        <th>Tags</th>
                        <th>Created</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($recentAnime) > 0): ?>
                        <?php foreach($recentAnime as $anime): ?>
                        <tr>
                            <td>
                                <div class="anime-title"><?php echo htmlspecialchars($anime['title']); ?></div>
                            </td>
                            <td><?php echo ucfirst($anime['status']); ?></td>
                            <td>
                                <?php if($anime['is_hot']): ?>
                                    <span class="badge hot">HOT</span>
                                <?php endif; ?>
                                <?php if($anime['is_new']): ?>
                                    <span class="badge new">NEW</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo date('M d, Y', strtotime($anime['created_at'])); ?></td>
                            <td class="table-actions">
                                <a href="anime-edit.php?id=<?php echo $anime['id']; ?>" title="Edit">
                                    <i data-lucide="edit"></i>
                                </a>
                                <a href="episode-add.php?anime_id=<?php echo $anime['id']; ?>" title="Add Episode">
                                    <i data-lucide="plus-circle"></i>
                                </a>
                                <button class="delete" onclick="confirmDelete(<?php echo $anime['id']; ?>, '<?php echo addslashes($anime['title']); ?>')" title="Delete">
                                    <i data-lucide="trash-2"></i>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" style="text-align: center; padding: 40px; color: #999;">
                                <?php echo $search ? 'No anime found matching your search.' : 'No anime added yet.'; ?>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<script>
function confirmDelete(id, title) {
    if(confirm('Are you sure you want to delete "' + title + '"?\n\nThis will also delete all episodes associated with this anime.')) {
        window.location.href = 'index.php?delete_id=' + id;
    }
}
</script>
<?php include 'footer.php'; ?>
<!-- ===================================== -->
