<!-- header.php -->
<?php
if(!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title : 'Admin Dashboard'; ?></title>
    <link rel="stylesheet" href="https://unpkg.com/lucide@latest/dist/umd/lucide.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f7fa;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        /* ========== HEADER ========== */
        .admin-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 12px 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            position: sticky;
            top: 0;
            z-index: 100;
        }
        
        .admin-header-content {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 15px;
            display: grid;
            grid-template-columns: auto 1fr;
            gap: 15px;
            align-items: center;
        }
        
        .admin-logo {
            color: #fff;
            font-size: 22px;
            font-weight: bold;
            display: flex;
            align-items: center;
            gap: 8px;
            text-decoration: none;
            line-height: 1;
        }
        
        .admin-logo i {
            flex-shrink: 0;
        }
        
        .admin-logo span {
            display: inline-block;
        }
        
        .admin-user {
            display: grid;
            grid-template-columns: 1fr auto auto;
            align-items: center;
            gap: 10px;
            color: #fff;
        }
        
        .admin-user > span {
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 13px;
            white-space: nowrap;
            overflow: hidden;
        }
        
        .admin-user > span > span {
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        
        .admin-user a {
            color: #fff;
            text-decoration: none;
            background: rgba(255,255,255,0.2);
            padding: 8px 12px;
            border-radius: 6px;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 13px;
            white-space: nowrap;
            line-height: 1;
        }
        
        .admin-user a i,
        .admin-user > span i {
            flex-shrink: 0;
        }
        
        .admin-user a span {
            display: inline-block;
        }
        
        .admin-user a:hover {
            background: rgba(255,255,255,0.3);
        }
        
        /* ========== NAVIGATION ========== */
        .admin-nav {
            background: #fff;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            border-bottom: 1px solid #e0e0e0;
        }
        
        .admin-nav-content {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 10px;
            display: flex;
            gap: 2px;
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }
        
        .admin-nav-content::-webkit-scrollbar {
            height: 3px;
        }
        
        .admin-nav-content::-webkit-scrollbar-thumb {
            background: #667eea;
            border-radius: 4px;
        }
        
        .nav-link {
            color: #333;
            text-decoration: none;
            padding: 12px 15px;
            display: flex;
            align-items: center;
            gap: 6px;
            transition: all 0.3s;
            white-space: nowrap;
            font-size: 13px;
            font-weight: 500;
            border-bottom: 3px solid transparent;
        }
        
        .nav-link:hover {
            color: #667eea;
            background: #f8f9fa;
            border-bottom-color: #667eea;
        }
        
        .nav-link.active {
            color: #667eea;
            border-bottom-color: #667eea;
        }
        
        /* ========== MAIN CONTENT ========== */
        .admin-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 30px 20px;
            flex: 1;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: #fff;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            display: flex;
            align-items: center;
            gap: 15px;
            transition: all 0.3s;
        }
        
        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.12);
        }
        
        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            color: #fff;
            flex-shrink: 0;
        }
        
        .stat-icon.purple { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
        .stat-icon.orange { background: linear-gradient(135deg, #FF6B35 0%, #F7931E 100%); }
        .stat-icon.green { background: linear-gradient(135deg, #4ECDC4 0%, #44A08D 100%); }
        .stat-icon.red { background: linear-gradient(135deg, #FF416C 0%, #FF4B2B 100%); }
        
        .stat-info h3 {
            font-size: 28px;
            margin-bottom: 3px;
            line-height: 1;
        }
        
        .stat-info p {
            color: #666;
            font-size: 13px;
        }
        
        /* ========== TABLE STYLES ========== */
        .recent-table {
            background: #fff;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }
        
        .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            flex-wrap: wrap;
            gap: 15px;
        }
        
        .table-header h2 {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 20px;
        }
        
        .search-box {
            display: flex;
            gap: 10px;
            align-items: center;
        }
        
        .search-input {
            padding: 8px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            width: 250px;
            transition: all 0.3s;
        }
        
        .search-input:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .search-btn {
            padding: 8px 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #fff;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s;
        }
        
        .search-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102,126,234,0.4);
        }
        
        .table-wrapper {
            overflow-x: auto;
            border-radius: 8px;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        th {
            background: #f8f9fa;
            padding: 12px;
            text-align: left;
            font-weight: 600;
            color: #333;
            white-space: nowrap;
            font-size: 13px;
        }
        
        td {
            padding: 12px;
            border-bottom: 1px solid #f0f0f0;
            font-size: 13px;
        }
        
        tr:hover {
            background: #f8f9fa;
        }
        
        .anime-title {
            font-weight: 500;
            color: #333;
            max-width: 300px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        
        .badge {
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 10px;
            font-weight: 600;
            display: inline-block;
            margin: 2px;
        }
        
        .badge.hot {
            background: #fee;
            color: #c33;
        }
        
        .badge.new {
            background: #efe;
            color: #3c3;
        }
        
        .table-actions {
            display: flex;
            gap: 8px;
        }
        
        .table-actions a,
        .table-actions button {
            color: #667eea;
            text-decoration: none;
            font-size: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 32px;
            height: 32px;
            border-radius: 6px;
            background: #f0f0f0;
            transition: all 0.3s;
            border: none;
            cursor: pointer;
        }
        
        .table-actions a:hover,
        .table-actions button:hover {
            color: #fff;
            background: #667eea;
        }
        
        .table-actions button.delete:hover {
            background: #ff4b2b;
        }
        
        .alert {
            padding: 12px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 14px;
        }
        
        .alert.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        /* ========== FOOTER ========== */
        .admin-footer {
            background: #2c3e50;
            color: #ecf0f1;
            padding: 20px 0;
            margin-top: auto;
        }
        
        .admin-footer-content {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }
        
        .footer-text {
            font-size: 14px;
        }
        
        .footer-links {
            display: flex;
            gap: 20px;
        }
        
        .footer-links a {
            color: #ecf0f1;
            text-decoration: none;
            font-size: 14px;
            transition: color 0.3s;
        }
        
        .footer-links a:hover {
            color: #667eea;
        }
        
        /* ========== RESPONSIVE DESIGN ========== */
        @media (max-width: 768px) {
            .admin-header {
                padding: 10px 0;
            }
            
            .admin-header-content {
                grid-template-columns: 1fr;
                gap: 10px;
            }
            
            .admin-logo {
                font-size: 18px;
                gap: 6px;
            }
            
            .admin-logo span {
                font-size: 18px;
            }
            
            .admin-user {
                grid-template-columns: 1fr 1fr;
                gap: 8px;
            }
            
            .admin-user > span {
                grid-column: 1 / -1;
                font-size: 12px;
                padding: 6px 0;
                justify-content: flex-start;
            }
            
            .admin-user a {
                padding: 8px 10px;
                font-size: 12px;
                justify-content: center;
            }
            
            .admin-user a span {
                font-size: 12px;
            }
            
            .nav-link {
                padding: 10px 12px;
                font-size: 12px;
                gap: 5px;
            }
            
            .admin-container {
                padding: 20px 10px;
            }
            
            .stats-grid {
                grid-template-columns: 1fr 1fr;
                gap: 10px;
            }
            
            .stat-card {
                padding: 12px;
                gap: 10px;
            }
            
            .stat-icon {
                width: 40px;
                height: 40px;
                font-size: 18px;
            }
            
            .stat-info h3 {
                font-size: 22px;
            }
            
            .stat-info p {
                font-size: 11px;
            }
            
            .recent-table {
                padding: 15px 10px;
            }
            
            .table-header {
                flex-direction: column;
                align-items: stretch;
                gap: 12px;
            }
            
            .table-header h2 {
                font-size: 16px;
            }
            
            .search-box {
                width: 100%;
                flex-direction: row;
            }
            
            .search-input {
                flex: 1;
                font-size: 13px;
                padding: 8px 12px;
            }
            
            .search-btn {
                padding: 8px 15px;
                font-size: 13px;
            }
            
            .table-wrapper {
                margin: 0 -10px;
                padding: 0 10px;
            }
            
            th, td {
                padding: 10px 6px;
                font-size: 11px;
            }
            
            .anime-title {
                max-width: 150px;
                font-size: 12px;
            }
            
            .badge {
                font-size: 9px;
                padding: 3px 6px;
            }
            
            .table-actions {
                flex-direction: column;
                gap: 5px;
            }
            
            .table-actions a,
            .table-actions button {
                width: 28px;
                height: 28px;
                font-size: 14px;
            }
            
            .admin-footer {
                padding: 15px 0;
            }
            
            .admin-footer-content {
                flex-direction: column;
                text-align: center;
                gap: 10px;
            }
            
            .footer-text {
                font-size: 12px;
            }
            
            .footer-links {
                gap: 15px;
            }
            
            .footer-links a {
                font-size: 12px;
            }
        }
        
        @media (max-width: 576px) {
            .admin-header-content {
                padding: 0 10px;
            }
            
            .admin-logo {
                font-size: 16px;
            }
            
            .admin-logo span {
                font-size: 16px;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .stat-card {
                flex-direction: row;
            }
            
            .search-box {
                flex-direction: column;
                gap: 8px;
            }
            
            .search-btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <header class="admin-header">
        <div class="admin-header-content">
            
            <div class="admin-user">
                <span>
                    <i data-lucide="user"></i>
                    <span><?php echo $_SESSION['admin_username']; ?></span>
                </span>
                <a href="/" target="_blank">
                    <i data-lucide="external-link"></i>
                    <span>View Site</span>
                </a>
                <a href="logout.php">
                    <i data-lucide="log-out"></i>
                    <span>Logout</span>
                </a>
            </div>
        </div>
    </header>
    
    <nav class="admin-nav">
        <div class="admin-nav-content">
            <a href="index.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">
                <i data-lucide="home"></i> Dashboard
            </a>
            <a href="anime-add.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'anime-add.php' ? 'active' : ''; ?>">
                <i data-lucide="plus"></i> Add Anime
            </a>
            <a href="anime-list.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'anime-list.php' ? 'active' : ''; ?>">
                <i data-lucide="list"></i> Manage Anime
            </a>
            <a href="anime-import.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'anime-import.php' ? 'active' : ''; ?>">
                <i data-lucide="download"></i> MAL Import
            </a>
            <a href="episode-add.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'episode-add.php' ? 'active' : ''; ?>">
                <i data-lucide="video"></i> Add Episode
            </a>
            <a href="episode-edit.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'episode-edit.php' ? 'active' : ''; ?>">
                <i data-lucide="film"></i> Edit Episode
            </a>
            <a href="manage_users.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'manage_users.php' ? 'active' : ''; ?>">
                <i data-lucide="users"></i> Users
            </a>
            <a href="settings.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'settings.php' ? 'active' : ''; ?>">
                <i data-lucide="settings"></i> Settings
            </a>
    <a href="site-customize.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'site-customize.php' ? 'active' : ''; ?>">
    <i data-lucide="paintbrush"></i> Customize Site
</a>
        </div>
    </nav>