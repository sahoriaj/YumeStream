<?php
require_once '../config.php';

if(!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$id = $_GET['id'] ?? 0;

// Get anime details
$stmt = $pdo->prepare("SELECT * FROM anime WHERE id = ?");
$stmt->execute([$id]);
$anime = $stmt->fetch();

if(!$anime) {
    header('Location: anime-list.php');
    exit;
}

$success = '';
$error = '';

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = sanitize($_POST['title']);
    $zh_name = sanitize($_POST['zh_name']);
    $synopsis = sanitize($_POST['synopsis']);
    $type = sanitize($_POST['type']);
    $status = $_POST['status'];
    $network = sanitize($_POST['network']);
    $duration = sanitize($_POST['duration']);
    $studio = sanitize($_POST['studio']);
    $country = sanitize($_POST['country']);
    $rating = floatval($_POST['rating']);
    $genres = sanitize($_POST['genres']);
    $released_date = $_POST['released_date'];
    $is_hot = isset($_POST['is_hot']) ? 1 : 0;
    $is_new = isset($_POST['is_new']) ? 1 : 0;
    $slug = createSlug($title);
    
    // Handle poster (file upload or URL)
    $poster = $anime['poster'];
    $poster_url = sanitize($_POST['poster_url'] ?? '');
    
    if(!empty($poster_url)) {
        if(filter_var($poster_url, FILTER_VALIDATE_URL)) {
            // Delete old local image if exists
            if(!empty($anime['poster']) && !filter_var($anime['poster'], FILTER_VALIDATE_URL)) {
                deleteImage($anime['poster']);
            }
            $poster = $poster_url;
        } else {
            $error = 'Invalid poster URL';
        }
    } elseif(isset($_FILES['poster']) && $_FILES['poster']['error'] === UPLOAD_ERR_OK) {
        $new_poster = uploadImage($_FILES['poster']);
        if($new_poster) {
            // Delete old local image if exists
            if(!empty($anime['poster']) && !filter_var($anime['poster'], FILTER_VALIDATE_URL)) {
                deleteImage($anime['poster']);
            }
            $poster = $new_poster;
        } else {
            $error = 'Failed to upload poster image';
        }
    }
    
    // Handle background image (file upload or URL)
    $background_image = $anime['background_image'];
    $background_url = sanitize($_POST['background_url'] ?? '');
    
    if(!empty($background_url)) {
        if(filter_var($background_url, FILTER_VALIDATE_URL)) {
            // Delete old local image if exists
            if(!empty($anime['background_image']) && !filter_var($anime['background_image'], FILTER_VALIDATE_URL)) {
                deleteImage($anime['background_image']);
            }
            $background_image = $background_url;
        } else {
            $error = 'Invalid background URL';
        }
    } elseif(isset($_FILES['background_image']) && $_FILES['background_image']['error'] === UPLOAD_ERR_OK) {
        $new_background = uploadImage($_FILES['background_image']);
        if($new_background) {
            // Delete old local image if exists
            if(!empty($anime['background_image']) && !filter_var($anime['background_image'], FILTER_VALIDATE_URL)) {
                deleteImage($anime['background_image']);
            }
            $background_image = $new_background;
        } else {
            $error = 'Failed to upload background image';
        }
    }
    
    if(!$error) {
        try {
            $stmt = $pdo->prepare("UPDATE anime SET title = ?, zh_name = ?, slug = ?, synopsis = ?, poster = ?, background_image = ?, status = ?, type = ?, network = ?, duration = ?, studio = ?, country = ?, rating = ?, genres = ?, released_date = ?, is_hot = ?, is_new = ?, update_date = NOW() WHERE id = ?");
            $stmt->execute([$title, $zh_name, $slug, $synopsis, $poster, $background_image, $status, $type, $network, $duration, $studio, $country, $rating, $genres, $released_date, $is_hot, $is_new, $id]);
            $success = 'Anime updated successfully!';
            
            // Refresh anime data
            $stmt = $pdo->prepare("SELECT * FROM anime WHERE id = ?");
            $stmt->execute([$id]);
            $anime = $stmt->fetch();
        } catch(PDOException $e) {
            $error = 'Error: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Anime - Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f7fa;
        }
        
        .admin-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .admin-header-content {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .admin-logo {
            color: #fff;
            font-size: 24px;
            font-weight: bold;
        }
        
        .back-btn {
            color: #fff;
            text-decoration: none;
            background: rgba(255,255,255,0.2);
            padding: 10px 20px;
            border-radius: 8px;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .back-btn:hover {
            background: rgba(255,255,255,0.3);
        }
        
        .container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 0 20px;
        }
        
        .form-card {
            background: #fff;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            margin-bottom: 20px;
        }
        
        .form-card h2 {
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
            color: #333;
            padding-bottom: 15px;
            border-bottom: 2px solid #f0f0f0;
        }
        
        .form-card h2 i {
            color: #667eea;
        }
        
        .alert {
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .alert.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .form-group label i {
            color: #667eea;
        }
        
        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 15px;
            font-family: inherit;
            transition: all 0.3s;
        }
        
        .form-group textarea {
            min-height: 150px;
            resize: vertical;
        }
        
        .form-group input:focus,
        .form-group textarea:focus,
        .form-group select:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 10px rgba(102,126,234,0.2);
        }
        
        .checkbox-group {
            display: flex;
            gap: 30px;
            margin-top: 10px;
        }
        
        .checkbox-label {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
        }
        
        .checkbox-label input {
            width: auto;
            cursor: pointer;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        
        .form-row-3 {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
        }
        
        .btn {
            padding: 15px 35px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #fff;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(102,126,234,0.4);
        }
        
        .current-poster {
            margin-top: 15px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 10px;
        }
        
        .current-poster img {
            max-width: 200px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        
        .current-background {
            margin-top: 15px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 10px;
        }
        
        .current-background img {
            max-width: 400px;
            width: 100%;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        
        .help-text {
            font-size: 13px;
            color: #666;
            margin-top: 5px;
        }
        
        .upload-badge {
            display: inline-block;
            background: linear-gradient(135deg, #00c6ff 0%, #0072ff 100%);
            color: #fff;
            padding: 5px 12px;
            border-radius: 15px;
            font-size: 12px;
            font-weight: 600;
            margin-left: 10px;
        }
        
        .image-type-badge {
            display: inline-block;
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: #fff;
            padding: 5px 12px;
            border-radius: 15px;
            font-size: 12px;
            font-weight: 600;
            margin-left: 10px;
        }
        
        .image-url {
            background: #e7f3ff;
            padding: 10px;
            border-radius: 8px;
            margin-top: 10px;
            font-size: 13px;
            word-break: break-all;
            color: #0066cc;
        }
        
        @media (max-width: 768px) {
            .form-row, .form-row-3 {
                grid-template-columns: 1fr;
            }
            .current-background img {
                max-width: 100%;
            }
        }
    </style>
</head>
<body>
    <header class="admin-header">
        <div class="admin-header-content">
            <div class="admin-logo">
                <i class="fas fa-edit"></i> Edit Anime
            </div>
            <a href="anime-list.php" class="back-btn">
                <i class="fas fa-arrow-left"></i> Back to List
            </a>
        </div>
    </header>
    
    <div class="container">
        <div class="form-card">
            <h2><i class="fas fa-film"></i> Edit: <?php echo htmlspecialchars($anime['title']); ?></h2>
            
            <?php if($success): ?>
                <div class="alert success">
                    <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                </div>
            <?php endif; ?>
            
            <?php if($error): ?>
                <div class="alert error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" enctype="multipart/form-data">
                <!-- Basic Information -->
                <div class="form-group">
                    <label><i class="fas fa-heading"></i> Title *</label>
                    <input type="text" name="title" required value="<?php echo htmlspecialchars($anime['title']); ?>">
                </div>
                
                <div class="form-group">
                    <label><i class="fas fa-language"></i> Chinese Name</label>
                    <input type="text" name="zh_name" value="<?php echo htmlspecialchars($anime['zh_name']); ?>">
                </div>
                
                <div class="form-group">
                    <label><i class="fas fa-align-left"></i> Synopsis</label>
                    <textarea name="synopsis"><?php echo htmlspecialchars($anime['synopsis']); ?></textarea>
                </div>
                
                <!-- Media Details -->
                <div class="form-row">
                    <div class="form-group">
                        <label><i class="fas fa-tag"></i> Type</label>
                        <input type="text" name="type" placeholder="e.g. TV Series, Movie, OVA" value="<?php echo htmlspecialchars($anime['type']); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-info-circle"></i> Status *</label>
                        <select name="status" required>
                            <option value="ongoing" <?php echo $anime['status'] == 'ongoing' ? 'selected' : ''; ?>>Ongoing</option>
                            <option value="completed" <?php echo $anime['status'] == 'completed' ? 'selected' : ''; ?>>Completed</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-row-3">
                    <div class="form-group">
                        <label><i class="fas fa-tv"></i> Network</label>
                        <input type="text" name="network" placeholder="e.g. Tencent Video" value="<?php echo htmlspecialchars($anime['network']); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-clock"></i> Duration</label>
                        <input type="text" name="duration" placeholder="e.g. 20 min per ep" value="<?php echo htmlspecialchars($anime['duration']); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-user"></i> Studio</label>
                        <input type="text" name="studio" placeholder="e.g. Motion Magic" value="<?php echo htmlspecialchars($anime['studio']); ?>">
                    </div>
                </div>
                
                <div class="form-row-3">
                    <div class="form-group">
                        <label><i class="fas fa-globe"></i> Country</label>
                        <input type="text" name="country" placeholder="e.g. China" value="<?php echo htmlspecialchars($anime['country']); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-star"></i> Rating</label>
                        <input type="number" name="rating" step="0.1" min="0" max="10" placeholder="9.2" value="<?php echo htmlspecialchars($anime['rating']); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-calendar"></i> Released Date</label>
                        <input type="date" name="released_date" value="<?php echo htmlspecialchars($anime['released_date']); ?>">
                    </div>
                </div>
                
                <div class="form-group">
                    <label><i class="fas fa-tags"></i> Genres</label>
                    <input type="text" name="genres" placeholder="Action, Adventure, Fantasy" value="<?php echo htmlspecialchars($anime['genres']); ?>">
                    <div class="help-text">Separate multiple genres with commas</div>
                </div>
                
                <!-- Poster Image -->
                <div class="form-group">
                    <label>
                        <i class="fas fa-image"></i> Poster Image
                        <span class="upload-badge"><i class="fas fa-upload"></i> Local Upload</span>
                        <span class="image-type-badge">Vertical/Portrait</span>
                    </label>
                    <input type="file" name="poster" accept="image/*">
                    <div class="help-text">
                        <i class="fas fa-info-circle"></i> Upload a new poster image (replaces current)
                    </div>
                </div>
                
                <div class="form-group">
                    <label><i class="fas fa-link"></i> Or Enter New Poster URL</label>
                    <input type="url" name="poster_url" placeholder="https://example.com/image.jpg">
                    <div class="help-text">Leave blank to keep current poster</div>
                </div>
                
                <?php if($anime['poster']): ?>
                <div class="current-poster">
                    <p style="margin-bottom: 10px; color: #666; font-size: 14px; font-weight: 600;">
                        <i class="fas fa-image"></i> Current Poster:
                    </p>
                    <img src="<?php echo getImageUrl($anime['poster']); ?>" alt="Current Poster" onerror="this.src='<?php echo SITE_URL; ?>/uploads/default.jpg'">
                    
                    <div class="image-url">
                        <i class="fas fa-link"></i> <strong>Image URL:</strong><br>
                        <?php echo htmlspecialchars(getImageUrl($anime['poster'])); ?>
                    </div>
                </div>
                <?php endif; ?>
                
                <!-- Background Image -->
                <div class="form-group" style="margin-top: 30px;">
                    <label>
                        <i class="fas fa-panorama"></i> Background Image
                        <span class="upload-badge"><i class="fas fa-upload"></i> Local Upload</span>
                        <span class="image-type-badge">Horizontal/Landscape</span>
                    </label>
                    <input type="file" name="background_image" accept="image/*">
                    <div class="help-text">
                        <i class="fas fa-info-circle"></i> Recommended: Wide background banner (e.g., 1920x1080px)
                    </div>
                </div>
                
                <div class="form-group">
                    <label><i class="fas fa-link"></i> Or Enter New Background URL</label>
                    <input type="url" name="background_url" placeholder="https://example.com/background.jpg">
                    <div class="help-text">Leave blank to keep current background (or use poster if no background exists)</div>
                </div>
                
                <?php if(!empty($anime['background_image'])): ?>
                <div class="current-background">
                    <p style="margin-bottom: 10px; color: #666; font-size: 14px; font-weight: 600;">
                        <i class="fas fa-panorama"></i> Current Background:
                    </p>
                    <img src="<?php echo getImageUrl($anime['background_image']); ?>" alt="Current Background" onerror="this.src='<?php echo SITE_URL; ?>/uploads/default.jpg'">
                    
                    <div class="image-url">
                        <i class="fas fa-link"></i> <strong>Image URL:</strong><br>
                        <?php echo htmlspecialchars(getImageUrl($anime['background_image'])); ?>
                    </div>
                </div>
                <?php else: ?>
                <div class="help-text" style="margin-top: 10px; padding: 10px; background: #fff3cd; border-radius: 8px; color: #856404;">
                    <i class="fas fa-info-circle"></i> <strong>No background image set.</strong> The poster image will be used as the background on the detail page.
                </div>
                <?php endif; ?>
                
                <!-- Tags -->
                <div class="form-group" style="margin-top: 30px;">
                    <label><i class="fas fa-tags"></i> Tags</label>
                    <div class="checkbox-group">
                        <label class="checkbox-label">
                            <input type="checkbox" name="is_hot" <?php echo $anime['is_hot'] ? 'checked' : ''; ?>>
                            <span><i class="fas fa-fire"></i> Hot Series</span>
                        </label>
                        <label class="checkbox-label">
                            <input type="checkbox" name="is_new" <?php echo $anime['is_new'] ? 'checked' : ''; ?>>
                            <span><i class="fas fa-sparkles"></i> New Series</span>
                        </label>
                    </div>
                </div>
                
                <button type="submit" class="btn">
                    <i class="fas fa-save"></i> Update Anime
                </button>
            </form>
        </div>
    </div>
</body>
</html>