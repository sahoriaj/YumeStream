<?php
require_once '../config.php';

if(!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$page_title = 'Import from MyAnimeList';

$success = '';
$error = '';
$anime_data = null;
$characters_data = null;
$staff_data = null;

// Function to fetch anime data from Jikan API
function fetchAnimeFromJikan($mal_id) {
    $url = "https://api.jikan.moe/v4/anime/{$mal_id}/full";
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; AnimeDB/1.0)');
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    
    if($error) {
        error_log("Jikan API Error: " . $error);
        return null;
    }
    
    if($httpCode === 200 && $response) {
        $data = json_decode($response, true);
        return $data['data'] ?? null;
    }
    
    error_log("Jikan API HTTP Code: " . $httpCode);
    return null;
}

// Function to fetch characters from Jikan API
function fetchCharactersFromJikan($mal_id) {
    sleep(1);
    
    $url = "https://api.jikan.moe/v4/anime/{$mal_id}/characters";
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; AnimeDB/1.0)');
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    
    if($error) {
        error_log("Jikan Characters API Error: " . $error);
        return [];
    }
    
    if($httpCode === 200 && $response) {
        $data = json_decode($response, true);
        return $data['data'] ?? [];
    }
    
    error_log("Jikan Characters API HTTP Code: " . $httpCode);
    return [];
}

// Function to fetch staff from Jikan API
function fetchStaffFromJikan($mal_id) {
    sleep(1);
    
    $url = "https://api.jikan.moe/v4/anime/{$mal_id}/staff";
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; AnimeDB/1.0)');
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    
    if($error) {
        error_log("Jikan Staff API Error: " . $error);
        return [];
    }
    
    if($httpCode === 200 && $response) {
        $data = json_decode($response, true);
        return $data['data'] ?? [];
    }
    
    error_log("Jikan Staff API HTTP Code: " . $httpCode);
    return [];
}

// Handle fetching anime data
if(isset($_POST['fetch_anime'])) {
    $mal_id = intval($_POST['mal_id']);
    
    if($mal_id > 0) {
        $anime_data = fetchAnimeFromJikan($mal_id);
        
        if($anime_data) {
            $characters_data = fetchCharactersFromJikan($mal_id);
            $staff_data = fetchStaffFromJikan($mal_id);
            
            $success = 'Anime data fetched successfully! Found ' . count($characters_data) . ' characters and ' . count($staff_data) . ' staff members.';
        } else {
            $error = 'Failed to fetch anime data. Please check the MAL ID and try again.';
        }
    } else {
        $error = 'Please enter a valid MyAnimeList ID.';
    }
}

// Handle importing anime to database
if(isset($_POST['import_anime']) && isset($_POST['anime_json'])) {
    $anime_data = json_decode($_POST['anime_json'], true);
    $characters_json = $_POST['characters_json'] ?? '[]';
    $staff_json = $_POST['staff_json'] ?? '[]';
    $mal_id = intval($_POST['mal_id']);
    
    if($anime_data && $mal_id > 0) {
        $title = sanitize($anime_data['title']);
        $zh_name = sanitize($anime_data['title_japanese'] ?? '');
        $synopsis = sanitize($anime_data['synopsis'] ?? '');
        $type = sanitize($anime_data['type'] ?? 'TV');
        $status = strtolower($anime_data['status'] ?? 'Unknown');
        $status = ($status === 'finished airing' || $status === 'finished') ? 'completed' : 'ongoing';
        
        $studios = $anime_data['studios'] ?? [];
        $studio = !empty($studios) ? sanitize($studios[0]['name']) : '';
        
        $producers = $anime_data['producers'] ?? [];
        $network = !empty($producers) ? sanitize($producers[0]['name']) : '';
        
        $duration = sanitize($anime_data['duration'] ?? '');
        $country = 'Japan';
        $rating = floatval($anime_data['score'] ?? 0);
        
        $genres_array = $anime_data['genres'] ?? [];
        $themes_array = $anime_data['themes'] ?? [];
        $all_genres = array_merge($genres_array, $themes_array);
        $genres = implode(', ', array_map(fn($g) => sanitize($g['name']), $all_genres));
        
        $aired = $anime_data['aired']['from'] ?? null;
        $released_date = $aired ? date('Y-m-d', strtotime($aired)) : null;
        
        $poster = $anime_data['images']['jpg']['large_image_url'] ?? $anime_data['images']['jpg']['image_url'];
        $background_image = $anime_data['trailer']['images']['maximum_image_url'] ?? $poster;
        
        $slug = createSlug($title);
        
        try {
            $stmt = $pdo->prepare("SELECT id FROM anime WHERE mal_id = ?");
            $stmt->execute([$mal_id]);
            $existing = $stmt->fetch();
            
            if($existing) {
                $error = 'This anime is already in the database! MAL ID: ' . $mal_id;
            } else {
                $stmt = $pdo->prepare("INSERT INTO anime (title, zh_name, slug, synopsis, poster, background_image, status, type, network, duration, studio, country, rating, genres, released_date, mal_id, is_hot, is_new, update_date) 
                                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, NOW())");
                $stmt->execute([$title, $zh_name, $slug, $synopsis, $poster, $background_image, $status, $type, $network, $duration, $studio, $country, $rating, $genres, $released_date, $mal_id]);
                
                $anime_id = $pdo->lastInsertId();
                
                $char_count = 0;
                $staff_count = 0;
                
                $characters = json_decode($characters_json, true);
                
                if(!empty($characters) && is_array($characters)) {
                    foreach(array_slice($characters, 0, 20) as $char) {
                        if(!isset($char['character'])) continue;
                        
                        $char_name = sanitize($char['character']['name'] ?? 'Unknown');
                        $char_image = $char['character']['images']['jpg']['image_url'] ?? '';
                        $char_role = sanitize($char['role'] ?? 'Supporting');
                        
                        $va_name = '';
                        $voice_actors = $char['voice_actors'] ?? [];
                        
                        if(!empty($voice_actors) && is_array($voice_actors)) {
                            foreach($voice_actors as $va) {
                                if(isset($va['language']) && $va['language'] === 'Japanese') {
                                    $va_name = sanitize($va['person']['name'] ?? '');
                                    break;
                                }
                            }
                            
                            if(empty($va_name)) {
                                $va_name = sanitize($voice_actors[0]['person']['name'] ?? '');
                            }
                        }
                        
                        try {
                            $stmt = $pdo->prepare("INSERT INTO anime_characters (anime_id, name, role, image_url, voice_actor) VALUES (?, ?, ?, ?, ?)");
                            $stmt->execute([$anime_id, $char_name, $char_role, $char_image, $va_name]);
                            $char_count++;
                        } catch(PDOException $e) {
                            error_log("Character insert error: " . $e->getMessage());
                        }
                    }
                }
                
                $staff = json_decode($staff_json, true);
                
                if(!empty($staff) && is_array($staff)) {
                    foreach(array_slice($staff, 0, 25) as $staff_member) {
                        if(!isset($staff_member['person'])) continue;
                        
                        $staff_name = sanitize($staff_member['person']['name'] ?? 'Unknown');
                        $staff_image = $staff_member['person']['images']['jpg']['image_url'] ?? '';
                        $positions = $staff_member['positions'] ?? [];
                        
                        if(is_array($positions) && !empty($positions)) {
                            $staff_role = implode(', ', array_map('sanitize', $positions));
                        } else {
                            $staff_role = 'Staff';
                        }
                        
                        try {
                            $stmt = $pdo->prepare("INSERT INTO anime_staff (anime_id, name, role, image_url) VALUES (?, ?, ?, ?)");
                            $stmt->execute([$anime_id, $staff_name, $staff_role, $staff_image]);
                            $staff_count++;
                        } catch(PDOException $e) {
                            error_log("Staff insert error: " . $e->getMessage());
                        }
                    }
                }
                
                $success = "✓ Anime imported successfully!<br>✓ Added {$char_count} characters<br>✓ Added {$staff_count} staff members<br>✓ <a href='../anime.php/{$slug}' target='_blank' style='color: #155724; text-decoration: underline;'>View Anime</a>";
                $anime_data = null;
                $characters_data = null;
                $staff_data = null;
            }
        } catch(PDOException $e) {
            $error = 'Database Error: ' . $e->getMessage();
            error_log("Import error: " . $e->getMessage());
        }
    } else {
        $error = 'Invalid anime data provided.';
    }
}

require_once 'header.php';
?>

<style>
    .import-container {
        max-width: 1200px;
        margin: 0 auto;
    }
    
    .form-card {
        background: #fff;
        border-radius: 12px;
        padding: 25px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.08);
        margin-bottom: 25px;
    }
    
    .form-card h2 {
        margin-bottom: 20px;
        display: flex;
        align-items: center;
        gap: 10px;
        color: #333;
        padding-bottom: 15px;
        border-bottom: 2px solid #f0f0f0;
        font-size: 20px;
    }
    
    .help-text {
        background: #e3f2fd;
        border-left: 4px solid #2196f3;
        padding: 15px;
        border-radius: 8px;
        margin-bottom: 20px;
        color: #1565c0;
        font-size: 14px;
        line-height: 1.6;
    }
    
    .help-text strong {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 8px;
    }
    
    .help-text a {
        color: #1565c0;
        text-decoration: underline;
    }
    
    .help-text code {
        background: rgba(0,0,0,0.05);
        padding: 2px 6px;
        border-radius: 4px;
        font-family: 'Courier New', monospace;
    }
    
    .info-box {
        background: #fff3cd;
        border-left: 4px solid #ffc107;
        padding: 15px;
        border-radius: 8px;
        margin-bottom: 20px;
        color: #856404;
        font-size: 14px;
        display: flex;
        align-items: flex-start;
        gap: 10px;
    }
    
    .info-box i {
        flex-shrink: 0;
        margin-top: 2px;
    }
    
    .form-group {
        margin-bottom: 20px;
    }
    
    .form-group label {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 8px;
        font-weight: 600;
        color: #333;
        font-size: 14px;
    }
    
    .form-group input {
        width: 100%;
        padding: 12px 15px;
        border: 2px solid #e0e0e0;
        border-radius: 8px;
        font-size: 15px;
        transition: all 0.3s;
    }
    
    .form-group input:focus {
        outline: none;
        border-color: #667eea;
        box-shadow: 0 0 0 3px rgba(102,126,234,0.1);
    }
    
    .btn {
        padding: 12px 28px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: #fff;
        border: none;
        border-radius: 8px;
        font-size: 15px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        width: 100%;
        justify-content: center;
    }
    
    .btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 20px rgba(102,126,234,0.4);
    }
    
    .btn-success {
        background: linear-gradient(135deg, #00c853 0%, #00e676 100%);
    }
    
    .btn-success:hover {
        box-shadow: 0 5px 20px rgba(0,200,83,0.4);
    }
    
    .preview-card {
        background: #f8f9fa;
        border-radius: 12px;
        padding: 20px;
        margin-top: 20px;
    }
    
    .preview-header {
        display: grid;
        grid-template-columns: auto 1fr;
        gap: 20px;
        margin-bottom: 20px;
    }
    
    .preview-poster {
        width: 150px;
        height: auto;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    
    .preview-info {
        min-width: 0;
    }
    
    .preview-title {
        font-size: 22px;
        font-weight: bold;
        color: #333;
        margin-bottom: 8px;
        word-wrap: break-word;
    }
    
    .preview-japanese {
        color: #888;
        margin-bottom: 15px;
        display: flex;
        align-items: center;
        gap: 6px;
        font-size: 14px;
    }
    
    .preview-meta {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
        gap: 10px;
        margin-bottom: 15px;
    }
    
    .meta-item {
        display: flex;
        gap: 5px;
        font-size: 14px;
    }
    
    .meta-label {
        font-weight: 600;
        color: #666;
    }
    
    .genres-list {
        margin-top: 15px;
        font-size: 14px;
    }
    
    .genres-list strong {
        color: #333;
    }
    
    .preview-synopsis {
        background: #fff;
        padding: 15px;
        border-radius: 8px;
        line-height: 1.6;
        color: #555;
        margin-bottom: 20px;
        font-size: 14px;
    }
    
    .preview-synopsis strong {
        display: block;
        margin-bottom: 10px;
        color: #333;
    }
    
    .characters-preview,
    .staff-preview {
        margin-top: 20px;
        background: #fff;
        padding: 15px;
        border-radius: 8px;
    }
    
    .characters-preview h3,
    .staff-preview h3 {
        margin-bottom: 15px;
        color: #667eea;
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 18px;
    }
    
    .character-grid,
    .staff-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
        gap: 15px;
    }
    
    .character-item,
    .staff-item {
        text-align: center;
    }
    
    .character-item img,
    .staff-item img {
        width: 100%;
        height: 150px;
        object-fit: cover;
        border-radius: 8px;
        margin-bottom: 8px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    
    .character-name,
    .staff-name {
        font-size: 13px;
        font-weight: 600;
        color: #333;
        margin-bottom: 4px;
        word-wrap: break-word;
    }
    
    .character-role,
    .staff-role {
        font-size: 11px;
        color: #666;
        word-wrap: break-word;
    }
    
    /* Responsive Design */
    @media (max-width: 768px) {
        .form-card {
            padding: 20px 15px;
        }
        
        .form-card h2 {
            font-size: 18px;
        }
        
        .preview-header {
            grid-template-columns: 1fr;
            justify-items: center;
            text-align: center;
        }
        
        .preview-poster {
            width: 120px;
        }
        
        .preview-title {
            font-size: 20px;
        }
        
        .preview-japanese {
            justify-content: center;
        }
        
        .preview-meta {
            grid-template-columns: 1fr;
        }
        
        .character-grid,
        .staff-grid {
            grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
            gap: 12px;
        }
        
        .character-item img,
        .staff-item img {
            height: 130px;
        }
        
        .btn {
            padding: 12px 20px;
            font-size: 14px;
        }
    }
    
    @media (max-width: 480px) {
        .preview-poster {
            width: 100px;
        }
        
        .preview-title {
            font-size: 18px;
        }
        
        .character-grid,
        .staff-grid {
            grid-template-columns: repeat(auto-fill, minmax(80px, 1fr));
            gap: 10px;
        }
        
        .character-item img,
        .staff-item img {
            height: 110px;
        }
        
        .character-name,
        .staff-name {
            font-size: 11px;
        }
        
        .character-role,
        .staff-role {
            font-size: 10px;
        }
    }
</style>

<div class="admin-container import-container">
    <?php if($success): ?>
        <div class="alert success">
            <i data-lucide="check-circle"></i>
            <div><?php echo $success; ?></div>
        </div>
    <?php endif; ?>
    
    <?php if($error): ?>
        <div class="alert error">
            <i data-lucide="alert-circle"></i>
            <div><?php echo $error; ?></div>
        </div>
    <?php endif; ?>
    
    <div class="form-card">
        <h2>
            <i data-lucide="search"></i>
            Find Anime on MyAnimeList
        </h2>
        
        <div class="help-text">
            <strong>
                <i data-lucide="info"></i>
                How to find MAL ID:
            </strong>
            1. Go to <a href="https://myanimelist.net" target="_blank">MyAnimeList.net</a><br>
            2. Search for the anime you want<br>
            3. Look at the URL: <code>https://myanimelist.net/anime/<strong>21</strong>/One_Piece</code><br>
            4. The number after "/anime/" is the MAL ID (21 in this example)
        </div>
        
        <div class="info-box">
            <i data-lucide="zap"></i>
            <div><strong>Note:</strong> This will automatically import anime details, characters, and staff information from MyAnimeList using the Jikan API.</div>
        </div>
        
        <form method="POST">
            <div class="form-group">
                <label>
                    <i data-lucide="hash"></i>
                    MyAnimeList ID
                </label>
                <input type="number" name="mal_id" placeholder="e.g., 16498 for Shingeki no Kyojin" required>
            </div>
            
            <button type="submit" name="fetch_anime" class="btn">
                <i data-lucide="download"></i>
                Fetch Anime Data
            </button>
        </form>
    </div>
    
    <?php if($anime_data): ?>
    <div class="form-card">
        <h2>
            <i data-lucide="eye"></i>
            Preview Anime Data
        </h2>
        
        <div class="preview-card">
            <div class="preview-header">
                <img src="<?php echo $anime_data['images']['jpg']['large_image_url'] ?? $anime_data['images']['jpg']['image_url']; ?>" 
                     alt="<?php echo htmlspecialchars($anime_data['title']); ?>" 
                     class="preview-poster">
                
                <div class="preview-info">
                    <div class="preview-title"><?php echo htmlspecialchars($anime_data['title']); ?></div>
                    
                    <?php if(!empty($anime_data['title_japanese'])): ?>
                    <div class="preview-japanese">
                        <i data-lucide="languages"></i>
                        <?php echo htmlspecialchars($anime_data['title_japanese']); ?>
                    </div>
                    <?php endif; ?>
                    
                    <div class="preview-meta">
                        <div class="meta-item">
                            <span class="meta-label">Type:</span>
                            <span><?php echo $anime_data['type']; ?></span>
                        </div>
                        <div class="meta-item">
                            <span class="meta-label">Status:</span>
                            <span><?php echo $anime_data['status']; ?></span>
                        </div>
                        <div class="meta-item">
                            <span class="meta-label">Episodes:</span>
                            <span><?php echo $anime_data['episodes'] ?? 'Unknown'; ?></span>
                        </div>
                        <div class="meta-item">
                            <span class="meta-label">Score:</span>
                            <span><?php echo $anime_data['score'] ?? 'N/A'; ?></span>
                        </div>
                        <div class="meta-item">
                            <span class="meta-label">Duration:</span>
                            <span><?php echo $anime_data['duration'] ?? 'Unknown'; ?></span>
                        </div>
                        <div class="meta-item">
                            <span class="meta-label">Studio:</span>
                            <span><?php echo !empty($anime_data['studios']) ? $anime_data['studios'][0]['name'] : 'Unknown'; ?></span>
                        </div>
                    </div>
                    
                    <div class="genres-list">
                        <strong>Genres:</strong>
                        <?php 
                        $genres = array_merge($anime_data['genres'] ?? [], $anime_data['themes'] ?? []);
                        echo implode(', ', array_map(fn($g) => $g['name'], $genres)); 
                        ?>
                    </div>
                </div>
            </div>
            
            <div class="preview-synopsis">
                <strong>Synopsis:</strong>
                <?php echo nl2br(htmlspecialchars($anime_data['synopsis'] ?? 'No synopsis available.')); ?>
            </div>
            
            <?php if(!empty($characters_data)): ?>
            <div class="characters-preview">
                <h3>
                    <i data-lucide="users"></i>
                    Characters (<?php echo count($characters_data); ?> found - showing first 10)
                </h3>
                <div class="character-grid">
                    <?php foreach(array_slice($characters_data, 0, 10) as $char): ?>
                    <div class="character-item">
                        <img src="<?php echo $char['character']['images']['jpg']['image_url']; ?>" 
                             alt="<?php echo htmlspecialchars($char['character']['name']); ?>">
                        <div class="character-name"><?php echo htmlspecialchars($char['character']['name']); ?></div>
                        <div class="character-role"><?php echo $char['role']; ?></div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php else: ?>
            <div class="info-box">
                <i data-lucide="info"></i>
                <div>No characters found or unable to fetch characters data.</div>
            </div>
            <?php endif; ?>
            
            <?php if(!empty($staff_data)): ?>
            <div class="staff-preview">
                <h3>
                    <i data-lucide="briefcase"></i>
                    Staff (<?php echo count($staff_data); ?> found - showing first 10)
                </h3>
                <div class="staff-grid">
                    <?php foreach(array_slice($staff_data, 0, 10) as $staff_member): ?>
                    <div class="staff-item">
                        <img src="<?php echo $staff_member['person']['images']['jpg']['image_url']; ?>" 
                             alt="<?php echo htmlspecialchars($staff_member['person']['name']); ?>">
                        <div class="staff-name"><?php echo htmlspecialchars($staff_member['person']['name']); ?></div>
                        <div class="staff-role"><?php echo implode(', ', $staff_member['positions']); ?></div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php else: ?>
            <div class="info-box">
                <i data-lucide="info"></i>
                <div>No staff found or unable to fetch staff data.</div>
            </div>
            <?php endif; ?>
        </div>
        
        <form method="POST" style="margin-top: 20px;">
            <input type="hidden" name="anime_json" value='<?php echo htmlspecialchars(json_encode($anime_data)); ?>'>
            <input type="hidden" name="characters_json" value='<?php echo htmlspecialchars(json_encode($characters_data)); ?>'>
            <input type="hidden" name="staff_json" value='<?php echo htmlspecialchars(json_encode($staff_data)); ?>'>
            <input type="hidden" name="mal_id" value="<?php echo $anime_data['mal_id']; ?>">
            <button type="submit" name="import_anime" class="btn btn-success">
                <i data-lucide="file-input"></i>
                Import to Database (with Characters & Staff)
            </button>
        </form>
    </div>
    <?php endif; ?>
</div>

<?php require_once 'footer.php'; ?>