<!-- footer.php -->
    <footer class="admin-footer">
        <div class="admin-footer-content">
            <div class="footer-text">
                &copy; <?php echo date('Y'); ?> Anime Admin Panel. All rights reserved.
            </div>
            <div class="footer-links">
                <a href="index.php">Dashboard</a>
                <a href="settings.php">Settings</a>
                <a href="/" target="_blank">View Site</a>
            </div>
        </div>
    </footer>
    
    <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.js"></script>
    <script>
        lucide.createIcons();
    </script>
</body>
</html>