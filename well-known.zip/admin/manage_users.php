<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../config.php';

// Check if admin is logged in
if(!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

// Check for message in URL parameters (for redirects)
if (isset($_GET['message']) && isset($_GET['type'])) {
    $message = $_GET['message'];
    $messageType = $_GET['type'];
} else {
    $message = '';
    $messageType = '';
}

// Check if users table exists, if not create it
try {
    $pdo->query("SELECT 1 FROM users LIMIT 1");
} catch(PDOException $e) {
    // Users table doesn't exist, create it
    $createTable = "CREATE TABLE IF NOT EXISTS `users` (
      `id` INT PRIMARY KEY AUTO_INCREMENT,
      `username` VARCHAR(50) UNIQUE NOT NULL,
      `password` VARCHAR(255) NOT NULL,
      `email` VARCHAR(100) UNIQUE,
      `full_name` VARCHAR(255),
      `role` ENUM('user', 'admin') DEFAULT 'user',
      `status` ENUM('active', 'inactive') DEFAULT 'active',
      `is_verified` BOOLEAN DEFAULT FALSE,
      `membership_expires_at` DATETIME NULL,
      `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    try {
        $pdo->exec($createTable);
    } catch(PDOException $e) {
        die("Error creating users table: " . $e->getMessage());
    }
}

// Handle user actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    
    try {
        // Handle grant membership
        if ($_POST['action'] === 'grant_membership') {
            $userId = (int)$_POST['user_id'];
            $membershipType = sanitize($_POST['membership_type']);
            $expiresAt = null;
            
            // Calculate expiration date based on membership type
            if ($membershipType === 'monthly') {
                $expiresAt = date('Y-m-d H:i:s', strtotime('+1 month'));
            } elseif ($membershipType === 'yearly') {
                $expiresAt = date('Y-m-d H:i:s', strtotime('+1 year'));
            } elseif ($membershipType === 'lifetime') {
                $expiresAt = null; // NULL means lifetime
            } elseif ($membershipType === 'custom' && !empty($_POST['custom_date'])) {
                $expiresAt = date('Y-m-d H:i:s', strtotime($_POST['custom_date']));
            }
            
            // Update user membership
            $stmt = $pdo->prepare("UPDATE users SET is_verified = 1, membership_expires_at = ? WHERE id = ?");
            $stmt->execute([$expiresAt, $userId]);
            
            // Redirect to prevent form resubmission
            header('Location: ' . $_SERVER['PHP_SELF'] . '?message=Membership granted successfully!&type=success');
            exit;
        }
        
        // Handle revoke membership
        if ($_POST['action'] === 'revoke_membership') {
            $userId = (int)$_POST['user_id'];
            
            $stmt = $pdo->prepare("UPDATE users SET is_verified = 0, membership_expires_at = NULL WHERE id = ?");
            $stmt->execute([$userId]);
            
            // Redirect to prevent form resubmission
            header('Location: ' . $_SERVER['PHP_SELF'] . '?message=Membership revoked successfully!&type=success');
            exit;
        }
        
        // Handle extend membership
        if ($_POST['action'] === 'extend_membership') {
            $userId = (int)$_POST['user_id'];
            $extendType = sanitize($_POST['extend_type']);
            
            // Get current expiration
            $stmt = $pdo->prepare("SELECT membership_expires_at FROM users WHERE id = ?");
            $stmt->execute([$userId]);
            $user = $stmt->fetch();
            
            $currentExpiry = $user['membership_expires_at'];
            $newExpiry = null;
            
            if ($currentExpiry && $currentExpiry !== null) {
                // Extend from current expiry date
                $baseDate = strtotime($currentExpiry);
            } else {
                // Start from today
                $baseDate = time();
            }
            
            if ($extendType === 'month') {
                $newExpiry = date('Y-m-d H:i:s', strtotime('+1 month', $baseDate));
            } elseif ($extendType === 'year') {
                $newExpiry = date('Y-m-d H:i:s', strtotime('+1 year', $baseDate));
            } elseif ($extendType === 'lifetime') {
                $newExpiry = null;
            }
            
            $stmt = $pdo->prepare("UPDATE users SET is_verified = 1, membership_expires_at = ? WHERE id = ?");
            $stmt->execute([$newExpiry, $userId]);
            
            // Redirect to prevent form resubmission
            header('Location: ' . $_SERVER['PHP_SELF'] . '?message=Membership extended successfully!&type=success');
            exit;
        }
        
        if ($_POST['action'] === 'update_user') {
            $userId = (int)$_POST['user_id'];
            $newUsername = sanitize($_POST['new_username']);
            $newPassword = $_POST['new_password'] ?? '';
            $newEmail = sanitize($_POST['new_email']);
            $newFullName = sanitize($_POST['new_full_name'] ?? '');
            $newRole = sanitize($_POST['new_role']);
            $newStatus = sanitize($_POST['new_status']);
            
            $success = true;
            $errorMessage = '';
            
            // Check if username already exists
            if (!empty($newUsername)) {
                $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? AND id != ?");
                $stmt->execute([$newUsername, $userId]);
                
                if ($stmt->fetch()) {
                    $errorMessage = 'Username already exists';
                    $success = false;
                }
            }
            
            // Check if email already exists
            if ($success && !empty($newEmail)) {
                $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
                $stmt->execute([$newEmail, $userId]);
                
                if ($stmt->fetch()) {
                    $errorMessage = 'Email already exists';
                    $success = false;
                }
            }
            
            if ($success) {
                // Update username, email, full name, role, and status
                $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, full_name = ?, role = ?, status = ? WHERE id = ?");
                $stmt->execute([$newUsername, $newEmail, $newFullName, $newRole, $newStatus, $userId]);
                
                // Update password if provided
                if (!empty($newPassword) && strlen($newPassword) >= 6) {
                    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
                    $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
                    $stmt->execute([$hashedPassword, $userId]);
                }
                
                // Redirect to prevent form resubmission
                header('Location: ' . $_SERVER['PHP_SELF'] . '?message=User updated successfully!&type=success');
                exit;
            } else {
                // If there was an error, show it without redirecting
                $message = $errorMessage;
                $messageType = 'error';
            }
        }
        
        // Handle delete user
        if ($_POST['action'] === 'delete_user') {
            $userId = (int)$_POST['user_id'];
            
            $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
            if ($stmt->execute([$userId])) {
                // Redirect to prevent form resubmission
                header('Location: ' . $_SERVER['PHP_SELF'] . '?message=User deleted successfully!&type=success');
                exit;
            } else {
                $message = 'Failed to delete user';
                $messageType = 'error';
            }
        }
        
    } catch(PDOException $e) {
        $message = 'Database error: ' . $e->getMessage();
        $messageType = 'error';
    }
}

// Get filter and search parameters
$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';
$roleFilter = isset($_GET['role']) ? sanitize($_GET['role']) : '';
$statusFilter = isset($_GET['status']) ? sanitize($_GET['status']) : '';
$membershipFilter = isset($_GET['membership']) ? sanitize($_GET['membership']) : '';

// Build query
$query = "SELECT * FROM users WHERE 1=1";
$params = [];

if (!empty($search)) {
    $query .= " AND (username LIKE ? OR email LIKE ? OR full_name LIKE ?)";
    $searchParam = "%$search%";
    $params[] = $searchParam;
    $params[] = $searchParam;
    $params[] = $searchParam;
}

if (!empty($roleFilter)) {
    $query .= " AND role = ?";
    $params[] = $roleFilter;
}

if (!empty($statusFilter)) {
    $query .= " AND status = ?";
    $params[] = $statusFilter;
}

if ($membershipFilter === 'active') {
    $query .= " AND is_verified = 1 AND (membership_expires_at IS NULL OR membership_expires_at > NOW())";
} elseif ($membershipFilter === 'expired') {
    $query .= " AND is_verified = 1 AND membership_expires_at < NOW()";
} elseif ($membershipFilter === 'none') {
    $query .= " AND is_verified = 0";
}

$query .= " ORDER BY created_at DESC";

try {
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $users = $stmt->fetchAll();
} catch(PDOException $e) {
    die("Error fetching users: " . $e->getMessage());
}

// Get statistics
try {
    $totalUsers = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    $totalAdmins = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'admin'")->fetchColumn();
    $totalActive = $pdo->query("SELECT COUNT(*) FROM users WHERE status = 'active'")->fetchColumn();
    $totalMembers = $pdo->query("SELECT COUNT(*) FROM users WHERE is_verified = 1 AND (membership_expires_at IS NULL OR membership_expires_at > NOW())")->fetchColumn();
} catch(PDOException $e) {
    $totalUsers = 0;
    $totalAdmins = 0;
    $totalActive = 0;
    $totalMembers = 0;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users - Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: #f5f7fa;
}

.admin-header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    padding: 20px 0;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.admin-header-content {
    max-width: 1400px;
    margin: 0 auto;
    padding: 0 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.admin-logo {
    color: #fff;
    font-size: 24px;
    font-weight: bold;
}

.back-btn {
    color: #fff;
    text-decoration: none;
    background: rgba(255,255,255,0.2);
    padding: 10px 20px;
    border-radius: 8px;
    transition: all 0.3s;
    display: flex;
    align-items: center;
    gap: 8px;
}

.back-btn:hover {
    background: rgba(255,255,255,0.3);
}

.user-management {
    padding: 20px;
    max-width: 1400px;
    margin: 0 auto;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.stat-card {
    background: white;
    padding: 25px;
    border-radius: 12px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    display: flex;
    align-items: center;
    gap: 20px;
    transition: all 0.3s;
}

.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 5px 20px rgba(0,0,0,0.1);
}

.stat-icon {
    width: 60px;
    height: 60px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    color: white;
}

.stat-icon.users {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

.stat-icon.admins {
    background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
}

.stat-icon.active {
    background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
}

.stat-icon.members {
    background: linear-gradient(135deg, #FFD700 0%, #FFA500 100%);
}

.stat-info h3 {
    font-size: 28px;
    margin-bottom: 5px;
    color: #333;
}

.stat-info p {
    color: #666;
    font-size: 14px;
    margin: 0;
}

.filters-section {
    background: white;
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    margin-bottom: 20px;
}

.filters-form {
    display: grid;
    grid-template-columns: 2fr 1fr 1fr 1fr auto;
    gap: 15px;
    align-items: end;
}

.filter-group {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.filter-group label {
    font-size: 14px;
    font-weight: 600;
    color: #333;
}

.filter-group input,
.filter-group select {
    padding: 10px 15px;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    font-size: 14px;
    transition: all 0.3s;
}

.filter-group input:focus,
.filter-group select:focus {
    outline: none;
    border-color: #667eea;
}

.filter-btn {
    padding: 11px 25px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-weight: 600;
    transition: all 0.3s;
}

.filter-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(102,126,234,0.4);
}

.users-table-container {
    background: white;
    border-radius: 12px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    overflow: hidden;
}

.users-table {
    width: 100%;
    border-collapse: collapse;
}

.users-table thead {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

.users-table thead th {
    padding: 15px;
    text-align: left;
    color: white;
    font-weight: 600;
    font-size: 14px;
}

.users-table tbody td {
    padding: 15px;
    border-bottom: 1px solid #f0f0f0;
    font-size: 14px;
}

.users-table tbody tr:hover {
    background: #f8f9fa;
}

.user-avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: 600;
    font-size: 16px;
}

.user-info {
    display: flex;
    align-items: center;
    gap: 12px;
}

.user-details h4 {
    margin: 0 0 3px 0;
    font-size: 14px;
    color: #333;
}

.user-details p {
    margin: 0;
    font-size: 12px;
    color: #666;
}

.badge {
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
    display: inline-flex;
    align-items: center;
    gap: 5px;
}

.badge.admin {
    background: #fff3e0;
    color: #f57c00;
}

.badge.user {
    background: #e3f2fd;
    color: #1976d2;
}

.badge.active {
    background: #e8f5e9;
    color: #388e3c;
}

.badge.inactive {
    background: #ffebee;
    color: #d32f2f;
}

.badge.member {
    background: linear-gradient(135deg, #FFD700 0%, #FFA500 100%);
    color: white;
}

.badge.expired {
    background: #ffebee;
    color: #d32f2f;
}

.badge.no-membership {
    background: #f5f5f5;
    color: #999;
}

.badge.lifetime {
    background: linear-gradient(135deg, #FFD700 0%, #FF6B35 100%);
    color: white;
}

.membership-status {
    display: flex;
    flex-direction: column;
    gap: 5px;
}

.membership-expiry {
    font-size: 11px;
    color: #666;
}

.action-buttons {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}

.action-btn {
    padding: 8px 12px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-size: 12px;
    font-weight: 600;
    transition: all 0.3s;
    display: flex;
    align-items: center;
    gap: 5px;
}

.action-btn.edit {
    background: #e3f2fd;
    color: #1976d2;
}

.action-btn.edit:hover {
    background: #1976d2;
    color: white;
}

.action-btn.membership {
    background: #fff3e0;
    color: #f57c00;
}

.action-btn.membership:hover {
    background: #f57c00;
    color: white;
}

.action-btn.delete {
    background: #ffebee;
    color: #d32f2f;
}

.action-btn.delete:hover {
    background: #d32f2f;
    color: white;
}

.modal {
    display: none;
    position: fixed;
    z-index: 10000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.8);
    backdrop-filter: blur(5px);
}

.modal-content {
    background: white;
    margin: 5% auto;
    padding: 30px;
    border-radius: 12px;
    width: 90%;
    max-width: 500px;
    box-shadow: 0 10px 40px rgba(0,0,0,0.3);
    animation: slideDown 0.3s ease;
}

@keyframes slideDown {
    from {
        transform: translateY(-50px);
        opacity: 0;
    }
    to {
        transform: translateY(0);
        opacity: 1;
    }
}

.modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.modal-header h2 {
    color: #667eea;
    font-size: 22px;
}

.modal-close {
    background: none;
    border: none;
    font-size: 28px;
    color: #999;
    cursor: pointer;
    transition: all 0.3s;
}

.modal-close:hover {
    color: #667eea;
    transform: rotate(90deg);
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    margin-bottom: 8px;
    font-weight: 600;
    color: #333;
    font-size: 14px;
}

.form-group input,
.form-group select {
    width: 100%;
    padding: 12px 15px;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    font-size: 14px;
    transition: all 0.3s;
    box-sizing: border-box;
}

.form-group input:focus,
.form-group select:focus {
    outline: none;
    border-color: #667eea;
}

.modal-buttons {
    display: flex;
    gap: 10px;
    justify-content: flex-end;
}

.modal-btn {
    padding: 12px 25px;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-weight: 600;
    transition: all 0.3s;
}

.modal-btn.primary {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
}

.modal-btn.primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(102,126,234,0.4);
}

.modal-btn.secondary {
    background: #f0f0f0;
    color: #666;
}

.modal-btn.secondary:hover {
    background: #e0e0e0;
}

.modal-btn.danger {
    background: #ffebee;
    color: #d32f2f;
}

.modal-btn.danger:hover {
    background: #d32f2f;
    color: white;
}

.alert {
    padding: 15px 20px;
    border-radius: 8px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
    animation: slideDown 0.3s ease;
}

.alert.success {
    background: #e8f5e9;
    color: #388e3c;
    border-left: 4px solid #388e3c;
}

.alert.error {
    background: #ffebee;
    color: #d32f2f;
    border-left: 4px solid #d32f2f;
}

.membership-info-box {
    background: #f8f9fa;
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
    border-left: 4px solid #FFD700;
}

.membership-info-box h4 {
    margin: 0 0 10px 0;
    color: #333;
    font-size: 14px;
}

.membership-info-box p {
    margin: 0 0 5px 0;
    font-size: 13px;
    color: #666;
}

@media (max-width: 768px) {
    .stats-grid {
        grid-template-columns: 1fr;
    }
    
    .filters-form {
        grid-template-columns: 1fr;
    }
    
    .users-table-container {
        overflow-x: auto;
    }
    
    .action-buttons {
        flex-direction: column;
    }
}
</style>
</head>
<body>
    <header class="admin-header">
        <div class="admin-header-content">
            <div class="admin-logo">
                <i class="fas fa-users-cog"></i> Manage Website Users
            </div>
            <a href="settings.php" class="back-btn">
                <i class="fas fa-arrow-left"></i> Back to Settings
            </a>
        </div>
    </header>

<div class="user-management">
    <?php if ($message): ?>
        <div class="alert <?php echo $messageType; ?>">
            <i class="fas fa-<?php echo $messageType === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
            <span><?php echo htmlspecialchars($message); ?></span>
        </div>
    <?php endif; ?>
    
    <!-- Statistics -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon users">
                <i class="fas fa-users"></i>
            </div>
            <div class="stat-info">
                <h3><?php echo $totalUsers; ?></h3>
                <p>Total Users</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon admins">
                <i class="fas fa-user-shield"></i>
            </div>
            <div class="stat-info">
                <h3><?php echo $totalAdmins; ?></h3>
                <p>Admin Users</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon active">
                <i class="fas fa-check-circle"></i>
            </div>
            <div class="stat-info">
                <h3><?php echo $totalActive; ?></h3>
                <p>Active Users</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon members">
                <i class="fas fa-crown"></i>
            </div>
            <div class="stat-info">
                <h3><?php echo $totalMembers; ?></h3>
                <p>Active Members</p>
            </div>
        </div>
    </div>
    
    <!-- Filters -->
    <div class="filters-section">
        <form method="GET" class="filters-form">
            <div class="filter-group">
                <label>Search</label>
                <input type="text" name="search" placeholder="Search by username, email or name..." value="<?php echo htmlspecialchars($search); ?>">
            </div>
            
            <div class="filter-group">
                <label>Role</label>
                <select name="role">
                    <option value="">All Roles</option>
                    <option value="user" <?php echo $roleFilter === 'user' ? 'selected' : ''; ?>>User</option>
                    <option value="admin" <?php echo $roleFilter === 'admin' ? 'selected' : ''; ?>>Admin</option>
                </select>
            </div>
            
            <div class="filter-group">
                <label>Status</label>
                <select name="status">
                    <option value="">All Status</option>
                    <option value="active" <?php echo $statusFilter === 'active' ? 'selected' : ''; ?>>Active</option>
                    <option value="inactive" <?php echo $statusFilter === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                </select>
            </div>
            
            <div class="filter-group">
                <label>Membership</label>
                <select name="membership">
                    <option value="">All</option>
                    <option value="active" <?php echo $membershipFilter === 'active' ? 'selected' : ''; ?>>Active Members</option>
                    <option value="expired" <?php echo $membershipFilter === 'expired' ? 'selected' : ''; ?>>Expired</option>
                    <option value="none" <?php echo $membershipFilter === 'none' ? 'selected' : ''; ?>>No Membership</option>
                </select>
            </div>
            
            <button type="submit" class="filter-btn">
                <i class="fas fa-filter"></i> Filter
            </button>
        </form>
    </div>
    
    <!-- Users Table -->
    <div class="users-table-container">
        <table class="users-table">
            <thead>
                <tr>
                    <th>User</th>
                    <th>Role</th>
                    <th>Status</th>
                    <th>Membership</th>
                    <th>Registered</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): 
                    // Use the helper functions from config.php for more accurate status
                    $membershipStatus = getUserMembershipStatus($user['id']);
                    $membershipExpiry = getMembershipExpiryDate($user['id']);
                ?>
                <tr>
                    <td>
                        <div class="user-info">
                            <div class="user-avatar">
                                <?php echo strtoupper(substr($user['username'], 0, 1)); ?>
                            </div>
                            <div class="user-details">
                                <h4><?php echo htmlspecialchars($user['username']); ?></h4>
                                <p><?php echo htmlspecialchars($user['email']); ?></p>
                                <?php if (!empty($user['full_name'])): ?>
                                <p style="color: #999;"><?php echo htmlspecialchars($user['full_name']); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </td>
                    <td>
                        <span class="badge <?php echo $user['role']; ?>">
                            <?php echo ucfirst($user['role']); ?>
                        </span>
                    </td>
                    <td>
                        <span class="badge <?php echo $user['status']; ?>">
                            <?php echo ucfirst($user['status']); ?>
                        </span>
                    </td>
                    <td>
                        <div class="membership-status">
                            <?php if ($membershipStatus === 'lifetime'): ?>
                                <span class="badge lifetime">
                                    <i class="fas fa-infinity"></i> Lifetime
                                </span>
                            <?php elseif ($membershipStatus === 'active'): ?>
                                <span class="badge member">
                                    <i class="fas fa-crown"></i> Active
                                </span>
                                <span class="membership-expiry">
                                    Until: <?php echo date('M d, Y', strtotime($membershipExpiry)); ?>
                                </span>
                            <?php elseif ($membershipStatus === 'expired'): ?>
                                <span class="badge expired">
                                    <i class="fas fa-times-circle"></i> Expired
                                </span>
                                <span class="membership-expiry">
                                    <?php echo date('M d, Y', strtotime($membershipExpiry)); ?>
                                </span>
                            <?php else: ?>
                                <span class="badge no-membership">
                                    <i class="fas fa-minus-circle"></i> None
                                </span>
                            <?php endif; ?>
                        </div>
                    </td>
                    <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                    <td>
                        <div class="action-buttons">
                            <button class="action-btn edit" onclick='openEditModal(<?php echo json_encode($user); ?>)'>
                                <i class="fas fa-edit"></i> Edit
                            </button>
                            <button class="action-btn membership" onclick='openMembershipModal(<?php echo json_encode($user); ?>)'>
                                <i class="fas fa-crown"></i> Membership
                            </button>
                            <button class="action-btn delete" onclick="deleteUser(<?php echo $user['id']; ?>, '<?php echo htmlspecialchars($user['username'], ENT_QUOTES); ?>')">
                                <i class="fas fa-trash"></i> Delete
                            </button>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                
                <?php if (empty($users)): ?>
                <tr>
                    <td colspan="6" style="text-align: center; padding: 40px; color: #999;">
                        <i class="fas fa-users" style="font-size: 48px; margin-bottom: 15px; display: block;"></i>
                        No users found
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Edit User Modal -->
<div id="editModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2><i class="fas fa-user-edit"></i> Edit User</h2>
            <button class="modal-close" onclick="closeEditModal()">&times;</button>
        </div>
        
        <form method="POST" id="editForm">
            <input type="hidden" name="user_id" id="editUserId">
            <input type="hidden" name="action" value="update_user">
            
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="new_username" id="editUsername" required>
            </div>
            
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="new_email" id="editEmail" required>
            </div>
            
            <div class="form-group">
                <label>Full Name</label>
                <input type="text" name="new_full_name" id="editFullName">
            </div>
            
            <div class="form-group">
                <label>New Password (leave empty to keep current)</label>
                <input type="password" name="new_password" id="editPassword" placeholder="Enter new password (min 6 characters)">
            </div>
            
            <div class="form-group">
                <label>Role</label>
                <select name="new_role" id="editRole">
                    <option value="user">User</option>
                    <option value="admin">Admin</option>
                </select>
            </div>
            
            <div class="form-group">
                <label>Status</label>
                <select name="new_status" id="editStatus">
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                </select>
            </div>
            
            <div class="modal-buttons">
                <button type="button" class="modal-btn secondary" onclick="closeEditModal()">Cancel</button>
                <button type="submit" class="modal-btn primary">Save Changes</button>
            </div>
        </form>
    </div>
</div>

<!-- Membership Management Modal -->
<div id="membershipModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2><i class="fas fa-crown"></i> Manage Membership</h2>
            <button class="modal-close" onclick="closeMembershipModal()">&times;</button>
        </div>
        
        <div class="membership-info-box" id="currentMembershipInfo">
            <!-- Will be populated by JavaScript -->
        </div>
        
        <div id="membershipActions">
            <!-- Grant Membership Form -->
            <div id="grantMembershipForm" style="display: none;">
                <form method="POST">
                    <input type="hidden" name="user_id" id="grantUserId">
                    <input type="hidden" name="action" value="grant_membership">
                    
                    <div class="form-group">
                        <label>Membership Type</label>
                        <select name="membership_type" id="membershipType" onchange="toggleCustomDate()">
                            <option value="monthly">Monthly (1 Month)</option>
                            <option value="yearly">Yearly (1 Year)</option>
                            <option value="lifetime">Lifetime (Permanent)</option>
                            <option value="custom">Custom Date</option>
                        </select>
                    </div>
                    
                    <div class="form-group" id="customDateGroup" style="display: none;">
                        <label>Custom Expiry Date</label>
                        <input type="date" name="custom_date" id="customDate" min="<?php echo date('Y-m-d'); ?>">
                    </div>
                    
                    <div class="modal-buttons">
                        <button type="button" class="modal-btn secondary" onclick="closeMembershipModal()">Cancel</button>
                        <button type="submit" class="modal-btn primary">
                            <i class="fas fa-check"></i> Grant Membership
                        </button>
                    </div>
                </form>
            </div>
            
            <!-- Extend Membership Form -->
            <div id="extendMembershipForm" style="display: none;">
                <form method="POST">
                    <input type="hidden" name="user_id" id="extendUserId">
                    <input type="hidden" name="action" value="extend_membership">
                    
                    <div class="form-group">
                        <label>Extend By</label>
                        <select name="extend_type">
                            <option value="month">1 Month</option>
                            <option value="year">1 Year</option>
                            <option value="lifetime">Convert to Lifetime</option>
                        </select>
                    </div>
                    
                    <div class="modal-buttons">
                        <button type="button" class="modal-btn secondary" onclick="closeMembershipModal()">Cancel</button>
                        <button type="submit" class="modal-btn primary">
                            <i class="fas fa-plus"></i> Extend Membership
                        </button>
                    </div>
                </form>
            </div>
            
            <!-- Revoke Membership Form -->
            <div id="revokeMembershipForm" style="display: none;">
                <form method="POST">
                    <input type="hidden" name="user_id" id="revokeUserId">
                    <input type="hidden" name="action" value="revoke_membership">
                    
                    <p style="color: #d32f2f; margin-bottom: 20px;">
                        <i class="fas fa-exclamation-triangle"></i>
                        Are you sure you want to revoke this user's membership? This action will immediately remove all membership benefits.
                    </p>
                    
                    <div class="modal-buttons">
                        <button type="button" class="modal-btn secondary" onclick="closeMembershipModal()">Cancel</button>
                        <button type="submit" class="modal-btn danger">
                            <i class="fas fa-times"></i> Revoke Membership
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
// Edit User Modal Functions
function openEditModal(user) {
    document.getElementById('editUserId').value = user.id;
    document.getElementById('editUsername').value = user.username;
    document.getElementById('editEmail').value = user.email;
    document.getElementById('editFullName').value = user.full_name || '';
    document.getElementById('editPassword').value = '';
    document.getElementById('editRole').value = user.role;
    document.getElementById('editStatus').value = user.status;
    document.getElementById('editModal').style.display = 'block';
    document.body.style.overflow = 'hidden';
}

function closeEditModal() {
    document.getElementById('editModal').style.display = 'none';
    document.body.style.overflow = 'auto';
}

// Membership Modal Functions
function openMembershipModal(user) {
    const isMember = user.is_verified == 1;
    const membershipExpiry = user.membership_expires_at;
    const isLifetime = isMember && membershipExpiry === null;
    const isExpired = isMember && membershipExpiry !== null && new Date(membershipExpiry) < new Date();
    
    // Populate current membership info
    let infoHTML = '<h4>Current Membership Status</h4>';
    
    if (!isMember) {
        infoHTML += '<p><strong>Status:</strong> No Active Membership</p>';
    } else if (isLifetime) {
        infoHTML += '<p><strong>Status:</strong> <span style="color: #FFD700;">★ Lifetime Member</span></p>';
    } else if (isExpired) {
        infoHTML += '<p><strong>Status:</strong> <span style="color: #d32f2f;">Expired</span></p>';
        infoHTML += '<p><strong>Expired On:</strong> ' + formatDate(membershipExpiry) + '</p>';
    } else {
        infoHTML += '<p><strong>Status:</strong> <span style="color: #388e3c;">Active Member</span></p>';
        infoHTML += '<p><strong>Expires On:</strong> ' + formatDate(membershipExpiry) + '</p>';
        const daysLeft = Math.ceil((new Date(membershipExpiry) - new Date()) / (1000 * 60 * 60 * 24));
        infoHTML += '<p><strong>Days Remaining:</strong> ' + daysLeft + ' days</p>';
    }
    
    document.getElementById('currentMembershipInfo').innerHTML = infoHTML;
    
    // Show appropriate forms
    document.getElementById('grantMembershipForm').style.display = 'none';
    document.getElementById('extendMembershipForm').style.display = 'none';
    document.getElementById('revokeMembershipForm').style.display = 'none';
    
    if (!isMember || isExpired) {
        // Show grant form
        document.getElementById('grantUserId').value = user.id;
        document.getElementById('grantMembershipForm').style.display = 'block';
    } else {
        // Show extend and revoke options
        document.getElementById('extendUserId').value = user.id;
        document.getElementById('revokeUserId').value = user.id;
        document.getElementById('extendMembershipForm').style.display = 'block';
        
        // Add revoke button
        const extendForm = document.getElementById('extendMembershipForm');
        if (!document.getElementById('revokeBtn')) {
            const revokeBtn = document.createElement('button');
            revokeBtn.id = 'revokeBtn';
            revokeBtn.type = 'button';
            revokeBtn.className = 'modal-btn danger';
            revokeBtn.style.marginTop = '15px';
            revokeBtn.style.width = '100%';
            revokeBtn.innerHTML = '<i class="fas fa-times-circle"></i> Revoke Membership';
            revokeBtn.onclick = function() {
                document.getElementById('extendMembershipForm').style.display = 'none';
                document.getElementById('revokeMembershipForm').style.display = 'block';
            };
            extendForm.appendChild(revokeBtn);
        }
    }
    
    document.getElementById('membershipModal').style.display = 'block';
    document.body.style.overflow = 'hidden';
}

function closeMembershipModal() {
    document.getElementById('membershipModal').style.display = 'none';
    document.body.style.overflow = 'auto';
    
    // Remove revoke button if exists
    const revokeBtn = document.getElementById('revokeBtn');
    if (revokeBtn) {
        revokeBtn.remove();
    }
}

function toggleCustomDate() {
    const membershipType = document.getElementById('membershipType').value;
    const customDateGroup = document.getElementById('customDateGroup');
    
    if (membershipType === 'custom') {
        customDateGroup.style.display = 'block';
        document.getElementById('customDate').required = true;
    } else {
        customDateGroup.style.display = 'none';
        document.getElementById('customDate').required = false;
    }
}

function deleteUser(userId, username) {
    if (confirm(`Are you sure you want to delete user "${username}"? This action cannot be undone!`)) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = `
            <input type="hidden" name="action" value="delete_user">
            <input type="hidden" name="user_id" value="${userId}">
        `;
        document.body.appendChild(form);
        form.submit();
    }
}

function formatDate(dateString) {
    const date = new Date(dateString);
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return date.toLocaleDateString('en-US', options);
}

// Close modals when clicking outside
window.onclick = function(event) {
    const editModal = document.getElementById('editModal');
    const membershipModal = document.getElementById('membershipModal');
    
    if (event.target === editModal) {
        closeEditModal();
    }
    if (event.target === membershipModal) {
        closeMembershipModal();
    }
}

// Auto-hide alerts after 5 seconds
document.addEventListener('DOMContentLoaded', function() {
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            alert.style.opacity = '0';
            alert.style.transform = 'translateY(-20px)';
            setTimeout(function() {
                alert.remove();
            }, 300);
        }, 5000);
    });
});
</script>

</body>
</html>