<?php
require_once '../config.php';

if(!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if($id === 0) {
    $_SESSION['error'] = 'Invalid episode ID';
    header('Location: anime-list.php');
    exit;
}

// Get episode details with anime info
$stmt = $pdo->prepare("SELECT e.*, a.title as anime_title, a.id as anime_id 
                       FROM episodes e 
                       JOIN anime a ON e.anime_id = a.id 
                       WHERE e.id = ?");
$stmt->execute([$id]);
$episode = $stmt->fetch();

if(!$episode) {
    $_SESSION['error'] = 'Episode not found';
    header('Location: anime-list.php');
    exit;
}

// Get servers for this episode
$stmt = $pdo->prepare("SELECT * FROM servers WHERE episode_id = ? ORDER BY id ASC");
$stmt->execute([$id]);
$servers = $stmt->fetchAll();

// Get download links for this episode
$stmt = $pdo->prepare("SELECT * FROM download_links WHERE episode_id = ? ORDER BY link_order ASC, id ASC");
$stmt->execute([$id]);
$downloadLinks = $stmt->fetchAll();

$success = '';
$error = '';

// Check if this is a combined episode
$isCombined = !empty($episode['episode_letter']) && strpos($episode['episode_letter'], '-') === 0;
$episodeEnd = $isCombined ? ltrim($episode['episode_letter'], '-') : '';

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    if(isset($_POST['delete_episode'])) {
        try {
            $pdo->prepare("DELETE FROM episodes WHERE id = ?")->execute([$id]);
            $_SESSION['success'] = 'Episode deleted successfully!';
            header('Location: anime-list.php');
            exit;
        } catch(PDOException $e) {
            $error = 'Error deleting episode: ' . $e->getMessage();
        }
    } else {
        $episode_start = (int)$_POST['episode_start'];
        $episode_end_input = $_POST['episode_end'] ?? '';
        $episode_title = sanitize($_POST['episode_title']);
        $is_combined = isset($_POST['is_combined']) && $_POST['is_combined'] === '1';
        
        // Determine episode_letter based on combined status
        $episode_letter = '';
        if($is_combined && !empty($episode_end_input)) {
            $episode_end_num = (int)$episode_end_input;
            if($episode_end_num > $episode_start) {
                $episode_letter = '-' . $episode_end_num;
            }
        }
        
        // Update slug
        $anime_slug = createSlug($episode['anime_title']);
        if($is_combined && !empty($episode_end_input)) {
            $slug = $anime_slug . '-episode-' . $episode_start . '-' . $episode_end_input;
        } else {
            $slug = $anime_slug . '-episode-' . $episode_start;
        }
        
        // Servers data
        $server_ids = $_POST['server_id'] ?? [];
        $server_names = $_POST['server_name'] ?? [];
        $server_urls = $_POST['server_url'] ?? [];
        $server_qualities = $_POST['server_quality'] ?? [];
        
        // Download links data
        $download_ids = $_POST['download_id'] ?? [];
        $download_names = $_POST['download_name'] ?? [];
        $download_urls = $_POST['download_url'] ?? [];
        $download_qualities = $_POST['download_quality'] ?? [];
        $download_sizes = $_POST['download_size'] ?? [];
        
        if(count($server_names) === 0) {
            $error = 'Please add at least one server';
        } else {
            try {
                $pdo->beginTransaction();
                
                // Update episode
                $stmt = $pdo->prepare("UPDATE episodes SET episode_number = ?, episode_letter = ?, title = ?, slug = ? WHERE id = ?");
                $stmt->execute([$episode_start, $episode_letter, $episode_title, $slug, $id]);
                
                // Get existing server IDs
                $existingServers = array_column($servers, 'id');
                
                // Update existing servers and add new ones
                foreach($server_names as $index => $name) {
                    if(!empty($name) && !empty($server_urls[$index])) {
                        $server_id = $server_ids[$index] ?? null;
                        $is_default = ($index === 0) ? 1 : 0;
                        
                        if($server_id && in_array($server_id, $existingServers)) {
                            $stmt = $pdo->prepare("UPDATE servers SET server_name = ?, server_url = ?, quality = ?, is_default = ? WHERE id = ?");
                            $stmt->execute([
                                $name,
                                $server_urls[$index],
                                $server_qualities[$index] ?? '',
                                $is_default,
                                $server_id
                            ]);
                            $existingServers = array_diff($existingServers, [$server_id]);
                        } else {
                            $stmt = $pdo->prepare("INSERT INTO servers (episode_id, server_name, server_url, quality, is_default) VALUES (?, ?, ?, ?, ?)");
                            $stmt->execute([
                                $id,
                                $name,
                                $server_urls[$index],
                                $server_qualities[$index] ?? '',
                                $is_default
                            ]);
                        }
                    }
                }
                
                // Delete servers that were removed
                if(!empty($existingServers)) {
                    $placeholders = str_repeat('?,', count($existingServers) - 1) . '?';
                    $stmt = $pdo->prepare("DELETE FROM servers WHERE id IN ($placeholders)");
                    $stmt->execute(array_values($existingServers));
                }
                
                // Handle download links
                $existingDownloads = array_column($downloadLinks, 'id');
                
                foreach($download_names as $index => $name) {
                    if(!empty($name) && !empty($download_urls[$index])) {
                        $download_id = $download_ids[$index] ?? null;
                        
                        if($download_id && in_array($download_id, $existingDownloads)) {
                            $stmt = $pdo->prepare("UPDATE download_links SET link_name = ?, download_url = ?, quality = ?, file_size = ?, link_order = ? WHERE id = ?");
                            $stmt->execute([
                                $name,
                                $download_urls[$index],
                                $download_qualities[$index] ?? '',
                                $download_sizes[$index] ?? '',
                                $index,
                                $download_id
                            ]);
                            $existingDownloads = array_diff($existingDownloads, [$download_id]);
                        } else {
                            $stmt = $pdo->prepare("INSERT INTO download_links (episode_id, link_name, download_url, quality, file_size, link_order) VALUES (?, ?, ?, ?, ?, ?)");
                            $stmt->execute([
                                $id,
                                $name,
                                $download_urls[$index],
                                $download_qualities[$index] ?? '',
                                $download_sizes[$index] ?? '',
                                $index
                            ]);
                        }
                    }
                }
                
                // Delete download links that were removed
                if(!empty($existingDownloads)) {
                    $placeholders = str_repeat('?,', count($existingDownloads) - 1) . '?';
                    $stmt = $pdo->prepare("DELETE FROM download_links WHERE id IN ($placeholders)");
                    $stmt->execute(array_values($existingDownloads));
                }
                
                // Update anime update_date
                $pdo->prepare("UPDATE anime SET update_date = NOW() WHERE id = ?")->execute([$episode['anime_id']]);
                
                $pdo->commit();
                $success = 'Episode updated successfully!';
                
                // Refresh data
                $stmt = $pdo->prepare("SELECT e.*, a.title as anime_title, a.id as anime_id 
                                       FROM episodes e 
                                       JOIN anime a ON e.anime_id = a.id 
                                       WHERE e.id = ?");
                $stmt->execute([$id]);
                $episode = $stmt->fetch();
                
                // Recalculate combined status
                $isCombined = !empty($episode['episode_letter']) && strpos($episode['episode_letter'], '-') === 0;
                $episodeEnd = $isCombined ? ltrim($episode['episode_letter'], '-') : '';
                
                $stmt = $pdo->prepare("SELECT * FROM servers WHERE episode_id = ? ORDER BY id ASC");
                $stmt->execute([$id]);
                $servers = $stmt->fetchAll();
                
                $stmt = $pdo->prepare("SELECT * FROM download_links WHERE episode_id = ? ORDER BY link_order ASC, id ASC");
                $stmt->execute([$id]);
                $downloadLinks = $stmt->fetchAll();
            } catch(PDOException $e) {
                $pdo->rollBack();
                $error = 'Error: ' . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Episode - Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f7fa;
        }
        
        .admin-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .admin-header-content {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }
        
        .admin-logo {
            color: #fff;
            font-size: 24px;
            font-weight: bold;
        }
        
        .back-btn {
            color: #fff;
            text-decoration: none;
            background: rgba(255,255,255,0.2);
            padding: 10px 20px;
            border-radius: 8px;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .back-btn:hover {
            background: rgba(255,255,255,0.3);
        }
        
        .container {
            max-width: 1000px;
            margin: 30px auto;
            padding: 0 20px;
        }
        
        .form-card {
            background: #fff;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        }
        
        .form-card h2 {
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
            color: #333;
            flex-wrap: wrap;
        }
        
        .form-card h2 i {
            color: #667eea;
        }
        
        .anime-badge {
            display: inline-block;
            background: #f0f4ff;
            color: #667eea;
            padding: 8px 15px;
            border-radius: 8px;
            font-size: 14px;
            margin-bottom: 20px;
        }
        
        .alert {
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .alert.success {
            background: #d4edda;
            color: #155724;
        }
        
        .alert.error {
            background: #f8d7da;
            color: #721c24;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
            display: flex;
            align-items: center;
            gap: 8px;
            flex-wrap: wrap;
        }
        
        .form-group label i {
            color: #667eea;
        }
        
        .form-group label .optional {
            font-size: 12px;
            font-weight: 400;
            color: #999;
        }
        
        .form-group input,
        .form-group select {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 15px;
            transition: all 0.3s;
        }
        
        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 10px rgba(102,126,234,0.2);
        }
        
        .form-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
        }
        
        .episode-range {
            display: grid;
            grid-template-columns: 1fr auto 1fr;
            gap: 15px;
            align-items: end;
        }
        
        .episode-range .separator {
            padding-bottom: 12px;
            text-align: center;
            color: #999;
            font-weight: 600;
        }
        
        .combined-checkbox {
            background: #f0f4ff;
            border: 2px solid #667eea;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 20px;
        }
        
        .combined-checkbox label {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            font-weight: 600;
            color: #333;
        }
        
        .combined-checkbox input[type="checkbox"] {
            width: 20px;
            height: 20px;
            cursor: pointer;
        }
        
        .combined-checkbox .help-text {
            font-size: 13px;
            color: #666;
            margin-top: 8px;
            margin-left: 30px;
        }
        
        .servers-section,
        .downloads-section {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
        }
        
        .servers-section h3,
        .downloads-section h3 {
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
        }
        
        .server-item,
        .download-item {
            background: #fff;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 15px;
        }
        
        .item-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            flex-wrap: wrap;
            gap: 10px;
        }
        
        .item-header h4 {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .remove-btn {
            background: #ff4b5c;
            color: #fff;
            border: none;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s;
            flex-shrink: 0;
        }
        
        .remove-btn:hover {
            background: #ff3344;
            transform: scale(1.1);
        }
        
        .add-btn {
            background: linear-gradient(135deg, #4ECDC4 0%, #44A08D 100%);
            color: #fff;
            border: none;
            padding: 12px 25px;
            border-radius: 8px;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .add-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(78,205,196,0.4);
        }
        
        .btn {
            padding: 15px 35px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #fff;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(102,126,234,0.4);
        }
        
        .btn-danger {
            background: linear-gradient(135deg, #FF416C 0%, #FF4B2B 100%);
            margin-left: 10px;
        }
        
        .btn-danger:hover {
            box-shadow: 0 10px 25px rgba(255,65,108,0.4);
        }
        
        .downloads-section {
            background: #fff3e0;
            border: 2px solid #ffb74d;
        }
        
        .downloads-section h3 {
            color: #e65100;
        }
        
        .button-group {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        
        @media (max-width: 768px) {
            .admin-logo {
                font-size: 20px;
            }
            
            .form-card {
                padding: 20px 15px;
            }
            
            .form-card h2 {
                font-size: 20px;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .episode-range {
                grid-template-columns: 1fr;
            }
            
            .episode-range .separator {
                padding: 0;
                padding-bottom: 5px;
            }
            
            .btn {
                padding: 12px 25px;
                font-size: 14px;
                width: 100%;
                justify-content: center;
            }
            
            .btn-danger {
                margin-left: 0;
            }
            
            .add-btn {
                width: 100%;
                justify-content: center;
            }
            
            .button-group {
                flex-direction: column;
            }
        }
        
        @media (max-width: 480px) {
            .container {
                padding: 0 10px;
                margin: 20px auto;
            }
            
            .admin-header-content {
                padding: 0 10px;
            }
            
            .form-card {
                padding: 15px 10px;
            }
            
            .anime-badge {
                font-size: 12px;
                padding: 6px 12px;
            }
        }
    </style>
</head>
<body>
    <header class="admin-header">
        <div class="admin-header-content">
            <div class="admin-logo">
                <i class="fas fa-edit"></i> Edit Episode
            </div>
            <a href="anime-list.php" class="back-btn">
                <i class="fas fa-arrow-left"></i> Back to List
            </a>
        </div>
    </header>
    
    <div class="container">
        <div class="form-card">
            <h2><i class="fas fa-play-circle"></i> Edit Episode</h2>
            
            <div class="anime-badge">
                <i class="fas fa-film"></i> <?php echo htmlspecialchars($episode['anime_title']); ?> - 
                Episode <?php echo $episode['episode_number']; ?><?php echo $episode['episode_letter']; ?>
            </div>
            
            <?php if($success): ?>
                <div class="alert success">
                    <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                </div>
            <?php endif; ?>
            
            <?php if($error): ?>
                <div class="alert error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" id="episodeForm">
                <div class="episode-range">
                    <div class="form-group">
                        <label><i class="fas fa-hashtag"></i> Episode Start *</label>
                        <input type="number" name="episode_start" required min="1" value="<?php echo $episode['episode_number']; ?>" id="episodeStart">
                    </div>
                    
                    <div class="separator">to</div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-hashtag"></i> Episode End <span class="optional">(Optional)</span></label>
                        <input type="number" name="episode_end" min="1" value="<?php echo $episodeEnd; ?>" placeholder="Leave empty for single episode" id="episodeEnd">
                    </div>
                </div>
                
                <div class="combined-checkbox" id="combinedCheckboxContainer" style="<?php echo $isCombined || !empty($episodeEnd) ? 'display: block;' : 'display: none;'; ?>">
                    <label>
                        <input type="checkbox" name="is_combined" value="1" id="combinedCheckbox" <?php echo $isCombined ? 'checked' : ''; ?>>
                        <i class="fas fa-layer-group"></i> This is a Combined Episode
                    </label>
                    <div class="help-text">
                        <i class="fas fa-info-circle"></i> This will create ONE page with slug like "anime-title-episode-1-5"
                    </div>
                </div>
                
                <div class="form-group">
                    <label><i class="fas fa-heading"></i> Title <span class="optional">(Optional)</span></label>
                    <input type="text" name="episode_title" value="<?php echo htmlspecialchars($episode['title']); ?>">
                </div>
                
                <div class="servers-section">
                    <h3><i class="fas fa-server"></i> Video Servers</h3>
                    <div id="serversContainer">
                        <?php foreach($servers as $index => $server): ?>
                            <div class="server-item">
                                <div class="item-header">
                                    <h4><i class="fas fa-hdd"></i> Server <?php echo $index + 1; ?></h4>
                                    <?php if($index > 0): ?>
                                    <button type="button" class="remove-btn" onclick="removeServer(this)">
                                        <i class="fas fa-times"></i>
                                    </button>
                                    <?php endif; ?>
                                </div>
                                <input type="hidden" name="server_id[]" value="<?php echo $server['id']; ?>">
                                <div class="form-row">
                                    <div class="form-group">
                                        <label><i class="fas fa-tag"></i> Server Name *</label>
                                        <input type="text" name="server_name[]" required value="<?php echo htmlspecialchars($server['server_name']); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label><i class="fas fa-signal"></i> Quality</label>
                                        <input type="text" name="server_quality[]" value="<?php echo htmlspecialchars($server['quality']); ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label><i class="fas fa-link"></i> Video URL *</label>
                                    <input type="url" name="server_url[]" required value="<?php echo htmlspecialchars($server['server_url']); ?>">
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <button type="button" class="add-btn" onclick="addServer()">
                        <i class="fas fa-plus"></i> Add Another Server
                    </button>
                </div>
                
                <div class="downloads-section">
                    <h3><i class="fas fa-download"></i> Download Links <span class="optional" style="color: #999;">(Optional)</span></h3>
                    <div id="downloadsContainer">
                        <?php if(count($downloadLinks) > 0): ?>
                            <?php foreach($downloadLinks as $index => $link): ?>
                                <div class="download-item">
                                    <div class="item-header">
                                        <h4><i class="fas fa-cloud-download-alt"></i> Download Link <?php echo $index + 1; ?></h4>
                                        <button type="button" class="remove-btn" onclick="removeDownload(this)">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>
                                    <input type="hidden" name="download_id[]" value="<?php echo $link['id']; ?>">
                                    <div class="form-row">
                                        <div class="form-group">
                                            <label><i class="fas fa-tag"></i> Link Name</label>
                                            <input type="text" name="download_name[]" value="<?php echo htmlspecialchars($link['link_name']); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label><i class="fas fa-signal"></i> Quality</label>
                                            <input type="text" name="download_quality[]" value="<?php echo htmlspecialchars($link['quality']); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label><i class="fas fa-database"></i> File Size</label>
                                            <input type="text" name="download_size[]" value="<?php echo htmlspecialchars($link['file_size']); ?>">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label><i class="fas fa-link"></i> Download URL</label>
                                        <input type="url" name="download_url[]" value="<?php echo htmlspecialchars($link['download_url']); ?>">
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="download-item">
                                <div class="item-header">
                                    <h4><i class="fas fa-cloud-download-alt"></i> Download Link 1</h4>
                                    <button type="button" class="remove-btn" onclick="removeDownload(this)">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                                <input type="hidden" name="download_id[]" value="">
                                <div class="form-row">
                                    <div class="form-group">
                                        <label><i class="fas fa-tag"></i> Link Name</label>
                                        <input type="text" name="download_name[]" placeholder="e.g. Google Drive">
                                    </div>
                                    <div class="form-group">
                                        <label><i class="fas fa-signal"></i> Quality</label>
                                        <input type="text" name="download_quality[]" placeholder="e.g. 1080p">
                                    </div>
                                    <div class="form-group">
                                        <label><i class="fas fa-database"></i> File Size</label>
                                        <input type="text" name="download_size[]" placeholder="e.g. 500MB">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label><i class="fas fa-link"></i> Download URL</label>
                                    <input type="url" name="download_url[]" placeholder="https://...">
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                    <button type="button" class="add-btn" onclick="addDownload()">
                        <i class="fas fa-plus"></i> Add Another Download Link
                    </button>
                </div>
                
                <div class="button-group">
                    <button type="submit" class="btn">
                        <i class="fas fa-save"></i> Update Episode
                    </button>
                    
                    <button type="button" class="btn btn-danger" onclick="confirmDelete()">
                        <i class="fas fa-trash"></i> Delete Episode
                    </button>
                </div>
            </form>
            
            <form method="POST" id="deleteForm" style="display: none;">
                <input type="hidden" name="delete_episode" value="1">
            </form>
        </div>
    </div>
    
    <script>
        let serverCount = <?php echo max(count($servers), 1); ?>;
        let downloadCount = <?php echo max(count($downloadLinks), 1); ?>;
        
        // Show/hide combined checkbox based on episode range
        function updateCombinedCheckbox() {
            const startEp = parseInt(document.getElementById('episodeStart').value) || 0;
            const endEp = parseInt(document.getElementById('episodeEnd').value) || 0;
            const combinedContainer = document.getElementById('combinedCheckboxContainer');
            
            if(endEp > startEp) {
                combinedContainer.style.display = 'block';
            } else if(endEp === 0 || endEp === startEp) {
                combinedContainer.style.display = 'none';
                document.getElementById('combinedCheckbox').checked = false;
            }
        }
        
        document.getElementById('episodeStart').addEventListener('input', updateCombinedCheckbox);
        document.getElementById('episodeEnd').addEventListener('input', updateCombinedCheckbox);
        
        function addServer() {
            serverCount++;
            const container = document.getElementById('serversContainer');
            const serverHtml = `
                <div class="server-item">
                    <div class="item-header">
                        <h4><i class="fas fa-hdd"></i> Server ${serverCount}</h4>
                        <button type="button" class="remove-btn" onclick="removeServer(this)">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <input type="hidden" name="server_id[]" value="">
                    <div class="form-row">
                        <div class="form-group">
                            <label><i class="fas fa-tag"></i> Server Name *</label>
                            <input type="text" name="server_name[]" required>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-signal"></i> Quality</label>
                            <input type="text" name="server_quality[]">
                        </div>
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-link"></i> Video URL *</label>
                        <input type="url" name="server_url[]" required>
                    </div>
                </div>
            `;
            container.insertAdjacentHTML('beforeend', serverHtml);
        }
        
        function removeServer(btn) {
            if(document.querySelectorAll('.server-item').length > 1) {
                btn.closest('.server-item').remove();
            } else {
                alert('You must have at least one server!');
            }
        }
        
        function addDownload() {
            downloadCount++;
            const container = document.getElementById('downloadsContainer');
            const downloadHtml = `
                <div class="download-item">
                    <div class="item-header">
                        <h4><i class="fas fa-cloud-download-alt"></i> Download Link ${downloadCount}</h4>
                        <button type="button" class="remove-btn" onclick="removeDownload(this)">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <input type="hidden" name="download_id[]" value="">
                    <div class="form-row">
                        <div class="form-group">
                            <label><i class="fas fa-tag"></i> Link Name</label>
                            <input type="text" name="download_name[]" placeholder="e.g. Google Drive">
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-signal"></i> Quality</label>
                            <input type="text" name="download_quality[]" placeholder="e.g. 1080p">
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-database"></i> File Size</label>
                            <input type="text" name="download_size[]" placeholder="e.g. 500MB">
                        </div>
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-link"></i> Download URL</label>
                        <input type="url" name="download_url[]" placeholder="https://...">
                    </div>
                </div>
            `;
            container.insertAdjacentHTML('beforeend', downloadHtml);
        }
        
        function removeDownload(btn) {
            btn.closest('.download-item').remove();
        }
        
        function confirmDelete() {
            if(confirm('Are you sure you want to delete this episode? This action cannot be undone.')) {
                document.getElementById('deleteForm').submit();
            }
        }
    </script>
</body>
</html>