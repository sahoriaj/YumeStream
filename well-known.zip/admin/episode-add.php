<?php
require_once '../config.php';

if(!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

// Get all anime for dropdown
$animeList = $pdo->query("SELECT id, title FROM anime ORDER BY title ASC")->fetchAll();

$success = '';
$error = '';

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $anime_id = (int)$_POST['anime_id'];
    $episode_start = (int)$_POST['episode_start'];
    $episode_end = isset($_POST['episode_end']) && !empty($_POST['episode_end']) ? (int)$_POST['episode_end'] : $episode_start;
    $episode_title = sanitize($_POST['episode_title']);
    $combined = isset($_POST['combined']) && $_POST['combined'] === '1';
    
    // Validate range
    if($episode_end < $episode_start) {
        $error = 'End episode number cannot be less than start episode number';
    } else {
        // Get anime info
        $anime = $pdo->prepare("SELECT title, slug FROM anime WHERE id = ?");
        $anime->execute([$anime_id]);
        $anime = $anime->fetch();
        
        // Servers data
        $server_names = $_POST['server_name'] ?? [];
        $server_urls = $_POST['server_url'] ?? [];
        $server_qualities = $_POST['server_quality'] ?? [];
        
        // Download links data
        $download_names = $_POST['download_name'] ?? [];
        $download_urls = $_POST['download_url'] ?? [];
        $download_qualities = $_POST['download_quality'] ?? [];
        $download_sizes = $_POST['download_size'] ?? [];
        
        if(count($server_names) === 0) {
            $error = 'Please add at least one server';
        } else {
            try {
                $pdo->beginTransaction();
                
                if($combined && $episode_end > $episode_start) {
                    // Create ONE combined episode
                    $episode_range = $episode_start . '-' . $episode_end;
                    $slug = $anime['slug'] . '-episode-' . $episode_range;
                    
                    // Insert single combined episode
                    $stmt = $pdo->prepare("INSERT INTO episodes (anime_id, episode_number, episode_letter, title, slug) VALUES (?, ?, ?, ?, ?)");
                    $stmt->execute([$anime_id, $episode_start, '-' . $episode_end, $episode_title, $slug]);
                    $episode_id = $pdo->lastInsertId();
                    
                    // Insert servers for this combined episode
                    $serverStmt = $pdo->prepare("INSERT INTO servers (episode_id, server_name, server_url, quality, is_default) VALUES (?, ?, ?, ?, ?)");
                    foreach($server_names as $index => $name) {
                        if(!empty($name) && !empty($server_urls[$index])) {
                            $is_default = ($index === 0) ? 1 : 0;
                            $serverStmt->execute([
                                $episode_id,
                                $name,
                                $server_urls[$index],
                                $server_qualities[$index] ?? '',
                                $is_default
                            ]);
                        }
                    }
                    
                    // Insert download links
                    if(!empty($download_names)) {
                        $downloadStmt = $pdo->prepare("INSERT INTO download_links (episode_id, link_name, download_url, quality, file_size, link_order) VALUES (?, ?, ?, ?, ?, ?)");
                        foreach($download_names as $index => $name) {
                            if(!empty($name) && !empty($download_urls[$index])) {
                                $downloadStmt->execute([
                                    $episode_id,
                                    $name,
                                    $download_urls[$index],
                                    $download_qualities[$index] ?? '',
                                    $download_sizes[$index] ?? '',
                                    $index
                                ]);
                            }
                        }
                    }
                    
                    $success = "Successfully created combined episode: Episode $episode_range!";
                } else {
                    // Create SEPARATE episodes (original behavior)
                    for($ep_num = $episode_start; $ep_num <= $episode_end; $ep_num++) {
                        $slug = $anime['slug'] . '-episode-' . $ep_num;
                        
                        // Insert episode
                        $stmt = $pdo->prepare("INSERT INTO episodes (anime_id, episode_number, episode_letter, title, slug) VALUES (?, ?, ?, ?, ?)");
                        $stmt->execute([$anime_id, $ep_num, '', $episode_title, $slug]);
                        $episode_id = $pdo->lastInsertId();
                        
                        // Insert servers for this episode
                        $serverStmt = $pdo->prepare("INSERT INTO servers (episode_id, server_name, server_url, quality, is_default) VALUES (?, ?, ?, ?, ?)");
                        foreach($server_names as $index => $name) {
                            if(!empty($name) && !empty($server_urls[$index])) {
                                $is_default = ($index === 0) ? 1 : 0;
                                $serverStmt->execute([
                                    $episode_id,
                                    $name,
                                    $server_urls[$index],
                                    $server_qualities[$index] ?? '',
                                    $is_default
                                ]);
                            }
                        }
                        
                        // Insert download links for this episode
                        if(!empty($download_names)) {
                            $downloadStmt = $pdo->prepare("INSERT INTO download_links (episode_id, link_name, download_url, quality, file_size, link_order) VALUES (?, ?, ?, ?, ?, ?)");
                            foreach($download_names as $index => $name) {
                                if(!empty($name) && !empty($download_urls[$index])) {
                                    $downloadStmt->execute([
                                        $episode_id,
                                        $name,
                                        $download_urls[$index],
                                        $download_qualities[$index] ?? '',
                                        $download_sizes[$index] ?? '',
                                        $index
                                    ]);
                                }
                            }
                        }
                    }
                    
                    $episodes_added = ($episode_end - $episode_start + 1);
                    $success = $episodes_added > 1 ? "Successfully added episodes $episode_start to $episode_end!" : "Episode $episode_start added successfully!";
                }
                
                // Update anime update_date
                $pdo->prepare("UPDATE anime SET update_date = NOW() WHERE id = ?")->execute([$anime_id]);
                
                $pdo->commit();
                $_POST = array();
            } catch(PDOException $e) {
                $pdo->rollBack();
                $error = 'Error: ' . $e->getMessage();
            }
        }
    }
}

$selected_anime = $_GET['anime_id'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Episode - Admin</title>
    <link rel="stylesheet" href="https://unpkg.com/lucide@latest/dist/umd/lucide.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f7fa;
        }
        
        .admin-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .admin-header-content {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }
        
        .admin-logo {
            color: #fff;
            font-size: 24px;
            font-weight: bold;
        }
        
        .back-btn {
            color: #fff;
            text-decoration: none;
            background: rgba(255,255,255,0.2);
            padding: 10px 20px;
            border-radius: 8px;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .back-btn:hover {
            background: rgba(255,255,255,0.3);
        }
        
        .container {
            max-width: 1000px;
            margin: 30px auto;
            padding: 0 20px;
        }
        
        .form-card {
            background: #fff;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        }
        
        .form-card h2 {
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
            color: #333;
            flex-wrap: wrap;
        }
        
        .form-card h2 i {
            color: #667eea;
        }
        
        .alert {
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .alert.success {
            background: #d4edda;
            color: #155724;
        }
        
        .alert.error {
            background: #f8d7da;
            color: #721c24;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
            display: flex;
            align-items: center;
            gap: 8px;
            flex-wrap: wrap;
        }
        
        .form-group label i {
            color: #667eea;
        }
        
        .form-group label .optional {
            font-size: 12px;
            font-weight: 400;
            color: #999;
        }
        
        .form-group input,
        .form-group select {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 15px;
            transition: all 0.3s;
        }
        
        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 10px rgba(102,126,234,0.2);
        }
        
        .form-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
        }
        
        .episode-range {
            display: grid;
            grid-template-columns: 1fr auto 1fr;
            gap: 15px;
            align-items: end;
        }
        
        .episode-range .separator {
            padding-bottom: 12px;
            text-align: center;
            color: #999;
            font-weight: 600;
        }
        
        .combined-checkbox {
            background: #f0f4ff;
            border: 2px solid #667eea;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 20px;
        }
        
        .combined-checkbox label {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            font-weight: 600;
            color: #333;
        }
        
        .combined-checkbox input[type="checkbox"] {
            width: 20px;
            height: 20px;
            cursor: pointer;
        }
        
        .combined-checkbox .help-text {
            font-size: 13px;
            color: #666;
            margin-top: 8px;
            margin-left: 30px;
        }
        
        .servers-section,
        .downloads-section {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
        }
        
        .servers-section h3,
        .downloads-section h3 {
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
        }
        
        .server-item,
        .download-item {
            background: #fff;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 15px;
        }
        
        .item-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            flex-wrap: wrap;
            gap: 10px;
        }
        
        .item-header h4 {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .remove-btn {
            background: #ff4b5c;
            color: #fff;
            border: none;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s;
            flex-shrink: 0;
        }
        
        .remove-btn:hover {
            background: #ff3344;
            transform: scale(1.1);
        }
        
        .add-btn {
            background: linear-gradient(135deg, #4ECDC4 0%, #44A08D 100%);
            color: #fff;
            border: none;
            padding: 12px 25px;
            border-radius: 8px;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .add-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(78,205,196,0.4);
        }
        
        .btn {
            padding: 15px 35px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #fff;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            width: 100%;
            justify-content: center;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(102,126,234,0.4);
        }
        
        .info-box {
            background: #e3f2fd;
            border-left: 4px solid #2196f3;
            padding: 12px 15px;
            margin-bottom: 20px;
            border-radius: 5px;
            font-size: 14px;
            color: #1976d2;
        }
        
        .downloads-section {
            background: #fff3e0;
            border: 2px solid #ffb74d;
        }
        
        .downloads-section h3 {
            color: #e65100;
        }
        
        @media (max-width: 768px) {
            .admin-logo {
                font-size: 20px;
            }
            
            .form-card {
                padding: 20px 15px;
            }
            
            .form-card h2 {
                font-size: 20px;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .episode-range {
                grid-template-columns: 1fr;
            }
            
            .episode-range .separator {
                padding: 0;
                padding-bottom: 5px;
            }
            
            .btn {
                padding: 12px 25px;
                font-size: 14px;
            }
            
            .add-btn {
                width: 100%;
                justify-content: center;
            }
        }
        
        @media (max-width: 480px) {
            .container {
                padding: 0 10px;
                margin: 20px auto;
            }
            
            .admin-header-content {
                padding: 0 10px;
            }
            
            .form-card {
                padding: 15px 10px;
            }
        }
    </style>
</head>
<body>
    <header class="admin-header">
        <div class="admin-header-content">
            <div class="admin-logo">
                <i data-lucide="video"></i> Add New Episode
            </div>
            <a href="index.php" class="back-btn">
                <i data-lucide="arrow-left"></i> Back to Dashboard
            </a>
        </div>
    </header>
    
    <div class="container">
        <div class="form-card">
            <h2><i data-lucide="play-circle"></i> Episode Information</h2>
            
            <?php if($success): ?>
                <div class="alert success">
                    <i data-lucide="check-circle"></i> <?php echo $success; ?>
                </div>
            <?php endif; ?>
            
            <?php if($error): ?>
                <div class="alert error">
                    <i data-lucide="alert-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <div class="info-box">
                <i data-lucide="info"></i> <strong>Tip:</strong> Check "Combined Episode" to create a single page for multiple episodes (e.g., Episode 1-5 as one video)
            </div>
            
            <form method="POST" id="episodeForm">
                <div class="form-group">
                    <label><i data-lucide="film"></i> Select Anime *</label>
                    <select name="anime_id" required>
                        <option value="">-- Select Anime --</option>
                        <?php foreach($animeList as $anime): ?>
                            <option value="<?php echo $anime['id']; ?>" <?php echo $selected_anime == $anime['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($anime['title']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="episode-range">
                    <div class="form-group">
                        <label><i data-lucide="hash"></i> Episode Start *</label>
                        <input type="number" name="episode_start" required min="1" placeholder="e.g., 1">
                    </div>
                    
                    <div class="separator">to</div>
                    
                    <div class="form-group">
                        <label><i data-lucide="hash"></i> Episode End <span class="optional">(Optional)</span></label>
                        <input type="number" name="episode_end" min="1" placeholder="Leave empty for single episode" id="episodeEnd">
                    </div>
                </div>
                
                <div class="combined-checkbox" id="combinedCheckboxContainer" style="display: none;">
                    <label>
                        <input type="checkbox" name="combined" value="1" id="combinedCheckbox">
                        <i data-lucide="layers"></i> Create as Combined Episode
                    </label>
                    <div class="help-text">
                        <i data-lucide="info"></i> This will create ONE page with slug like "anime-title-episode-1-5" instead of 5 separate pages
                    </div>
                </div>
                
                <div class="form-group">
                    <label><i data-lucide="heading"></i> Title <span class="optional">(Optional)</span></label>
                    <input type="text" name="episode_title" placeholder="Episode title">
                </div>
                
                <div class="servers-section">
                    <h3><i data-lucide="server"></i> Video Servers</h3>
                    <div id="serversContainer">
                        <div class="server-item">
                            <div class="item-header">
                                <h4><i data-lucide="hard-drive"></i> Server 1</h4>
                            </div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label><i data-lucide="tag"></i> Server Name *</label>
                                    <input type="text" name="server_name[]" placeholder="e.g. Server 1" required>
                                </div>
                                <div class="form-group">
                                    <label><i data-lucide="signal"></i> Quality</label>
                                    <input type="text" name="server_quality[]" placeholder="e.g. 1080p">
                                </div>
                            </div>
                            <div class="form-group">
                                <label><i data-lucide="link"></i> Video URL *</label>
                                <input type="url" name="server_url[]" placeholder="https://..." required>
                            </div>
                        </div>
                    </div>
                    <button type="button" class="add-btn" onclick="addServer()">
                        <i data-lucide="plus"></i> Add Another Server
                    </button>
                </div>
                
                <div class="downloads-section">
                    <h3><i data-lucide="download"></i> Download Links <span class="optional" style="color: #999;">(Optional)</span></h3>
                    <div id="downloadsContainer">
                        <div class="download-item">
                            <div class="item-header">
                                <h4><i data-lucide="cloud-download"></i> Download Link 1</h4>
                                <button type="button" class="remove-btn" onclick="removeDownload(this)">
                                    <i data-lucide="x"></i>
                                </button>
                            </div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label><i data-lucide="tag"></i> Link Name</label>
                                    <input type="text" name="download_name[]" placeholder="e.g. Google Drive">
                                </div>
                                <div class="form-group">
                                    <label><i data-lucide="signal"></i> Quality</label>
                                    <input type="text" name="download_quality[]" placeholder="e.g. 1080p">
                                </div>
                                <div class="form-group">
                                    <label><i data-lucide="database"></i> File Size</label>
                                    <input type="text" name="download_size[]" placeholder="e.g. 500MB">
                                </div>
                            </div>
                            <div class="form-group">
                                <label><i data-lucide="link"></i> Download URL</label>
                                <input type="url" name="download_url[]" placeholder="https://...">
                            </div>
                        </div>
                    </div>
                    <button type="button" class="add-btn" onclick="addDownload()">
                        <i data-lucide="plus"></i> Add Another Download Link
                    </button>
                </div>
                
                <button type="submit" class="btn">
                    <i data-lucide="save"></i> Add Episode(s)
                </button>
            </form>
        </div>
    </div>
    
    <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.js"></script>
    <script>
        lucide.createIcons();
        
        let serverCount = 1;
        let downloadCount = 1;
        
        // Show/hide combined checkbox based on episode range
        document.getElementById('episodeEnd').addEventListener('input', function() {
            const startEp = parseInt(document.querySelector('input[name="episode_start"]').value) || 0;
            const endEp = parseInt(this.value) || 0;
            const combinedContainer = document.getElementById('combinedCheckboxContainer');
            
            if(endEp > startEp) {
                combinedContainer.style.display = 'block';
            } else {
                combinedContainer.style.display = 'none';
                document.getElementById('combinedCheckbox').checked = false;
            }
        });
        
        function addServer() {
            serverCount++;
            const container = document.getElementById('serversContainer');
            const serverHtml = `
                <div class="server-item">
                    <div class="item-header">
                        <h4><i data-lucide="hard-drive"></i> Server ${serverCount}</h4>
                        <button type="button" class="remove-btn" onclick="removeServer(this)">
                            <i data-lucide="x"></i>
                        </button>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label><i data-lucide="tag"></i> Server Name *</label>
                            <input type="text" name="server_name[]" placeholder="e.g. Server ${serverCount}" required>
                        </div>
                        <div class="form-group">
                            <label><i data-lucide="signal"></i> Quality</label>
                            <input type="text" name="server_quality[]" placeholder="e.g. 1080p">
                        </div>
                    </div>
                    <div class="form-group">
                        <label><i data-lucide="link"></i> Video URL *</label>
                        <input type="url" name="server_url[]" placeholder="https://..." required>
                    </div>
                </div>
            `;
            container.insertAdjacentHTML('beforeend', serverHtml);
            lucide.createIcons();
        }
        
        function removeServer(btn) {
            if(document.querySelectorAll('.server-item').length > 1) {
                btn.closest('.server-item').remove();
            } else {
                alert('You must have at least one server!');
            }
        }
        
        function addDownload() {
            downloadCount++;
            const container = document.getElementById('downloadsContainer');
            const downloadHtml = `
                <div class="download-item">
                    <div class="item-header">
                        <h4><i data-lucide="cloud-download"></i> Download Link ${downloadCount}</h4>
                        <button type="button" class="remove-btn" onclick="removeDownload(this)">
                            <i data-lucide="x"></i>
                        </button>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label><i data-lucide="tag"></i> Link Name</label>
                            <input type="text" name="download_name[]" placeholder="e.g. Google Drive">
                        </div>
                        <div class="form-group">
                            <label><i data-lucide="signal"></i> Quality</label>
                            <input type="text" name="download_quality[]" placeholder="e.g. 1080p">
                        </div>
                        <div class="form-group">
                            <label><i data-lucide="database"></i> File Size</label>
                            <input type="text" name="download_size[]" placeholder="e.g. 500MB">
                        </div>
                    </div>
                    <div class="form-group">
                        <label><i data-lucide="link"></i> Download URL</label>
                        <input type="url" name="download_url[]" placeholder="https://...">
                    </div>
                </div>
            `;
            container.insertAdjacentHTML('beforeend', downloadHtml);
            lucide.createIcons();
        }
        
        function removeDownload(btn) {
            btn.closest('.download-item').remove();
        }
    </script>
</body>
</html>