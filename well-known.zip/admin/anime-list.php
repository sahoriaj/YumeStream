<?php
require_once '../config.php';

if(!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

// Handle delete
if(isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    try {
        $pdo->prepare("DELETE FROM anime WHERE id = ?")->execute([$id]);
        $success = 'Anime deleted successfully!';
    } catch(PDOException $e) {
        $error = 'Error deleting anime: ' . $e->getMessage();
    }
}

// Pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$perPage = 20;
$offset = ($page - 1) * $perPage;

// Search
$search = $_GET['search'] ?? '';
$whereClause = '';
$params = [];

if($search) {
    $whereClause = "WHERE a.title LIKE ? OR a.zh_name LIKE ?";
    $params = ["%$search%", "%$search%"];
}

// Get total count
$countStmt = $pdo->prepare("SELECT COUNT(*) FROM anime a $whereClause");
$countStmt->execute($params);
$totalAnime = $countStmt->fetchColumn();
$totalPages = ceil($totalAnime / $perPage);

// Get anime list with proper GROUP BY
$stmt = $pdo->prepare("
    SELECT 
        a.id, 
        a.title, 
        a.slug, 
        a.zh_name, 
        a.poster, 
        a.status, 
        a.is_hot, 
        a.is_new, 
        a.update_date, 
        COUNT(e.id) as episode_count 
    FROM anime a 
    LEFT JOIN episodes e ON a.id = e.anime_id 
    $whereClause
    GROUP BY a.id, a.title, a.slug, a.zh_name, a.poster, a.status, 
             a.is_hot, a.is_new, a.update_date
    ORDER BY a.update_date DESC 
    LIMIT ? OFFSET ?
");
$stmt->execute(array_merge($params, [$perPage, $offset]));
$animeList = $stmt->fetchAll();

$page_title = 'Manage Anime - Admin';
require_once 'header.php';
?>

<style>
    .page-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 30px;
        flex-wrap: wrap;
        gap: 20px;
    }
    
    .page-header h1 {
        font-size: 32px;
        color: #333;
        display: flex;
        align-items: center;
        gap: 10px;
    }
    
    .page-header h1 i {
        color: #667eea;
    }
    
    .add-btn {
        background: linear-gradient(135deg, #4ECDC4 0%, #44A08D 100%);
        color: #fff;
        text-decoration: none;
        padding: 12px 25px;
        border-radius: 10px;
        display: flex;
        align-items: center;
        gap: 10px;
        font-weight: 600;
        transition: all 0.3s;
        box-shadow: 0 5px 15px rgba(78,205,196,0.3);
    }
    
    .add-btn:hover {
        transform: translateY(-3px);
        box-shadow: 0 10px 25px rgba(78,205,196,0.5);
    }
    
    .search-filter {
        background: #fff;
        padding: 20px;
        border-radius: 15px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        margin-bottom: 30px;
    }
    
    .search-box {
        display: flex;
        gap: 10px;
    }
    
    .search-box input {
        flex: 1;
        padding: 12px 20px;
        border: 2px solid #e0e0e0;
        border-radius: 10px;
        font-size: 15px;
    }
    
    .search-box input:focus {
        outline: none;
        border-color: #667eea;
    }
    
    .search-box button {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: #fff;
        border: none;
        padding: 12px 30px;
        border-radius: 10px;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 8px;
        font-weight: 600;
        transition: all 0.3s;
    }
    
    .search-box button:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(102,126,234,0.4);
    }
    
    .clear-btn {
        background: rgba(255,255,255,0.2);
        color: #fff;
        text-decoration: none;
        padding: 12px 20px;
        border-radius: 10px;
        display: flex;
        align-items: center;
        gap: 8px;
        transition: all 0.3s;
        border: 2px solid #e0e0e0;
        color: #666;
    }
    
    .clear-btn:hover {
        background: #f8f9fa;
        border-color: #667eea;
        color: #667eea;
    }
    
    .anime-table {
        background: #fff;
        border-radius: 15px;
        overflow: hidden;
        box-shadow: 0 5px 15px rgba(0,0,0,0.08);
    }
    
    table {
        width: 100%;
        border-collapse: collapse;
    }
    
    thead {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: #fff;
    }
    
    th {
        padding: 15px;
        text-align: left;
        font-weight: 600;
    }
    
    tbody tr {
        border-bottom: 1px solid #f0f0f0;
        transition: all 0.3s;
    }
    
    tbody tr:hover {
        background: #f8f9fa;
    }
    
    td {
        padding: 15px;
    }
    
    .anime-info {
        display: flex;
        align-items: center;
        gap: 15px;
    }
    
    .anime-thumb {
        width: 60px;
        height: 80px;
        border-radius: 8px;
        object-fit: cover;
        box-shadow: 0 2px 8px rgba(0,0,0,0.2);
    }
    
    .anime-details h4 {
        margin-bottom: 5px;
        color: #333;
        font-size: 14px;
    }
    
    .anime-details p {
        font-size: 13px;
        color: #666;
    }
    
    .badge {
        display: inline-block;
        padding: 5px 10px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 600;
        margin-right: 5px;
    }
    
    .badge.hot {
        background: #fee;
        color: #c33;
    }
    
    .badge.new {
        background: #efe;
        color: #3c3;
    }
    
    .badge.ongoing {
        background: #e3f2fd;
        color: #1976d2;
    }
    
    .badge.completed {
        background: #f3e5f5;
        color: #7b1fa2;
    }
    
    .action-btns {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
    }
    
    .action-btn {
        width: 35px;
        height: 35px;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.3s;
        text-decoration: none;
        color: #fff;
        font-size: 14px;
    }
    
    .action-btn.view {
        background: #2196f3;
    }
    
    .action-btn.edit {
        background: #ff9800;
    }
    
    .action-btn.episodes {
        background: #4caf50;
    }
    
    .action-btn.list {
        background: #9c27b0;
    }
    
    .action-btn.delete {
        background: #f44336;
    }
    
    .action-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 10px rgba(0,0,0,0.2);
    }
    
    .pagination {
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 10px;
        margin-top: 30px;
    }
    
    .pagination a,
    .pagination span {
        padding: 10px 15px;
        background: #fff;
        border-radius: 8px;
        text-decoration: none;
        color: #333;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        transition: all 0.3s;
        display: flex;
        align-items: center;
        gap: 5px;
    }
    
    .pagination a:hover {
        background: #667eea;
        color: #fff;
        transform: translateY(-2px);
    }
    
    .pagination .active {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: #fff;
        font-weight: 600;
    }
    
    .pagination .disabled {
        opacity: 0.5;
        cursor: not-allowed;
    }
    
    .empty-state {
        text-align: center;
        padding: 60px 20px;
    }
    
    .empty-state i {
        font-size: 64px;
        color: #ccc;
        margin-bottom: 20px;
    }
    
    .empty-state h3 {
        font-size: 24px;
        color: #666;
        margin-bottom: 10px;
    }
    
    .empty-state p {
        color: #999;
        margin-bottom: 20px;
    }
    
    /* Responsive table for mobile */
    @media (max-width: 1024px) {
        .page-header {
            flex-direction: column;
            align-items: stretch;
        }
        
        .page-header h1 {
            font-size: 24px;
        }
        
        .add-btn {
            width: 100%;
            justify-content: center;
        }
        
        /* Card layout for mobile */
        .anime-table table {
            display: none;
        }
        
        .anime-table .mobile-cards {
            display: block;
        }
        
        .anime-card {
            background: #fff;
            border-radius: 12px;
            padding: 15px;
            margin-bottom: 15px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }
        
        .anime-card-header {
            display: flex;
            gap: 15px;
            margin-bottom: 15px;
        }
        
        .anime-card-thumb {
            width: 80px;
            height: 110px;
            border-radius: 8px;
            object-fit: cover;
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
            flex-shrink: 0;
        }
        
        .anime-card-info {
            flex: 1;
            min-width: 0;
        }
        
        .anime-card-title {
            font-size: 16px;
            font-weight: 600;
            color: #333;
            margin-bottom: 5px;
            line-height: 1.3;
        }
        
        .anime-card-subtitle {
            font-size: 13px;
            color: #666;
            margin-bottom: 10px;
            line-height: 1.3;
        }
        
        .anime-card-meta {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .meta-item {
            display: flex;
            align-items: center;
            gap: 5px;
            font-size: 12px;
            color: #666;
        }
        
        .meta-item i {
            width: 16px;
            height: 16px;
        }
        
        .anime-card-actions {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 8px;
        }
        
        .anime-card .action-btn {
            width: 100%;
            height: 40px;
            font-size: 16px;
        }
        
        .search-box {
            flex-direction: column;
        }
        
        .search-box input,
        .search-box button,
        .clear-btn {
            width: 100%;
        }
    }
    
    @media (min-width: 1025px) {
        .anime-table .mobile-cards {
            display: none;
        }
    }
</style>

<div class="admin-container">
    <div class="page-header">
        <h1><i data-lucide="film"></i> All Anime (<?php echo $totalAnime; ?>)</h1>
        <a href="anime-add.php" class="add-btn">
            <i data-lucide="plus"></i> Add New Anime
        </a>
    </div>
    
    <?php if(isset($success)): ?>
        <div class="alert success">
            <i data-lucide="check-circle"></i> <?php echo $success; ?>
        </div>
    <?php endif; ?>
    
    <?php if(isset($error)): ?>
        <div class="alert error">
            <i data-lucide="alert-circle"></i> <?php echo $error; ?>
        </div>
    <?php endif; ?>
    
    <div class="search-filter">
        <form method="GET" class="search-box">
            <input type="text" name="search" placeholder="Search anime by title or Chinese name..." value="<?php echo htmlspecialchars($search); ?>">
            <button type="submit">
                <i data-lucide="search"></i> Search
            </button>
            <?php if($search): ?>
                <a href="anime-list.php" class="clear-btn">
                    <i data-lucide="x"></i> Clear
                </a>
            <?php endif; ?>
        </form>
    </div>
    
    <?php if(count($animeList) > 0): ?>
    <div class="anime-table">
        <!-- Desktop Table View -->
        <table>
            <thead>
                <tr>
                    <th>Anime</th>
                    <th>Status</th>
                    <th>Tags</th>
                    <th>Episodes</th>
                    <th>Updated</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($animeList as $anime): ?>
                <tr>
                    <td>
                        <div class="anime-info">
                            <img src="<?php echo getImageUrl($anime['poster'], 'uploads/default.jpg'); ?>" 
                                 alt="<?php echo htmlspecialchars($anime['title']); ?>" 
                                 class="anime-thumb"
                                 onerror="this.src='<?php echo SITE_URL; ?>/uploads/default.jpg'">
                            <div class="anime-details">
                                <h4><?php echo htmlspecialchars($anime['title']); ?></h4>
                                <?php if($anime['zh_name']): ?>
                                    <p><?php echo htmlspecialchars($anime['zh_name']); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </td>
                    <td>
                        <span class="badge <?php echo $anime['status']; ?>">
                            <?php echo ucfirst($anime['status']); ?>
                        </span>
                    </td>
                    <td>
                        <?php if($anime['is_hot']): ?>
                            <span class="badge hot"><i data-lucide="flame"></i> HOT</span>
                        <?php endif; ?>
                        <?php if($anime['is_new']): ?>
                            <span class="badge new"><i data-lucide="sparkles"></i> NEW</span>
                        <?php endif; ?>
                        <?php if(!$anime['is_hot'] && !$anime['is_new']): ?>
                            <span style="color: #999;">None</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <strong><?php echo $anime['episode_count']; ?></strong> episodes
                    </td>
                    <td>
                        <?php echo date('M d, Y', strtotime($anime['update_date'])); ?>
                    </td>
                    <td>
                        <div class="action-btns">
                            <a href="../anime/<?php echo $anime['slug']; ?>" 
                               target="_blank" 
                               class="action-btn view" 
                               title="View Anime">
                                <i data-lucide="eye"></i>
                            </a>
                            <a href="anime-edit.php?id=<?php echo $anime['id']; ?>" 
                               class="action-btn edit" 
                               title="Edit Anime">
                                <i data-lucide="edit"></i>
                            </a>
                            <a href="episodes-list.php?anime_id=<?php echo $anime['id']; ?>" 
                               class="action-btn list" 
                               title="Manage Episodes">
                                <i data-lucide="list"></i>
                            </a>
                            <a href="episode-add.php?anime_id=<?php echo $anime['id']; ?>" 
                               class="action-btn episodes" 
                               title="Add Episode">
                                <i data-lucide="plus"></i>
                            </a>
                            <button onclick="confirmDelete(<?php echo $anime['id']; ?>, '<?php echo htmlspecialchars(addslashes($anime['title'])); ?>')" 
                                    class="action-btn delete" 
                                    title="Delete">
                                <i data-lucide="trash-2"></i>
                            </button>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        
        <!-- Mobile Card View -->
        <div class="mobile-cards">
            <?php foreach($animeList as $anime): ?>
            <div class="anime-card">
                <div class="anime-card-header">
                    <img src="<?php echo getImageUrl($anime['poster'], 'uploads/default.jpg'); ?>" 
                         alt="<?php echo htmlspecialchars($anime['title']); ?>" 
                         class="anime-card-thumb"
                         onerror="this.src='<?php echo SITE_URL; ?>/uploads/default.jpg'">
                    <div class="anime-card-info">
                        <div class="anime-card-title"><?php echo htmlspecialchars($anime['title']); ?></div>
                        <?php if($anime['zh_name']): ?>
                            <div class="anime-card-subtitle"><?php echo htmlspecialchars($anime['zh_name']); ?></div>
                        <?php endif; ?>
                        <div style="margin-top: 8px;">
                            <span class="badge <?php echo $anime['status']; ?>">
                                <?php echo ucfirst($anime['status']); ?>
                            </span>
                            <?php if($anime['is_hot']): ?>
                                <span class="badge hot"><i data-lucide="flame"></i> HOT</span>
                            <?php endif; ?>
                            <?php if($anime['is_new']): ?>
                                <span class="badge new"><i data-lucide="sparkles"></i> NEW</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="anime-card-meta">
                    <div class="meta-item">
                        <i data-lucide="video"></i>
                        <span><strong><?php echo $anime['episode_count']; ?></strong> episodes</span>
                    </div>
                    <div class="meta-item">
                        <i data-lucide="calendar"></i>
                        <span><?php echo date('M d, Y', strtotime($anime['update_date'])); ?></span>
                    </div>
                </div>
                
                <div class="anime-card-actions">
                    <a href="../anime/<?php echo $anime['slug']; ?>" 
                       target="_blank" 
                       class="action-btn view" 
                       title="View">
                        <i data-lucide="eye"></i>
                    </a>
                    <a href="anime-edit.php?id=<?php echo $anime['id']; ?>" 
                       class="action-btn edit" 
                       title="Edit">
                        <i data-lucide="edit"></i>
                    </a>
                    <a href="episodes-list.php?anime_id=<?php echo $anime['id']; ?>" 
                       class="action-btn list" 
                       title="Episodes">
                        <i data-lucide="list"></i>
                    </a>
                    <a href="episode-add.php?anime_id=<?php echo $anime['id']; ?>" 
                       class="action-btn episodes" 
                       title="Add">
                        <i data-lucide="plus"></i>
                    </a>
                    <button onclick="confirmDelete(<?php echo $anime['id']; ?>, '<?php echo htmlspecialchars(addslashes($anime['title'])); ?>')" 
                            class="action-btn delete" 
                            title="Delete">
                        <i data-lucide="trash-2"></i>
                    </button>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    
    <?php if($totalPages > 1): ?>
    <div class="pagination">
        <?php if($page > 1): ?>
            <a href="?page=<?php echo $page - 1; ?><?php echo $search ? '&search='.urlencode($search) : ''; ?>">
                <i data-lucide="chevron-left"></i> Previous
            </a>
        <?php else: ?>
            <span class="disabled">
                <i data-lucide="chevron-left"></i> Previous
            </span>
        <?php endif; ?>
        
        <?php
        $start = max(1, $page - 2);
        $end = min($totalPages, $page + 2);
        
        for($i = $start; $i <= $end; $i++):
        ?>
            <a href="?page=<?php echo $i; ?><?php echo $search ? '&search='.urlencode($search) : ''; ?>" 
               class="<?php echo $i === $page ? 'active' : ''; ?>">
                <?php echo $i; ?>
            </a>
        <?php endfor; ?>
        
        <?php if($page < $totalPages): ?>
            <a href="?page=<?php echo $page + 1; ?><?php echo $search ? '&search='.urlencode($search) : ''; ?>">
                Next <i data-lucide="chevron-right"></i>
            </a>
        <?php else: ?>
            <span class="disabled">
                Next <i data-lucide="chevron-right"></i>
            </span>
        <?php endif; ?>
    </div>
    <?php endif; ?>
    
    <?php else: ?>
    <div class="anime-table">
        <div class="empty-state">
            <i data-lucide="inbox"></i>
            <h3>No Anime Found</h3>
            <p><?php echo $search ? 'No results for your search.' : 'Start by adding your first anime!'; ?></p>
            <a href="anime-add.php" class="add-btn">
                <i data-lucide="plus"></i> Add Your First Anime
            </a>
        </div>
    </div>
    <?php endif; ?>
</div>

<script>
    function confirmDelete(id, title) {
        if(confirm('Are you sure you want to delete "' + title + '"?\n\nThis will also delete all episodes and servers associated with this anime.')) {
            window.location.href = 'anime-list.php?delete=' + id;
        }
    }
</script>

<?php require_once 'footer.php'; ?>