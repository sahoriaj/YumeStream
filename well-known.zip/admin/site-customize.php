<?php
require_once '../config.php';

if(!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$success = '';
$error = '';

// Handle form submissions
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Update Logos
    if(isset($_POST['update_logos'])) {
        $header_logo = sanitize($_POST['header_logo']);
        $footer_logo = sanitize($_POST['footer_logo']);
        
        // Handle header logo upload
        if(isset($_FILES['header_logo_file']) && $_FILES['header_logo_file']['error'] === UPLOAD_ERR_OK) {
            $uploaded = uploadImageToCDN($_FILES['header_logo_file']);
            if($uploaded) {
                $header_logo = $uploaded;
            }
        }
        
        // Handle footer logo upload
        if(isset($_FILES['footer_logo_file']) && $_FILES['footer_logo_file']['error'] === UPLOAD_ERR_OK) {
            $uploaded = uploadImageToCDN($_FILES['footer_logo_file']);
            if($uploaded) {
                $footer_logo = $uploaded;
            }
        }
        
        setSiteSetting('header_logo', $header_logo);
        setSiteSetting('footer_logo', $footer_logo);
        $success = 'Logos updated successfully!';
    }
    
    // Update Header Menu
    if(isset($_POST['update_header_menu'])) {
        $menu_items = [];
        if(isset($_POST['menu_label']) && is_array($_POST['menu_label'])) {
            foreach($_POST['menu_label'] as $index => $label) {
                if(!empty($label) && !empty($_POST['menu_url'][$index])) {
                    $menu_items[] = [
                        'label' => sanitize($label),
                        'icon' => sanitize($_POST['menu_icon'][$index]),
                        'icon_type' => sanitize($_POST['menu_icon_type'][$index]),
                        'url' => sanitize($_POST['menu_url'][$index])
                    ];
                }
            }
        }
        setSiteSetting('header_menu', json_encode($menu_items));
        $success = 'Header menu updated successfully!';
    }
    
    // Update Footer Quick Links
    if(isset($_POST['update_footer_quick'])) {
        $menu_items = [];
        if(isset($_POST['quick_label']) && is_array($_POST['quick_label'])) {
            foreach($_POST['quick_label'] as $index => $label) {
                if(!empty($label) && !empty($_POST['quick_url'][$index])) {
                    $menu_items[] = [
                        'label' => sanitize($label),
                        'icon' => sanitize($_POST['quick_icon'][$index]),
                        'icon_type' => sanitize($_POST['quick_icon_type'][$index]),
                        'url' => sanitize($_POST['quick_url'][$index])
                    ];
                }
            }
        }
        setSiteSetting('footer_menu_quick', json_encode($menu_items));
        $success = 'Footer quick links updated successfully!';
    }
    
    // Update Footer Info Links
    if(isset($_POST['update_footer_info'])) {
        $menu_items = [];
        if(isset($_POST['info_label']) && is_array($_POST['info_label'])) {
            foreach($_POST['info_label'] as $index => $label) {
                if(!empty($label) && !empty($_POST['info_url'][$index])) {
                    $menu_items[] = [
                        'label' => sanitize($label),
                        'icon' => sanitize($_POST['info_icon'][$index]),
                        'icon_type' => sanitize($_POST['info_icon_type'][$index]),
                        'url' => sanitize($_POST['info_url'][$index])
                    ];
                }
            }
        }
        setSiteSetting('footer_menu_info', json_encode($menu_items));
        $success = 'Footer info links updated successfully!';
    }
    
    // Update Social Links
    if(isset($_POST['update_social'])) {
        setSiteSetting('social_facebook', sanitize($_POST['social_facebook']));
        setSiteSetting('social_twitter', sanitize($_POST['social_twitter']));
        setSiteSetting('social_telegram', sanitize($_POST['social_telegram']));
        setSiteSetting('social_discord', sanitize($_POST['social_discord']));
        $success = 'Social links updated successfully!';
    }
}

// Get current settings
$header_logo = getSiteSetting('header_logo');
$footer_logo = getSiteSetting('footer_logo');
$header_menu = getMenuItems('header_menu');
$footer_quick = getMenuItems('footer_menu_quick');
$footer_info = getMenuItems('footer_menu_info');
$social_links = [
    'facebook' => getSiteSetting('social_facebook'),
    'twitter' => getSiteSetting('social_twitter'),
    'telegram' => getSiteSetting('social_telegram'),
    'discord' => getSiteSetting('social_discord')
];

// Default icons for reference
$fontawesome_icons = ['fa-home', 'fa-list', 'fa-bookmark', 'fa-user', 'fa-cog', 'fa-info', 'fa-envelope', 'fa-star', 'fa-heart', 'fa-share', 'fa-search', 'fa-bell', 'fa-comment', 'fa-image', 'fa-video', 'fa-music', 'fa-gamepad', 'fa-download', 'fa-upload', 'fa-save'];
$lucide_icons = ['home', 'list', 'bookmark', 'user', 'settings', 'info', 'mail', 'star', 'heart', 'share-2', 'search', 'bell', 'message-circle', 'image', 'video', 'music', 'gamepad-2', 'download', 'upload', 'save'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Site Customization - Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.js"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f7fa; }
        
        .admin-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .admin-header-content {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .admin-logo {
            color: #fff;
            font-size: 24px;
            font-weight: bold;
        }
        
        .back-btn {
            color: #fff;
            text-decoration: none;
            background: rgba(255,255,255,0.2);
            padding: 10px 20px;
            border-radius: 8px;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .back-btn:hover { background: rgba(255,255,255,0.3); }
        
        .container { max-width: 1200px; margin: 30px auto; padding: 0 20px; }
        
        .settings-card {
            background: #fff;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            margin-bottom: 30px;
        }
        
        .settings-card h2 {
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
            color: #333;
            padding-bottom: 15px;
            border-bottom: 2px solid #f0f0f0;
        }
        
        .settings-card h2 i { color: #667eea; }
        
        .alert {
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .alert.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .form-group label i { color: #667eea; }
        
        .form-group input, .form-group select {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 15px;
            transition: all 0.3s;
        }
        
        .form-group input:focus, .form-group select:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 10px rgba(102,126,234,0.2);
        }
        
        .logo-preview {
            margin-top: 15px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 10px;
            text-align: center;
        }
        
        .logo-preview img {
            max-width: 200px;
            max-height: 80px;
            border-radius: 8px;
        }
        
        .btn {
            padding: 12px 30px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #fff;
            border: none;
            border-radius: 10px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(102,126,234,0.4);
        }
        
        .menu-item {
            display: grid;
            grid-template-columns: 40px 1fr 1fr 1fr 1fr 40px;
            gap: 10px;
            margin-bottom: 15px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 10px;
            align-items: center;
        }
        
        .menu-item input, .menu-item select {
            margin: 0;
        }
        
        .btn-remove {
            background: #dc3545;
            color: #fff;
            border: none;
            width: 35px;
            height: 35px;
            border-radius: 50%;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .btn-add {
            background: #28a745;
            margin-top: 10px;
        }
        
        .help-text {
            font-size: 13px;
            color: #666;
            margin-top: 5px;
        }
        
        .icon-select {
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .icon-preview {
            width: 35px;
            height: 35px;
            background: #667eea;
            color: #fff;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .icon-preview.lucide svg {
            width: 18px;
            height: 18px;
        }
        
        .cdn-badge {
            background: linear-gradient(135deg, #00c6ff 0%, #0072ff 100%);
            color: #fff;
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 600;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        
        .icon-type-badge {
            padding: 2px 8px;
            border-radius: 6px;
            font-size: 10px;
            font-weight: 600;
            text-transform: uppercase;
        }
        
        .icon-type-badge.fontawesome {
            background: #ff6b6b;
            color: white;
        }
        
        .icon-type-badge.lucide {
            background: #4ecdc4;
            color: white;
        }
        
        .icon-reference {
            margin-top: 20px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 10px;
            border-left: 4px solid #667eea;
        }
        
        .icon-reference h4 {
            margin-bottom: 10px;
            color: #333;
        }
        
        .icon-list {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 10px;
        }
        
        .icon-example {
            display: flex;
            align-items: center;
            gap: 5px;
            padding: 5px 10px;
            background: white;
            border-radius: 6px;
            font-size: 12px;
            border: 1px solid #e0e0e0;
        }
        
        @media (max-width: 1024px) {
            .menu-item {
                grid-template-columns: 1fr 1fr 1fr 1fr 1fr;
            }
        }
        
        @media (max-width: 768px) {
            .menu-item {
                grid-template-columns: 1fr;
            }
            .form-row {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <header class="admin-header">
        <div class="admin-header-content">
            <div class="admin-logo">
                <i class="fas fa-paint-brush"></i> Site Customization
            </div>
            <a href="settings.php" class="back-btn">
                <i class="fas fa-arrow-left"></i> Back to Settings
            </a>
        </div>
    </header>
    
    <div class="container">
        <?php if($success): ?>
            <div class="alert success">
                <i class="fas fa-check-circle"></i> <?php echo $success; ?>
            </div>
        <?php endif; ?>
        
        <?php if($error): ?>
            <div class="alert error">
                <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
            </div>
        <?php endif; ?>
        
        <!-- Logos Section -->
        <div class="settings-card">
            <h2><i class="fas fa-image"></i> Site Logos <span class="cdn-badge">CDN Supported</span></h2>
            <form method="POST" enctype="multipart/form-data">
                <div class="form-row">
                    <div>
                        <div class="form-group">
                            <label><i class="fas fa-arrow-up"></i> Header Logo URL</label>
                            <input type="url" name="header_logo" value="<?php echo htmlspecialchars($header_logo); ?>" placeholder="https://cdn.example.com/logo.png">
                            <div class="help-text">Enter logo URL or upload below</div>
                        </div>
                        
                        <div class="form-group">
                            <label><i class="fas fa-upload"></i> Or Upload Header Logo</label>
                            <input type="file" name="header_logo_file" accept="image/*">
                            <div class="help-text">Will be uploaded to CDN automatically</div>
                        </div>
                        
                        <?php if($header_logo): ?>
                        <div class="logo-preview">
                            <p style="margin-bottom: 10px; color: #666; font-size: 14px;">Current Header Logo:</p>
                            <img src="<?php echo htmlspecialchars($header_logo); ?>" alt="Header Logo">
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <div>
                        <div class="form-group">
                            <label><i class="fas fa-arrow-down"></i> Footer Logo URL</label>
                            <input type="url" name="footer_logo" value="<?php echo htmlspecialchars($footer_logo); ?>" placeholder="https://cdn.example.com/logo.png">
                            <div class="help-text">Enter logo URL or upload below</div>
                        </div>
                        
                        <div class="form-group">
                            <label><i class="fas fa-upload"></i> Or Upload Footer Logo</label>
                            <input type="file" name="footer_logo_file" accept="image/*">
                            <div class="help-text">Will be uploaded to CDN automatically</div>
                        </div>
                        
                        <?php if($footer_logo): ?>
                        <div class="logo-preview">
                            <p style="margin-bottom: 10px; color: #666; font-size: 14px;">Current Footer Logo:</p>
                            <img src="<?php echo htmlspecialchars($footer_logo); ?>" alt="Footer Logo">
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <button type="submit" name="update_logos" class="btn">
                    <i class="fas fa-save"></i> Update Logos
                </button>
            </form>
        </div>
        
        <!-- Header Menu Section -->
        <div class="settings-card">
            <h2><i class="fas fa-bars"></i> Header Navigation Menu</h2>
            <form method="POST" id="headerMenuForm">
                <div id="headerMenuItems">
                    <?php foreach($header_menu as $index => $item): ?>
                    <div class="menu-item">
                        <div class="icon-select">
                            <div class="icon-preview <?php echo $item['icon_type'] === 'lucide' ? 'lucide' : ''; ?>" data-icon-type="<?php echo htmlspecialchars($item['icon_type']); ?>" data-icon-name="<?php echo htmlspecialchars($item['icon']); ?>">
                                <?php if($item['icon_type'] === 'lucide'): ?>
                                    <i data-lucide="<?php echo htmlspecialchars($item['icon']); ?>"></i>
                                <?php else: ?>
                                    <i class="fas <?php echo htmlspecialchars($item['icon']); ?>"></i>
                                <?php endif; ?>
                            </div>
                        </div>
                        <input type="text" name="menu_label[]" placeholder="Menu Label" value="<?php echo htmlspecialchars($item['label']); ?>" required>
                        <input type="text" name="menu_icon[]" placeholder="home / fa-home" value="<?php echo htmlspecialchars($item['icon']); ?>" required>
                        <select name="menu_icon_type[]" required>
                            <option value="fontawesome" <?php echo ($item['icon_type'] ?? 'fontawesome') === 'fontawesome' ? 'selected' : ''; ?>>FontAwesome</option>
                            <option value="lucide" <?php echo ($item['icon_type'] ?? 'fontawesome') === 'lucide' ? 'selected' : ''; ?>>Lucide</option>
                        </select>
                        <input type="text" name="menu_url[]" placeholder="page.php" value="<?php echo htmlspecialchars($item['url']); ?>" required>
                        <button type="button" class="btn-remove" onclick="this.parentElement.remove()"><i class="fas fa-times"></i></button>
                    </div>
                    <?php endforeach; ?>
                </div>
                
                <button type="button" class="btn btn-add" onclick="addHeaderMenuItem()">
                    <i class="fas fa-plus"></i> Add Menu Item
                </button>
                
                <button type="submit" name="update_header_menu" class="btn">
                    <i class="fas fa-save"></i> Update Header Menu
                </button>
                
                <div class="icon-reference">
                    <h4><i class="fas fa-info-circle"></i> Icon Reference</h4>
                    <div class="help-text">Use either FontAwesome (fa-icon-name) or Lucide (icon-name) icons</div>
                    
                    <div class="icon-list">
                        <div class="icon-example">
                            <span class="icon-type-badge fontawesome">FA</span>
                            <span>fa-home, fa-user, fa-cog</span>
                        </div>
                        <div class="icon-example">
                            <span class="icon-type-badge lucide">Lucide</span>
                            <span>home, user, settings</span>
                        </div>
                    </div>
                    
                    <div class="icon-list">
                        <?php foreach(array_slice($fontawesome_icons, 0, 8) as $icon): ?>
                        <div class="icon-example">
                            <i class="fas <?php echo $icon; ?>"></i>
                            <span><?php echo $icon; ?></span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <div class="icon-list">
                        <?php foreach(array_slice($lucide_icons, 0, 8) as $icon): ?>
                        <div class="icon-example">
                            <i data-lucide="<?php echo $icon; ?>"></i>
                            <span><?php echo $icon; ?></span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </form>
        </div>
        
        <!-- Footer Quick Links Section -->
        <div class="settings-card">
            <h2><i class="fas fa-link"></i> Footer Quick Links</h2>
            <form method="POST" id="footerQuickForm">
                <div id="footerQuickItems">
                    <?php foreach($footer_quick as $index => $item): ?>
                    <div class="menu-item">
                        <div class="icon-select">
                            <div class="icon-preview <?php echo $item['icon_type'] === 'lucide' ? 'lucide' : ''; ?>" data-icon-type="<?php echo htmlspecialchars($item['icon_type']); ?>" data-icon-name="<?php echo htmlspecialchars($item['icon']); ?>">
                                <?php if($item['icon_type'] === 'lucide'): ?>
                                    <i data-lucide="<?php echo htmlspecialchars($item['icon']); ?>"></i>
                                <?php else: ?>
                                    <i class="fas <?php echo htmlspecialchars($item['icon']); ?>"></i>
                                <?php endif; ?>
                            </div>
                        </div>
                        <input type="text" name="quick_label[]" placeholder="Link Label" value="<?php echo htmlspecialchars($item['label']); ?>" required>
                        <input type="text" name="quick_icon[]" placeholder="home / fa-home" value="<?php echo htmlspecialchars($item['icon']); ?>" required>
                        <select name="quick_icon_type[]" required>
                            <option value="fontawesome" <?php echo ($item['icon_type'] ?? 'fontawesome') === 'fontawesome' ? 'selected' : ''; ?>>FontAwesome</option>
                            <option value="lucide" <?php echo ($item['icon_type'] ?? 'fontawesome') === 'lucide' ? 'selected' : ''; ?>>Lucide</option>
                        </select>
                        <input type="text" name="quick_url[]" placeholder="page.php" value="<?php echo htmlspecialchars($item['url']); ?>" required>
                        <button type="button" class="btn-remove" onclick="this.parentElement.remove()"><i class="fas fa-times"></i></button>
                    </div>
                    <?php endforeach; ?>
                </div>
                
                <button type="button" class="btn btn-add" onclick="addFooterQuickItem()">
                    <i class="fas fa-plus"></i> Add Quick Link
                </button>
                
                <button type="submit" name="update_footer_quick" class="btn">
                    <i class="fas fa-save"></i> Update Quick Links
                </button>
            </form>
        </div>
        
        <!-- Footer Info Links Section -->
        <div class="settings-card">
            <h2><i class="fas fa-info-circle"></i> Footer Information Links</h2>
            <form method="POST" id="footerInfoForm">
                <div id="footerInfoItems">
                    <?php foreach($footer_info as $index => $item): ?>
                    <div class="menu-item">
                        <div class="icon-select">
                            <div class="icon-preview <?php echo $item['icon_type'] === 'lucide' ? 'lucide' : ''; ?>" data-icon-type="<?php echo htmlspecialchars($item['icon_type']); ?>" data-icon-name="<?php echo htmlspecialchars($item['icon']); ?>">
                                <?php if($item['icon_type'] === 'lucide'): ?>
                                    <i data-lucide="<?php echo htmlspecialchars($item['icon']); ?>"></i>
                                <?php else: ?>
                                    <i class="fas <?php echo htmlspecialchars($item['icon']); ?>"></i>
                                <?php endif; ?>
                            </div>
                        </div>
                        <input type="text" name="info_label[]" placeholder="Link Label" value="<?php echo htmlspecialchars($item['label']); ?>" required>
                        <input type="text" name="info_icon[]" placeholder="shield / fa-shield-alt" value="<?php echo htmlspecialchars($item['icon']); ?>" required>
                        <select name="info_icon_type[]" required>
                            <option value="fontawesome" <?php echo ($item['icon_type'] ?? 'fontawesome') === 'fontawesome' ? 'selected' : ''; ?>>FontAwesome</option>
                            <option value="lucide" <?php echo ($item['icon_type'] ?? 'fontawesome') === 'lucide' ? 'selected' : ''; ?>>Lucide</option>
                        </select>
                        <input type="text" name="info_url[]" placeholder="page.php" value="<?php echo htmlspecialchars($item['url']); ?>" required>
                        <button type="button" class="btn-remove" onclick="this.parentElement.remove()"><i class="fas fa-times"></i></button>
                    </div>
                    <?php endforeach; ?>
                </div>
                
                <button type="button" class="btn btn-add" onclick="addFooterInfoItem()">
                    <i class="fas fa-plus"></i> Add Info Link
                </button>
                
                <button type="submit" name="update_footer_info" class="btn">
                    <i class="fas fa-save"></i> Update Info Links
                </button>
            </form>
        </div>
        
        <!-- Social Links Section -->
        <div class="settings-card">
            <h2><i class="fas fa-share-alt"></i> Social Media Links</h2>
            <form method="POST">
                <div class="form-row">
                    <div class="form-group">
                        <label><i class="fab fa-facebook"></i> Facebook URL</label>
                        <input type="url" name="social_facebook" value="<?php echo htmlspecialchars($social_links['facebook']); ?>" placeholder="https://www.facebook.com/yourpage">
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fab fa-twitter"></i> Twitter/X URL</label>
                        <input type="url" name="social_twitter" value="<?php echo htmlspecialchars($social_links['twitter']); ?>" placeholder="https://x.com/yourpage">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label><i class="fab fa-telegram"></i> Telegram URL</label>
                        <input type="url" name="social_telegram" value="<?php echo htmlspecialchars($social_links['telegram']); ?>" placeholder="https://t.me/yourchannel">
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fab fa-discord"></i> Discord URL</label>
                        <input type="url" name="social_discord" value="<?php echo htmlspecialchars($social_links['discord']); ?>" placeholder="https://discord.gg/yourserver">
                    </div>
                </div>
                
                <button type="submit" name="update_social" class="btn">
                    <i class="fas fa-save"></i> Update Social Links
                </button>
            </form>
        </div>
    </div>
    
    <script>
        // Initialize Lucide icons
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
        
        function updateIconPreview(element) {
            const iconType = element.querySelector('select[name$="icon_type[]"]').value;
            const iconName = element.querySelector('input[name$="icon[]"]').value;
            const preview = element.querySelector('.icon-preview');
            
            preview.className = 'icon-preview';
            preview.innerHTML = '';
            
            if (iconType === 'lucide') {
                preview.classList.add('lucide');
                const icon = document.createElement('i');
                icon.setAttribute('data-lucide', iconName);
                preview.appendChild(icon);
                if (typeof lucide !== 'undefined') {
                    lucide.createIcons();
                }
            } else {
                const icon = document.createElement('i');
                icon.className = 'fas ' + iconName;
                preview.appendChild(icon);
            }
            
            preview.setAttribute('data-icon-type', iconType);
            preview.setAttribute('data-icon-name', iconName);
        }
        
        function addHeaderMenuItem() {
            const container = document.getElementById('headerMenuItems');
            const item = document.createElement('div');
            item.className = 'menu-item';
            item.innerHTML = `
                <div class="icon-select">
                    <div class="icon-preview"><i class="fas fa-link"></i></div>
                </div>
                <input type="text" name="menu_label[]" placeholder="Menu Label" required>
                <input type="text" name="menu_icon[]" placeholder="home / fa-home" value="fa-link" required oninput="updateIconPreview(this.parentElement.parentElement)">
                <select name="menu_icon_type[]" required onchange="updateIconPreview(this.parentElement.parentElement)">
                    <option value="fontawesome" selected>FontAwesome</option>
                    <option value="lucide">Lucide</option>
                </select>
                <input type="text" name="menu_url[]" placeholder="page.php" required>
                <button type="button" class="btn-remove" onclick="this.parentElement.remove()"><i class="fas fa-times"></i></button>
            `;
            container.appendChild(item);
        }
        
        function addFooterQuickItem() {
            const container = document.getElementById('footerQuickItems');
            const item = document.createElement('div');
            item.className = 'menu-item';
            item.innerHTML = `
                <div class="icon-select">
                    <div class="icon-preview"><i class="fas fa-link"></i></div>
                </div>
                <input type="text" name="quick_label[]" placeholder="Link Label" required>
                <input type="text" name="quick_icon[]" placeholder="home / fa-home" value="fa-link" required oninput="updateIconPreview(this.parentElement.parentElement)">
                <select name="quick_icon_type[]" required onchange="updateIconPreview(this.parentElement.parentElement)">
                    <option value="fontawesome" selected>FontAwesome</option>
                    <option value="lucide">Lucide</option>
                </select>
                <input type="text" name="quick_url[]" placeholder="page.php" required>
                <button type="button" class="btn-remove" onclick="this.parentElement.remove()"><i class="fas fa-times"></i></button>
            `;
            container.appendChild(item);
        }
        
        function addFooterInfoItem() {
            const container = document.getElementById('footerInfoItems');
            const item = document.createElement('div');
            item.className = 'menu-item';
            item.innerHTML = `
                <div class="icon-select">
                    <div class="icon-preview"><i class="fas fa-link"></i></div>
                </div>
                <input type="text" name="info_label[]" placeholder="Link Label" required>
                <input type="text" name="info_icon[]" placeholder="shield / fa-shield-alt" value="fa-link" required oninput="updateIconPreview(this.parentElement.parentElement)">
                <select name="info_icon_type[]" required onchange="updateIconPreview(this.parentElement.parentElement)">
                    <option value="fontawesome" selected>FontAwesome</option>
                    <option value="lucide">Lucide</option>
                </select>
                <input type="text" name="info_url[]" placeholder="page.php" required>
                <button type="button" class="btn-remove" onclick="this.parentElement.remove()"><i class="fas fa-times"></i></button>
            `;
            container.appendChild(item);
        }
        
        // Initialize icon previews for existing items
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('.menu-item').forEach(item => {
                updateIconPreview(item);
            });
        });
    </script>
</body>
</html>