<?php
require_once 'config.php';
require_once 'auth.php';

header('Content-Type: application/json');

// Get action from request
$action = $_GET['action'] ?? $_POST['action'] ?? '';

// Check if user is logged in
if (!isLoggedIn() && !in_array($action, ['check_login'])) {
    echo json_encode(['success' => false, 'message' => 'Please login first']);
    exit;
}

$userId = $_SESSION['user_id'] ?? null;

switch($action) {
    
    // Check login status
    case 'check_login':
        echo json_encode([
            'success' => true,
            'logged_in' => isLoggedIn(),
            'user' => getCurrentUser()
        ]);
        break;
    
    // Track watch progress
    case 'track_watch':
        $episodeId = $_POST['episode_id'] ?? 0;
        $animeId = $_POST['anime_id'] ?? 0;
        $progress = $_POST['progress'] ?? 0;
        
        if (!$episodeId || !$animeId) {
            echo json_encode(['success' => false, 'message' => 'Invalid data']);
            exit;
        }
        
        try {
            // Check if record exists
            $stmt = $pdo->prepare("SELECT id FROM watch_history WHERE user_id = ? AND episode_id = ?");
            $stmt->execute([$userId, $episodeId]);
            $existing = $stmt->fetch();
            
            if ($existing) {
                // Update existing record
                $stmt = $pdo->prepare("UPDATE watch_history SET watch_progress = ?, last_watched = NOW() WHERE user_id = ? AND episode_id = ?");
                $stmt->execute([$progress, $userId, $episodeId]);
            } else {
                // Insert new record
                $stmt = $pdo->prepare("INSERT INTO watch_history (user_id, episode_id, anime_id, watch_progress) VALUES (?, ?, ?, ?)");
                $stmt->execute([$userId, $episodeId, $animeId, $progress]);
            }
            
            echo json_encode(['success' => true, 'message' => 'Watch progress saved']);
        } catch(PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        }
        break;
    

    
    // Get watch progress
    case 'get_progress':
        $episodeId = $_GET['episode_id'] ?? 0;
        
        if (!$episodeId) {
            echo json_encode(['success' => false, 'message' => 'Invalid episode ID']);
            exit;
        }
        
        try {
            $stmt = $pdo->prepare("SELECT watch_progress FROM watch_history WHERE user_id = ? AND episode_id = ?");
            $stmt->execute([$userId, $episodeId]);
            $result = $stmt->fetch();
            
            echo json_encode([
                'success' => true,
                'progress' => $result ? $result['watch_progress'] : 0
            ]);
        } catch(PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        }
        break;
    
    // Mark notification as read
    case 'mark_notification_read':
        $notificationId = $_POST['notification_id'] ?? 0;
        
        if (!$notificationId) {
            echo json_encode(['success' => false, 'message' => 'Invalid notification ID']);
            exit;
        }
        
        try {
            $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?");
            $stmt->execute([$notificationId, $userId]);
            
            echo json_encode(['success' => true, 'message' => 'Notification marked as read']);
        } catch(PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        }
        break;
    
    // Mark all notifications as read
    case 'mark_all_read':
        try {
            $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?");
            $stmt->execute([$userId]);
            
            echo json_encode(['success' => true, 'message' => 'All notifications marked as read']);
        } catch(PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        }
        break;
    
    // Get unread notification count
    case 'get_notification_count':
        try {
            $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0");
            $stmt->execute([$userId]);
            $result = $stmt->fetch();
            
            echo json_encode(['success' => true, 'count' => $result['count']]);
        } catch(PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        }
        break;
    
    // Toggle notification settings for followed anime
    case 'toggle_notifications':
        $animeId = $_POST['anime_id'] ?? 0;
        
        if (!$animeId) {
            echo json_encode(['success' => false, 'message' => 'Invalid anime ID']);
            exit;
        }
        
        try {
            $stmt = $pdo->prepare("UPDATE anime_follows SET notify_enabled = NOT notify_enabled WHERE user_id = ? AND anime_id = ?");
            $stmt->execute([$userId, $animeId]);
            
            // Get current status
            $stmt = $pdo->prepare("SELECT notify_enabled FROM anime_follows WHERE user_id = ? AND anime_id = ?");
            $stmt->execute([$userId, $animeId]);
            $result = $stmt->fetch();
            
            echo json_encode([
                'success' => true,
                'notify_enabled' => $result['notify_enabled'],
                'message' => $result['notify_enabled'] ? 'Notifications enabled' : 'Notifications disabled'
            ]);
        } catch(PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        }
        break;
    
    // Get user stats
    case 'get_user_stats':
        try {
            // Total anime watched
            $stmt = $pdo->prepare("SELECT COUNT(DISTINCT anime_id) as count FROM watch_history WHERE user_id = ?");
            $stmt->execute([$userId]);
            $animeWatched = $stmt->fetch()['count'];
            
            // Total episodes watched
            $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM watch_history WHERE user_id = ?");
            $stmt->execute([$userId]);
            $episodesWatched = $stmt->fetch()['count'];
            
            // Following count
            $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM anime_follows WHERE user_id = ?");
            $stmt->execute([$userId]);
            $following = $stmt->fetch()['count'];
            
            // Unread notifications
            $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0");
            $stmt->execute([$userId]);
            $unreadNotifications = $stmt->fetch()['count'];
            
            echo json_encode([
                'success' => true,
                'stats' => [
                    'anime_watched' => $animeWatched,
                    'episodes_watched' => $episodesWatched,
                    'following' => $following,
                    'unread_notifications' => $unreadNotifications
                ]
            ]);
        } catch(PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        }
        break;

    // Export user data
    case 'export_data':
        try {
            // Get watch history
            $stmt = $pdo->prepare("
                SELECT w.*, a.title, a.slug as anime_slug, a.poster, e.episode_number, e.slug as episode_slug
                FROM watch_history w
                JOIN episodes e ON w.episode_id = e.id
                JOIN anime a ON e.anime_id = a.id
                WHERE w.user_id = ?
                ORDER BY w.last_watched DESC
            ");
            $stmt->execute([$userId]);
            $watchHistory = $stmt->fetchAll();

            // Format watch history for export
            $formattedHistory = [];
            foreach ($watchHistory as $item) {
                $formattedHistory[] = [
                    'anime_id' => $item['anime_id'],
                    'anime_title' => $item['title'],
                    'anime_slug' => $item['anime_slug'],
                    'episode_id' => $item['episode_id'],
                    'episode_number' => $item['episode_number'],
                    'episode_slug' => $item['episode_slug'],
                    'progress' => $item['watch_progress'] ?? 0,
                    'watched_at' => $item['last_watched']
                ];
            }

            $response = [
                'success' => true,
                'data' => [
                    'watch_history' => $formattedHistory,
                    'export_date' => date('Y-m-d H:i:s'),
                    'total_entries' => count($formattedHistory)
                ]
            ];

            echo json_encode($response);

        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        break;

    // Import user data
    case 'import_data':
        try {
            // Get JSON input
            $input = file_get_contents('php://input');
            $data = json_decode($input, true);

            if (!$data || !isset($data['data']) || !isset($data['data']['watch_history'])) {
                throw new Exception('Invalid data format');
            }

            $watchHistory = $data['data']['watch_history'];
            $imported = [
                'watch_history' => 0,
                'skipped' => 0
            ];

            foreach ($watchHistory as $item) {
                try {
                    // Validate required fields
                    if (!isset($item['anime_id']) || !isset($item['episode_id'])) {
                        $imported['skipped']++;
                        continue;
                    }

                    // Check if anime exists
                    $checkAnime = $pdo->prepare("SELECT id FROM anime WHERE id = ?");
                    $checkAnime->execute([$item['anime_id']]);
                    if (!$checkAnime->fetch()) {
                        $imported['skipped']++;
                        continue;
                    }

                    // Check if episode exists
                    $checkEpisode = $pdo->prepare("SELECT id FROM episodes WHERE id = ? AND anime_id = ?");
                    $checkEpisode->execute([$item['episode_id'], $item['anime_id']]);
                    if (!$checkEpisode->fetch()) {
                        $imported['skipped']++;
                        continue;
                    }

                    // Check if watch history already exists
                    $checkHistory = $pdo->prepare("
                        SELECT id FROM watch_history 
                        WHERE user_id = ? AND episode_id = ? AND anime_id = ?
                    ");
                    $checkHistory->execute([$userId, $item['episode_id'], $item['anime_id']]);
                    $existing = $checkHistory->fetch();

                    if ($existing) {
                        // Update existing entry
                        $update = $pdo->prepare("
                            UPDATE watch_history 
                            SET watch_progress = ?, last_watched = ?
                            WHERE id = ?
                        ");
                        $update->execute([
                            $item['progress'] ?? 0,
                            $item['watched_at'] ?? date('Y-m-d H:i:s'),
                            $existing['id']
                        ]);
                    } else {
                        // Insert new entry
                        $insert = $pdo->prepare("
                            INSERT INTO watch_history 
                            (user_id, anime_id, episode_id, watch_progress, last_watched)
                            VALUES (?, ?, ?, ?, ?)
                        ");
                        $insert->execute([
                            $userId,
                            $item['anime_id'],
                            $item['episode_id'],
                            $item['progress'] ?? 0,
                            $item['watched_at'] ?? date('Y-m-d H:i:s')
                        ]);
                    }

                    $imported['watch_history']++;

                } catch (Exception $e) {
                    $imported['skipped']++;
                    continue;
                }
            }

            echo json_encode([
                'success' => true,
                'imported' => $imported,
                'message' => "Successfully imported {$imported['watch_history']} entries"
            ]);

        } catch (Exception $e) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        break;
    
    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
        break;
}
?>