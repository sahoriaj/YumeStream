<?php
require_once 'config.php';
require_once 'auth.php';

requireLogin();

$user = getCurrentUser();
$userId = $user['id'];

// Get current membership status
$membershipStatus = getUserMembershipStatus($userId);
$expiryDate = getMembershipExpiryDate($userId);

// Define plans matching payment.php (in INR)
$plans = [
    'monthly' => [
        'name' => 'Monthly Premium',
        'price' => 29,
        'duration' => '1 month',
        'icon' => 'calendar',
        'features' => ['No ads', 'HD quality', 'Watch history', 'Continue watching', 'Email notifications'],
        'is_featured' => false
    ],
    'quarterly' => [
        'name' => 'Quarterly Premium',
        'price' => 69,
        'duration' => '3 months',
        'icon' => 'calendar-days',
        'features' => ['No ads', 'HD quality', 'Watch history', 'Continue watching', 'Email notifications', 'Save 23%'],
        'is_featured' => true
    ],
    'semi_annually' => [
        'name' => 'Semi-Annual Premium',
        'price' => 99,
        'duration' => '6 months',
        'icon' => 'calendar-range',
        'features' => ['No ads', 'HD quality', 'Watch history', 'Continue watching', 'Email notifications', 'Verified badge', 'Save 43%'],
        'is_featured' => false
    ],
    'yearly' => [
        'name' => 'Yearly Premium',
        'price' => 149,
        'duration' => '1 year',
        'icon' => 'calendar-check',
        'features' => ['No ads', 'HD quality', 'Watch history', 'Continue watching', 'Email notifications', 'Verified badge', 'Custom frame', 'Save 57%'],
        'is_featured' => false
    ],
    'lifetime' => [
        'name' => 'Permanent Premium',
        'price' => 499,
        'duration' => 'Lifetime',
        'icon' => 'crown',
        'features' => ['No ads', 'HD quality', 'Watch history', 'Continue watching', 'Email notifications', 'Verified badge', 'Custom frame', 'Priority support', 'All future features'],
        'is_featured' => false
    ]
];

$page_title = 'Premium Membership';
require_once 'header.php';
?>

<div class="membership-hero">
    <h1><i data-lucide="crown"></i> Premium Membership</h1>
    <p>Unlock the ultimate anime streaming experience with ad-free viewing and exclusive features</p>
</div>

<div class="membership-container">
    <div class="current-status">
        <h2><i data-lucide="user"></i> Your Current Status</h2>
        <?php if ($membershipStatus === 'lifetime'): ?>
            <div class="status-badge lifetime">
                <i data-lucide="infinity"></i> Lifetime Premium Member
            </div>
            <p>You have lifetime access to all premium features!</p>
        <?php elseif ($membershipStatus === 'active'): ?>
            <div class="status-badge active">
                <i data-lucide="star"></i> Active Premium Member
            </div>
            <p>Your membership expires on: <strong><?php echo date('F d, Y', strtotime($expiryDate)); ?></strong></p>
        <?php elseif ($membershipStatus === 'expired'): ?>
            <div class="status-badge expired">
                <i data-lucide="alert-circle"></i> Membership Expired
            </div>
            <p>Your membership expired on: <strong><?php echo date('F d, Y', strtotime($expiryDate)); ?></strong></p>
            <p>Renew now to continue enjoying premium features!</p>
        <?php else: ?>
            <div class="status-badge free">
                <i data-lucide="user"></i> Free Member
            </div>
            <p>Upgrade to premium to unlock exclusive features and remove all ads!</p>
        <?php endif; ?>
    </div>
    
    <div class="pricing-grid">
        <?php foreach ($plans as $planKey => $plan): ?>
            <div class="pricing-card <?php echo $plan['is_featured'] ? 'featured' : ''; ?>">
                <div class="plan-header">
                    <div class="plan-icon">
                        <i data-lucide="<?php echo $plan['icon']; ?>"></i>
                    </div>
                    <div class="plan-name"><?php echo $plan['name']; ?></div>
                </div>
                
                <div class="plan-price">
                    ₹<?php echo number_format($plan['price']); ?>
                </div>
                <div class="plan-duration"><?php echo $plan['duration']; ?></div>
                
                <ul class="plan-features">
                    <?php 
                    $allFeatures = [
                        'No ads',
                        'HD quality',
                        'Watch history',
                        'Continue watching',
                        'Email notifications',
                        'Verified badge',
                        'Custom frame',
                        'Priority support',
                        'All future features'
                    ];
                    
                    foreach ($allFeatures as $feature): 
                        $included = in_array($feature, $plan['features']);
                    ?>
                        <li class="<?php echo !$included ? 'not-included' : ''; ?>">
                            <i data-lucide="<?php echo $included ? 'check-circle' : 'x-circle'; ?>"></i>
                            <span><?php echo $feature; ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>
                
                <a href="payment.php?plan=<?php echo $planKey; ?>" class="btn-purchase <?php echo $plan['is_featured'] ? 'featured' : ''; ?>">
                    <i data-lucide="shopping-cart"></i>
                    <?php echo $plan['price'] == 499 ? 'Get Permanent' : 'Get ' . $plan['duration']; ?>
                </a>
            </div>
        <?php endforeach; ?>
    </div>
    
    <div class="features-comparison">
        <h2><i data-lucide="table"></i> Feature Comparison</h2>
        <div class="comparison-table-wrapper">
            <table class="comparison-table">
                <thead>
                    <tr>
                        <th>Feature</th>
                        <?php foreach ($plans as $plan): ?>
                            <th><?php echo $plan['name']; ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $comparisonFeatures = [
                        ['icon' => 'ad', 'name' => 'Advertisements', 'free' => true, 'plans' => [false, false, false, false, false]],
                        ['icon' => 'hd-video', 'name' => 'HD Quality', 'free' => false, 'plans' => [true, true, true, true, true]],
                        ['icon' => 'history', 'name' => 'Watch History', 'free' => '7 days', 'plans' => ['Unlimited', 'Unlimited', 'Unlimited', 'Unlimited', 'Unlimited']],
                        ['icon' => 'play', 'name' => 'Continue Watching', 'free' => 'Limited', 'plans' => [true, true, true, true, true]],
                        ['icon' => 'badge-check', 'name' => 'Verified Badge', 'free' => false, 'plans' => [false, false, true, true, true]],
                        ['icon' => 'frame', 'name' => 'Custom Profile Frame', 'free' => false, 'plans' => [false, false, false, true, true]],
                        ['icon' => 'headset', 'name' => 'Priority Support', 'free' => false, 'plans' => [false, false, false, false, true]],
                        ['icon' => 'gift', 'name' => 'Future Features', 'free' => false, 'plans' => [false, false, false, false, true]]
                    ];
                    
                    foreach ($comparisonFeatures as $feature): 
                    ?>
                        <tr>
                            <td>
                                <i data-lucide="<?php echo $feature['icon']; ?>"></i>
                                <?php echo $feature['name']; ?>
                            </td>
                            <td>
                                <?php if (is_bool($feature['free']) && $feature['free']): ?>
                                    <i data-lucide="check" class="check-icon"></i>
                                <?php elseif (is_bool($feature['free']) && !$feature['free']): ?>
                                    <i data-lucide="x" class="cross-icon"></i>
                                <?php else: ?>
                                    <?php echo $feature['free']; ?>
                                <?php endif; ?>
                            </td>
                            <?php foreach ($feature['plans'] as $planFeature): ?>
                                <td>
                                    <?php if (is_bool($planFeature) && $planFeature): ?>
                                        <i data-lucide="check" class="check-icon"></i>
                                    <?php elseif (is_bool($planFeature) && !$planFeature): ?>
                                        <i data-lucide="x" class="cross-icon"></i>
                                    <?php else: ?>
                                        <?php echo $planFeature; ?>
                                    <?php endif; ?>
                                </td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
// Highlight current plan in comparison table
document.addEventListener('DOMContentLoaded', function() {
    const currentPlan = '<?php echo $membershipStatus; ?>';
    if (currentPlan && currentPlan !== 'free') {
        const table = document.querySelector('.comparison-table');
        if (table) {
            const headers = table.querySelectorAll('th');
            const planIndex = currentPlan === 'lifetime' ? 4 : 0; // Adjust based on actual plan position
            if (headers[planIndex + 1]) {
                headers[planIndex + 1].style.background = 'linear-gradient(135deg, #FFD700, #FFA500)';
                headers[planIndex + 1].style.color = '#000';
            }
        }
    }
});
</script>

<?php require_once 'footer.php'; ?>