<?php
require_once 'config.php';

$slug = $_GET['slug'] ?? '';

if(empty($slug)) {
    header('Location: index.php');
    exit;
}

// Get episode details
$stmt = $pdo->prepare("SELECT e.*, a.title as anime_title, a.slug as anime_slug 
                       FROM episodes e 
                       JOIN anime a ON e.anime_id = a.id 
                       WHERE e.slug = ?");
$stmt->execute([$slug]);
$episode = $stmt->fetch();

if(!$episode) {
    header('Location: index.php');
    exit;
}

// Get servers for this episode
$stmt = $pdo->prepare("SELECT * FROM servers WHERE episode_id = ? ORDER BY is_default DESC");
$stmt->execute([$episode['id']]);
$servers = $stmt->fetchAll();

// Get download links for this episode
$stmt = $pdo->prepare("SELECT * FROM download_links WHERE episode_id = ? ORDER BY link_order ASC, id ASC");
$stmt->execute([$episode['id']]);
$downloadLinks = $stmt->fetchAll();

// Get all episodes of this anime (DESC = latest first)
$stmt = $pdo->prepare("SELECT * FROM episodes WHERE anime_id = ? ORDER BY episode_number DESC");
$stmt->execute([$episode['anime_id']]);
$allEpisodes = $stmt->fetchAll();

// Find current index
$currentIndex = array_search($episode['id'], array_column($allEpisodes, 'id'));

// PREVIOUS = older episode
$prevEpisode = $currentIndex < count($allEpisodes) - 1
    ? $allEpisodes[$currentIndex + 1]
    : null;

// NEXT = newer episode
$nextEpisode = $currentIndex > 0
    ? $allEpisodes[$currentIndex - 1]
    : null;

// Display episode number with letter if available
$episodeDisplay = 'Episode ' . $episode['episode_number'];
if(!empty($episode['episode_letter'])) {
    $episodeDisplay .= $episode['episode_letter'];
}

// Get code injection settings
$before_player_code = getSiteSetting('before_player_code', '');
$after_player_code = getSiteSetting('after_player_code', '');

$page_title = $episode['anime_title'] . ' ' . $episodeDisplay . ' English Sub, Indo Sub [MULTISUB]';
// Remove any "- Yumestream" or site name concatenation
$canonical_url = "https://yumestream.in/watch.php?slug=" . htmlspecialchars($slug);

require_once 'header.php';
?>

<style>
/* React Lucide Icons Base Styles */
.lucide-icon {
    width: 1em;
    height: 1em;
    stroke: currentColor;
    stroke-width: 2;
    fill: none;
    stroke-linecap: round;
    stroke-linejoin: round;
}

/* Ensure proper spacing */
.player-section {
    background: #fff;
    overflow: hidden;
}

/* PLAYER WRAPPER (keeps aspect ratio) */
.player-wrapper {
  position: relative;
  width: 100%;
  overflow: hidden;
}

.player-wrapper::before {
  content: "";
  display: block;
  padding-top: 56.25%; /* 16:9 */
}

/* Lazy Player Container */
.lazy-player {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  cursor: pointer;
  overflow: hidden;
}

/* Blurred abstract background */
.blur-bg {
  position: absolute;
  inset: 0;
  background: linear-gradient(135deg, #050505, #111, #1b1b1b, #0f0f0f);
  filter: blur(15px);
  transform: scale(1.2);
  z-index: 1;
}

/* Play Button */
.lazy-player .play-btn {
  position: absolute;
  top: 50%;
  left: 50%;
  width: 70px;
  height: 70px;
  background: rgba(255,255,255,0.85);
  border-radius: 50%;
  transform: translate(-50%, -50%);
  z-index: 5;
}

.play-btn::before {
  content: '';
  position: absolute;
  top: 20px;
  left: 27px;
  border-style: solid;
  border-width: 15px 0 15px 24px;
  border-color: transparent transparent transparent #000;
}

.player-info {
    padding: 20px;
}

/* Server Notice */
.server-notice {
    background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
    border: 2px solid #3498db;
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 25px;
    box-shadow: 0 5px 15px rgba(52, 152, 219, 0.2);
}

.notice-title {
    font-size: 16px;
    color: #3498db;
    margin-bottom: 10px;
    font-weight: 500;
}

.anime-highlight {
    color: #3498db;
    font-weight: 600;
    text-decoration: underline;
}

.notice-message {
    font-size: 15px;
    color: #e74c3c;
    margin: 0;
    font-weight: 600;
}

/* Server Selector */
.server-selector {
    margin-bottom: 25px;
}

.server-selector h3 {
    font-size: 16px;
    margin-bottom: 12px;
    display: flex;
    align-items: center;
    gap: 8px;
    color: #222;
    font-weight: 600;
}

.server-selector h3 .lucide-icon {
    color: #667eea;
}

.servers {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: 12px;
}

.server-btn {
    padding: 10px 20px;
    background: #f8f9fa;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    font-weight: 500;
    border: none;
    color: #000;
}

.server-btn:hover {
    background: #667eea;
    color: #fff;
}

.server-btn.active {
    background: linear-gradient(45deg, red, #000);
    color: #fff;
    border-color: #667eea;
}

/* Navigation Buttons */
.navigation-btns {
    display: flex;
    gap: 15px;
    justify-content: space-between;
}

.nav-btn {
    flex: 1;
    padding: 15px;
    background: linear-gradient(45deg, red, #000);
    color: #fff;
    text-decoration: none;
    border-radius: 10px;
    text-align: center;
    font-weight: 600;
    transition: all 0.3s;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    box-shadow: 0 5px 15px rgba(102,126,234,0.3);
}

.nav-btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 25px rgba(102,126,234,0.5);
}

.nav-btn.disabled {
    opacity: 0.5;
    pointer-events: none;
}

/* Episodes Sidebar */
.episodes-sidebar {
    background: #fff;
    border-radius: 15px;
    padding: 20px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.1);
    height: fit-content;
    max-height: calc(100vh - 100px);
    overflow: hidden;
    display: flex;
    flex-direction: column;
}

.sidebar-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 15px;
    padding-bottom: 15px;
    border-bottom: 2px solid #f0f0f0;
}

.sidebar-header h3 {
    font-size: 18px;
    display: flex;
    align-items: center;
    gap: 8px;
}

.sidebar-header .lucide-icon {
    color: #667eea;
}

.drawer-toggle {
    background: crimson;
    color: #fff;
    border: none;
    width: 35px;
    height: 35px;
    border-radius: 8px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 16px;
    transition: all 0.3s ease;
    box-shadow: 0 0 10px rgba(220, 20, 60, 0.5);
}

.drawer-toggle:hover {
    background: #ff002b;
    transform: rotate(180deg) scale(1.1);
    box-shadow: 0 0 15px rgba(255, 0, 43, 0.8);
}

.drawer-toggle:active {
    transform: scale(0.95);
    background: #b3001b;
}

/* Episode Search */
.episode-search {
    margin-bottom: 15px;
}

.episode-search input {
    width: 100%;
    padding: 10px 15px;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    font-size: 14px;
}

.episode-search input:focus {
    outline: none;
    border-color: #667eea;
}

/* Episode List */
.episodes-list {
    max-height: 260px; /* fits about 4 episodes */
    overflow-y: auto;
    flex: 1;
    padding-right: 10px;
}

.episodes-list::-webkit-scrollbar {
    width: 6px;
}

.episodes-list::-webkit-scrollbar-thumb {
    background: #667eea;
    border-radius: 3px;
}

.episode-item {
    padding: 12px 15px;
    background: #f8f9fa;
    margin-bottom: 10px;
    border-radius: 8px;
    text-decoration: none;
    color: #333;
    display: flex;
    align-items: center;
    gap: 10px;
    transition: all 0.3s;
    cursor: pointer;
}

.episode-item:hover {
    background: #667eea;
    color: #fff;
    transform: translateX(5px);
}

.episode-item.active {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: #fff;
    font-weight: 600;
    box-shadow: 0 3px 10px rgba(102,126,234,0.4);
}

.episode-item .lucide-icon {
    width: 14px;
    height: 14px;
}

.drawer-collapsed .episodes-list,
.drawer-collapsed .episode-search {
    display: none;
}

/* Breadcrumb */
.breadcrumb {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 5px;
    font-size: 15px;
    background: #fff;
    color: #333;
    padding: 12px 20px;
    border-radius: 8px;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
    margin-bottom: 25px;
    transition: background 0.4s ease, color 0.4s ease, box-shadow 0.4s ease;
}

.breadcrumb a {
    color: #3455db;
    text-decoration: none;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 2px;
    transition: color 0.3s ease;
}

.breadcrumb a:hover {
    color: #4a3ab8;
}

.breadcrumb .lucide-icon {
    color: #555;
    width: 13px;
    height: 13px;
}

.breadcrumb span {
    color: #444;
    font-weight: 500;
}

/* Player Overlay */
.player-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(135deg, rgba(0,0,0,0.95) 0%, rgba(20,20,40,0.95) 100%);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 10;
    transition: opacity 0.3s ease;
}

.player-overlay.hidden {
    opacity: 0;
    pointer-events: none;
}

.overlay-content {
    text-align: center;
    color: #fff;
}

.loading-spinner {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 20px;
}

.spinner {
    width: 60px;
    height: 60px;
    border: 4px solid rgba(255,255,255,0.1);
    border-top: 4px solid #667eea;
    border-radius: 50%;
    animation: spin 1s linear infinite;
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

.loading-spinner p {
    font-size: 16px;
    color: #ccc;
    margin: 0;
}

.overlay-controls {
    position: absolute;
    top: 20px;
    left: 20px;
    right: 20px;
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    z-index: 11;
}

.control-info h4 {
    margin: 0 0 5px 0;
    color: #fff;
    font-size: 18px;
    text-shadow: 0 2px 10px rgba(0,0,0,0.5);
}

.control-info p {
    margin: 0;
    color: #ccc;
    font-size: 14px;
    text-shadow: 0 2px 10px rgba(0,0,0,0.5);
}

/* Download Section */
.download-section {
    margin-top: 25px;
    margin-bottom: 25px;
}

.download-section h3 {
    font-size: 16px;
    margin-bottom: 12px;
    display: flex;
    align-items: center;
    gap: 8px;
    color: #222;
    font-weight: 600;
}

.download-section h3 .lucide-icon {
    color: #00cc66;
}

.download-links-grid {
    display: flex;
    gap: 12px;
    flex-wrap: wrap;
    align-items: center;
}

.download-btn {
    padding: 10px 25px;
    background: linear-gradient(135deg, #00ff9d, #0066ff);
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    font-weight: 600;
    border: none;
    color: #fff;
    box-shadow: 0 0 10px rgba(0,255,157,0.4);
    min-width: 150px;
}

.download-btn:hover {
    transform: translateY(-2px);
    background: linear-gradient(135deg, #00cc80, #0044cc);
}

/* Dark Mode */

body {
    background: #fff;
    color: #333;
}

body.dark-mode {
    background: #0c0c0c;
    color: #e0e0e0;
}

body.dark-mode .player-section,
body.dark-mode .episodes-sidebar {
    background: linear-gradient(45deg, #1a0033, #000);
    box-shadow: 0 0 20px rgba(0, 255, 157, 0.15);
}

body.dark-mode .server-notice {
    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
    border: 2px solid #00ff9d;
    box-shadow: 0 5px 15px rgba(0, 255, 157, 0.2);
}

body.dark-mode .notice-title {
    color: #00ff9d;
}

body.dark-mode .anime-highlight {
    color: #00ff9d;
}

body.dark-mode .notice-message {
    color: #ff6b6b;
}

body.dark-mode .sidebar-header h3 {
    color: #fff;
}

body.dark-mode .sidebar-header .lucide-icon,
body.dark-mode .server-selector h3 .lucide-icon {
    color: #00ff9d;
}

body.dark-mode .server-btn {
    background: rgba(255,255,255,0.05);
    border: 1px solid rgba(255,255,255,0.1);
    color: #ddd;
}

body.dark-mode .server-btn:hover {
    background: #00ff9d;
    color: #000;
    border-color: #00ff9d;
}

body.dark-mode .server-btn.active {
    background: linear-gradient(135deg, #00ff9d 0%, #0066ff 100%);
    border-color: #00ff9d;
    box-shadow: 0 5px 15px rgba(0,255,157,0.3);
}

body.dark-mode .nav-btn {
    background: linear-gradient(135deg, #00ff9d 0%, #0066ff 100%);
    box-shadow: 0 5px 15px rgba(0,255,157,0.3);
}

body.dark-mode .nav-btn:hover {
    box-shadow: 0 10px 25px rgba(0,255,157,0.5);
}

body.dark-mode .episode-item {
    background: rgba(255,255,255,0.05);
    color: #eee;
}

body.dark-mode .episode-item:hover {
    background: #00ff9d;
    color: #000;
}

body.dark-mode .episode-item.active {
    background: linear-gradient(135deg, #00ff9d 0%, #0066ff 100%);
    color: #fff;
}

body.dark-mode .episode-search input {
    background: rgba(255,255,255,0.05);
    border: 1px solid rgba(255,255,255,0.1);
    color: #fff;
}

body.dark-mode .drawer-toggle {
    background: #111;
    color: crimson;
    border: 2px solid crimson;
    box-shadow: 0 0 10px rgba(220, 20, 60, 0.4);
}

body.dark-mode .drawer-toggle:hover {
    background: crimson;
    color: #fff;
    border-color: #fff;
    transform: rotate(180deg);
    box-shadow: 0 0 15px crimson;
}

body.dark-mode .breadcrumb {
    background: linear-gradient(45deg, #1a0033, #000);
    color: #eee;
    box-shadow: 0 5px 20px rgba(0, 255, 157, 0.15);
}

body.dark-mode .breadcrumb a {
    color: #00ff9d;
}

body.dark-mode .breadcrumb a:hover {
    color: #00c3ff;
}

body.dark-mode .breadcrumb .lucide-icon {
    color: #00ff9d;
}

body.dark-mode .breadcrumb span {
    color: #ccc;
}

body.dark-mode .player-overlay {
    background: linear-gradient(135deg, rgba(0,0,0,0.97) 0%, rgba(10,0,30,0.97) 100%);
}

body.dark-mode .spinner {
    border-top-color: #00ff9d;
}

body.dark-mode .server-selector h3 {
    color: #fff;
}

body.dark-mode .server-selector h3 .lucide-icon {
    color: #00ff9d;
}

body.dark-mode .download-section h3 {
    color: #fff;
}

body.dark-mode .download-section h3 .lucide-icon {
    color: #00ff9d;
}

body.dark-mode .download-btn {
    background: linear-gradient(135deg, #00ff9d, #0066ff);
    color: #fff;
    border: 1px solid rgba(255,255,255,0.1);
}

body.dark-mode .download-btn:hover {
    background: linear-gradient(135deg, #00ff9d, #0044cc);
}

/* Responsive */
@media (max-width: 1024px) {
    .watch-container {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 768px) {
    .control-info h4 {
        font-size: 14px;
    }
    
    .control-info p {
        font-size: 12px;
    }
    
    .overlay-controls {
        top: 10px;
        left: 10px;
        right: 10px;
    }
    
    .download-links-grid {
        flex-wrap: wrap;
        justify-content: center;
    }
    
    .download-btn {
        flex: 1 1 45%;
        min-width: 130px;
    }
}

/* Login Modal Styles */
.login-modal {
    display: none;
    position: fixed;
    z-index: 10000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.8);
    backdrop-filter: blur(5px);
}

.login-modal-content {
    background: #fff;
    margin: 5% auto;
    padding: 40px;
    border-radius: 15px;
    width: 90%;
    max-width: 450px;
    box-shadow: 0 10px 40px rgba(0,0,0,0.3);
    animation: slideDown 0.3s ease;
    position: relative;
}

@keyframes slideDown {
    from {
        transform: translateY(-50px);
        opacity: 0;
    }
    to {
        transform: translateY(0);
        opacity: 1;
    }
}

.login-modal-header {
    text-align: center;
    margin-bottom: 25px;
}

.login-modal-header h2 {
    color: #667eea;
    font-size: 24px;
    margin-bottom: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
}

.login-modal-header p {
    color: #666;
    font-size: 14px;
}

.login-modal-close {
    position: absolute;
    right: 20px;
    top: 20px;
    font-size: 28px;
    font-weight: bold;
    color: #999;
    cursor: pointer;
    transition: all 0.3s;
}

.login-modal-close:hover {
    color: #667eea;
    transform: rotate(90deg);
}

.login-modal-buttons {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.modal-btn {
    padding: 14px;
    border-radius: 8px;
    text-decoration: none;
    text-align: center;
    font-weight: 600;
    font-size: 15px;
    transition: all 0.3s;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
}

.modal-btn-primary {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: #fff;
    box-shadow: 0 5px 20px rgba(102,126,234,0.3);
}

.modal-btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(102,126,234,0.5);
}

.modal-btn-secondary {
    background: #f8f9fa;
    color: #667eea;
    border: 2px solid #667eea;
}

.modal-btn-secondary:hover {
    background: #667eea;
    color: #fff;
}

/* Notification Styles */
.notification {
    position: fixed;
    top: 20px;
    right: 20px;
    background: #fff;
    padding: 15px 20px;
    border-radius: 8px;
    box-shadow: 0 5px 25px rgba(0,0,0,0.2);
    display: flex;
    align-items: center;
    gap: 12px;
    z-index: 10001;
    transform: translateX(400px);
    transition: transform 0.3s ease;
    min-width: 250px;
}

.notification.show {
    transform: translateX(0);
}

.notification-success {
    border-left: 4px solid #00cc66;
}

.notification-success .lucide-icon {
    color: #00cc66;
    width: 20px;
    height: 20px;
}

.notification-info {
    border-left: 4px solid #667eea;
}

.notification-info .lucide-icon {
    color: #667eea;
    width: 20px;
    height: 20px;
}

.notification span {
    color: #333;
    font-weight: 500;
    font-size: 14px;
}

/* Dark Mode Styles */
body.dark-mode .login-modal-content {
    background: linear-gradient(45deg, #1a0033, #000);
    border: 1px solid rgba(0,255,157,0.2);
}

body.dark-mode .login-modal-header h2 {
    color: #00ff9d;
}

body.dark-mode .login-modal-header p {
    color: #ccc;
}

body.dark-mode .login-modal-close {
    color: #999;
}

body.dark-mode .login-modal-close:hover {
    color: #00ff9d;
}

body.dark-mode .modal-btn-primary {
    background: linear-gradient(135deg, #00ff9d 0%, #0066ff 100%);
}

body.dark-mode .modal-btn-secondary {
    background: rgba(255,255,255,0.05);
    color: #00ff9d;
    border-color: #00ff9d;
}

body.dark-mode .modal-btn-secondary:hover {
    background: #00ff9d;
    color: #000;
}

body.dark-mode .notification {
    background: linear-gradient(45deg, #1a0033, #000);
    border: 1px solid rgba(0,255,157,0.2);
}

body.dark-mode .notification span {
    color: #fff;
}

body.dark-mode .notification-success {
    border-left-color: #00ff9d;
}

body.dark-mode .notification-success .lucide-icon {
    color: #00ff9d;
}

body.dark-mode .notification-info {
    border-left-color: #00c3ff;
}

body.dark-mode .notification-info .lucide-icon {
    color: #00c3ff;
}

@media (max-width: 768px) {
    .notification {
        right: 10px;
        left: 10px;
        min-width: auto;
    }
    
    .login-modal-content {
        margin: 10% auto;
        padding: 30px 20px;
    }
}
.main-content .container {
    max-width: 100% !important;
    padding-left: 0 !important;
    padding-right: 0 !important;
}
</style>

<main class="main-content">
    <div class="container">
        <div class="breadcrumb">
            <a href="/">
                <svg class="lucide-icon" viewBox="0 0 24 24"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
                Home
            </a>
            <svg class="lucide-icon" viewBox="0 0 24 24"><polyline points="9 18 15 12 9 6"/></svg>
            <a href="/anime/<?php echo $episode['anime_slug']; ?>">
                <?php echo htmlspecialchars($episode['anime_title']); ?>
            </a>
            <svg class="lucide-icon" viewBox="0 0 24 24"><polyline points="9 18 15 12 9 6"/></svg>
            <span><?php echo $episodeDisplay; ?></span>
        </div>
        
        <!-- CODE INJECTION: BEFORE PLAYER -->
        <?php if(!empty($before_player_code)): ?>
        <div class="code-injection-area before-player">
            <?php echo $before_player_code; ?>
        </div>
        <?php endif; ?>
        
        <div class="watch-container">
            <div class="player-section">
                
                <!-- BEFORE PLAYER AD (Non-premium users only) -->
                <?php
                $ad_before_player = getSiteSetting('ad_before_player', '');
                if(shouldShowAds() && !empty($ad_before_player)): 
                ?>
                <div class="player-ad-container ad-before-player">
                    <div class="ad-content">
                        <?php echo $ad_before_player; ?>
                    </div>
                </div>
                <?php endif; ?>
                
                <div class="player-wrapper" id="playerWrapper">
                    <div class="lazy-player"
                         id="lazyPlayerBox"
                         data-src="<?php echo $servers[0]['server_url']; ?>">
                        <div class="blur-bg"></div>
                        <div class="play-btn"></div>
                    </div>
                </div>
                
                <!-- AFTER PLAYER AD (Non-premium users only) -->
                <?php
                $ad_after_player = getSiteSetting('ad_after_player', '');
                if(shouldShowAds() && !empty($ad_after_player)): 
                ?>
                <div class="player-ad-container ad-after-player">
                    <div class="ad-content">
                        <?php echo $ad_after_player; ?>
                    </div>
                </div>
                <?php endif; ?>
                
                <!-- CODE INJECTION: AFTER PLAYER -->
                <?php if(!empty($after_player_code)): ?>
                <div class="code-injection-area after-player">
                    <?php echo $after_player_code; ?>
                </div>
                <?php endif; ?>
                
                <div class="player-info">
                    <div class="server-notice">
                        <p class="notice-title">
                            You are watching <span class="anime-highlight"><?php echo htmlspecialchars($episode['anime_title']); ?> <?php echo $episodeDisplay; ?></span>
                        </p>
                        <p class="notice-message">
                            If the current server doesn't work, please try another server below
                        </p>
                    </div>
                    
                    <?php if(!empty($servers)): ?>
                    <div class="server-selector">
                        <h3>
                            <svg class="lucide-icon" viewBox="0 0 24 24"><rect x="2" y="2" width="20" height="8" rx="2" ry="2"/><rect x="2" y="14" width="20" height="8" rx="2" ry="2"/><line x1="6" y1="6" x2="6.01" y2="6"/><line x1="6" y1="18" x2="6.01" y2="18"/></svg>
                            Select Server
                        </h3>
                        <div class="servers">
                            <?php foreach($servers as $index => $server): ?>
                                <button class="server-btn <?php echo $index === 0 ? 'active' : ''; ?>" 
                                        onclick="changeServer('<?php echo htmlspecialchars($server['server_url']); ?>', this)">
                                    <svg class="lucide-icon" viewBox="0 0 24 24"><line x1="6" y1="3" x2="6" y2="15"/><circle cx="18" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M18 9a9 9 0 0 1-9 9"/></svg>
                                    <?php echo htmlspecialchars($server['server_name']); ?>
                                    <?php if($server['quality']): ?>
                                        <span style="font-size: 11px; opacity: 0.8;">(<?php echo $server['quality']; ?>)</span>
                                    <?php endif; ?>
                                </button>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <!-- Download Section -->
                    <?php if(!empty($downloadLinks)): ?>
                    <div class="download-section">
                        <h3>
                            <svg class="lucide-icon" viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                            Download Links
                        </h3>
                        <div class="download-links-grid">
                            <?php foreach($downloadLinks as $link): ?>
                            <button class="download-btn" 
                                    onclick="handleDownload('<?php echo htmlspecialchars($link['download_url']); ?>')">
                                <svg class="lucide-icon" viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                                <?php echo htmlspecialchars($link['link_name']); ?>
                                <?php if($link['quality']): ?>
                                    <span style="font-size: 11px; opacity: 0.8;">(<?php echo $link['quality']; ?>)</span>
                                <?php endif; ?>
                            </button>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <!-- Login Modal for Downloads -->
<div id="downloadLoginModal" class="login-modal">
    <div class="login-modal-content">
        <span class="login-modal-close" onclick="closeDownloadModal()">&times;</span>
        <div class="login-modal-header">
            <h2>
                <svg class="lucide-icon" viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><circle cx="12" cy="5" r="2"/><path d="M12 7v4"/></svg>
                Login Required
            </h2>
            <p>Please login to download episodes</p>
        </div>
        <div class="login-modal-buttons">
            <a href="login.php" class="modal-btn modal-btn-primary">
                <svg class="lucide-icon" viewBox="0 0 24 24"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" y1="12" x2="3" y2="12"/></svg>
                Login to Download
            </a>
            <a href="signup.php" class="modal-btn modal-btn-secondary">
                <svg class="lucide-icon" viewBox="0 0 24 24"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M19 8v6"/><path d="M22 11h-6"/></svg>
                Create New Account
            </a>
        </div>
    </div>
</div>
                    
                    <!-- Navigation Buttons -->
                    <div class="navigation-btns">
                        <?php if($prevEpisode): ?>
                            <a href="/watch/<?php echo $prevEpisode['slug']; ?>" class="nav-btn">
                                <svg class="lucide-icon" viewBox="0 0 24 24"><polyline points="15 18 9 12 15 6"/></svg>
                                Previous
                            </a>
                        <?php else: ?>
                            <a class="nav-btn disabled">
                                <svg class="lucide-icon" viewBox="0 0 24 24"><polyline points="15 18 9 12 15 6"/></svg>
                                Previous
                            </a>
                        <?php endif; ?>
                        
                        <?php if($nextEpisode): ?>
                            <a href="/watch/<?php echo $nextEpisode['slug']; ?>" class="nav-btn">
                                Next
                                <svg class="lucide-icon" viewBox="0 0 24 24"><polyline points="9 18 15 12 9 6"/></svg>
                            </a>
                        <?php else: ?>
                            <a class="nav-btn disabled">
                                Next
                                <svg class="lucide-icon" viewBox="0 0 24 24"><polyline points="9 18 15 12 9 6"/></svg>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- Episodes Sidebar -->
            <div class="episodes-sidebar" id="episodesSidebar">
                <div class="sidebar-header">
                    <h3>
                        <svg class="lucide-icon" viewBox="0 0 24 24"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>
                        All Episodes
                    </h3>
                    <button class="drawer-toggle" onclick="toggleDrawer()" aria-label="Toggle episode list">
                        <svg class="lucide-icon" id="drawerIcon" viewBox="0 0 24 24"><polyline points="18 15 12 9 6 15"/></svg>
                    </button>
                </div>
                
                <div class="episode-search">
                    <input type="text" id="episodeSearch" placeholder="Search episodes..." onkeyup="searchEpisodes()">
                </div>
                
                <div class="episodes-list" id="episodesList">
                    <?php foreach($allEpisodes as $ep): ?>
                        <?php 
                        $epDisplay = 'Episode ' . $ep['episode_number'];
                        if(!empty($ep['episode_letter'])) {
                            $epDisplay .= $ep['episode_letter'];
                        }
                        ?>
                        <a href="/watch/<?php echo $ep['slug']; ?>" 
                           class="episode-item <?php echo $ep['id'] === $episode['id'] ? 'active' : ''; ?>" 
                           data-episode="<?php echo $ep['episode_number'] . ($ep['episode_letter'] ?? ''); ?>">
                            <svg class="lucide-icon" viewBox="0 0 24 24"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                            <span><?php echo $epDisplay; ?></span>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</main>

<script>
// ---------------------------
// LOGIN CHECK
// ---------------------------
let isUserLoggedIn = false;

async function checkLoginStatus() {
    try {
        const res = await fetch('api.php?action=check_login');
        const data = await res.json();
        isUserLoggedIn = data.logged_in;
        return isUserLoggedIn;
    } catch (err) {
        console.error("Login check failed:", err);
        return false;
    }
}

// ---------------------------
// NOTIFICATIONS
// ---------------------------
function showNotification(message, type = 'info') {
    const box = document.createElement("div");
    box.className = `notification notification-${type}`;
    
    let iconSvg = '';
    if (type === "success") {
        iconSvg = '<svg class="lucide-icon" viewBox="0 0 24 24"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>';
    } else if (type === "error") {
        iconSvg = '<svg class="lucide-icon" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>';
    } else {
        iconSvg = '<svg class="lucide-icon" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>';
    }
    
    box.innerHTML = `${iconSvg}<span>${message}</span>`;
    document.body.appendChild(box);
    setTimeout(() => box.classList.add("show"), 20);
    setTimeout(() => {
        box.classList.remove("show");
        setTimeout(() => box.remove(), 300);
    }, 3000);
}

// ---------------------------
// DOWNLOAD LOCK
// ---------------------------
function showDownloadModal() {
    document.getElementById('downloadLoginModal').style.display = 'block';
    document.body.style.overflow = 'hidden';
}
function closeDownloadModal() {
    document.getElementById('downloadLoginModal').style.display = 'none';
    document.body.style.overflow = 'auto';
}
function handleDownload(url) {
    if (!isUserLoggedIn) return showDownloadModal();
    window.open(url, "_blank");
    showNotification("Download started", "success");
}

window.addEventListener("click", e => {
    const modal = document.getElementById("downloadLoginModal");
    if (e.target === modal) closeDownloadModal();
});

// ---------------------------
// EPISODE SEARCH + DRAWER
// ---------------------------
function searchEpisodes() {
    const v = document.getElementById("episodeSearch").value.toLowerCase();
    document.querySelectorAll(".episode-item").forEach(ep => {
        ep.style.display = ep.dataset.episode.includes(v) ? "flex" : "none";
    });
}

function toggleDrawer() {
    const sidebar = document.getElementById("episodesSidebar");
    const icon = document.getElementById("drawerIcon");
    sidebar.classList.toggle("drawer-collapsed");
    
    // Toggle between chevron-up and chevron-down
    if (icon.getAttribute('viewBox') === "0 0 24 24") {
        if (icon.innerHTML.includes('polyline points="18 15 12 9 6 15"')) {
            // Change to chevron-down
            icon.innerHTML = '<polyline points="6 9 12 15 18 9"/>';
        } else {
            // Change to chevron-up
            icon.innerHTML = '<polyline points="18 15 12 9 6 15"/>';
        }
    }
}

function loadPlayer(url) {
    const wrapper = document.getElementById("playerWrapper");

    // Remove everything inside wrapper
    wrapper.innerHTML = "";

    // Create new iframe
    const iframe = document.createElement("iframe");
    iframe.src = url;
    iframe.allowFullscreen = true;
    iframe.loading = "lazy";
    iframe.frameBorder = "0";
    iframe.style.position = "absolute";
    iframe.style.width = "100%";
    iframe.style.height = "100%";
    iframe.style.inset = "0";

    wrapper.appendChild(iframe);
}

// 1. Lazy click
document.addEventListener("click", function(e) {
    const lazyBox = e.target.closest(".lazy-player");
    if (!lazyBox) return;

    loadPlayer(lazyBox.dataset.src);
});

// 2. Server switching buttons
function changeServer(url, btn) {
    // Activate button UI
    document.querySelectorAll(".server-btn").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");

    // Load player
    loadPlayer(url);
}
// ---------------------------
// WATCH TRACKING
// ---------------------------
window.episodeData = {
    episode_id: <?php echo $episode["id"]; ?>,
    anime_id: <?php echo $episode["anime_id"]; ?>,
    next_episode_slug: <?php echo $nextEpisode ? '"' . $nextEpisode["slug"] . '"' : 'null'; ?>
};

function initIframeTracking() {
    let start = Date.now();

    function save() {
        const sec = Math.floor((Date.now() - start) / 1000);
        if (sec < 10) return;

        const form = new URLSearchParams();
        form.append("action", "track_watch");
        form.append("episode_id", window.episodeData.episode_id);
        form.append("anime_id", window.episodeData.anime_id);
        form.append("progress", sec);

        fetch("api.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: form.toString()
        });
    }

    setInterval(save, 30000);
    window.addEventListener("beforeunload", save);
}

// ---------------------------
// NEXT EPISODE PROMPT
// ---------------------------
function showNextEpisodePrompt() {
    if (!window.episodeData.next_episode_slug) return;

    const slug = window.episodeData.next_episode_slug;
    const box = document.createElement("div");
    box.style.cssText = `
        position: fixed; inset: 0; margin: auto;
        width: 260px; padding: 25px;
        background: #fff; border-radius: 12px; text-align: center;
        z-index: 9999; box-shadow: 0 10px 40px rgba(0,0,0,.3);
    `;
    box.innerHTML = `
        <h3>Episode Complete!</h3>
        <p>Next episode in <span id="np-timer">10</span>s</p>
        <button id="np-play" style="margin-top:10px;padding:10px 20px;border-radius:6px;">Play Now</button>
    `;
    document.body.appendChild(box);

    let time = 10;
    const timer = setInterval(() => {
        time--;
        document.getElementById("np-timer").textContent = time;
        if (time <= 0) {
            clearInterval(timer);
            location.href = `watch.php?slug=${slug}`;
        }
    }, 1000);

    document.getElementById("np-play").onclick = () => {
        clearInterval(timer);
        location.href = `watch.php?slug=${slug}`;
    };
}

// ---------------------------
// INIT
// ---------------------------
document.addEventListener("DOMContentLoaded", async () => {
    const logged = await checkLoginStatus();

    // No native HTML5 <video>, so use iframe tracking
    initIframeTracking();
});
</script>

<?php require_once 'footer.php'; ?>