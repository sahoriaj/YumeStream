<?php
require_once 'config.php';
require_once 'auth.php';

header('Content-Type: application/json');

echo json_encode([
    'logged_in' => isLoggedIn(),
    'user' => getCurrentUser()
]);
?>