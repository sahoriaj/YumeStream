<?php
require_once 'config.php';

$page_title = 'My Bookmarks - ' . SITE_NAME;
require_once 'header.php';
?>

<style>
/* ========== LIGHT MODE ========== */
.bookmarks-container {
    background: transparent;
    padding: 30px 0;
    margin-bottom: 30px;
}

.bookmarks-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
    flex-wrap: wrap;
    gap: 15px;
}

.bookmarks-header h1 {
    font-size: 32px;
    color: #333;
    display: flex;
    align-items: center;
    gap: 12px;
}

.bookmarks-header h1 i {
    color: #667eea;
}

.header-actions {
    display: flex;
    gap: 12px;
    flex-wrap: wrap;
}

.action-btn {
    padding: 12px 25px;
    border-radius: 25px;
    border: none;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 8px;
    font-weight: 600;
    transition: all 0.3s;
    font-size: 14px;
}

.export-btn {
    background: linear-gradient(135deg, #00c853 0%, #00e676 100%);
    color: #fff;
}

.export-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(0,200,83,0.4);
}

.import-btn {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: #fff;
}

.import-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(102,126,234,0.4);
}

.clear-all-btn {
    background: linear-gradient(135deg, #FF416C 0%, #FF4B2B 100%);
    color: #fff;
}

.clear-all-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(255,65,108,0.4);
}

.bookmarks-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
    gap: 20px;
}

.bookmark-card {
    background: #fff;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    transition: all 0.3s;
    position: relative;
}

.bookmark-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 15px 35px rgba(0,0,0,0.2);
}

.bookmark-poster {
    position: relative;
    padding-top: 140%;
    overflow: hidden;
}

.bookmark-poster img {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.remove-bookmark {
    position: absolute;
    top: 10px;
    right: 10px;
    width: 35px;
    height: 35px;
    background: rgba(255,65,108,0.9);
    border: none;
    border-radius: 50%;
    color: #fff;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 16px;
    transition: all 0.3s;
    z-index: 2;
}

.remove-bookmark:hover {
    background: #FF416C;
    transform: scale(1.1);
}

.bookmark-info {
    padding: 12px;
}

.bookmark-title {
    font-size: 14px;
    font-weight: 600;
    color: #333;
    margin-bottom: 8px;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
    line-height: 1.4;
    min-height: 40px;
    text-align: center;
}

.bookmark-meta {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    font-size: 11px;
    color: #666;
}

.bookmark-meta i {
    color: #667eea;
}

.bookmark-link {
    text-decoration: none;
    display: block;
}

.empty-bookmarks {
    grid-column: 1 / -1;
    text-align: center;
    padding: 50px 20px;
    background: transparent;
}

.empty-bookmarks i {
    font-size: 80px;
    color: #ddd;
    margin-bottom: 25px;
    display: block;
}

.empty-bookmarks h3 {
    font-size: 28px;
    color: #333;
    margin-bottom: 15px;
    font-weight: 700;
}

.empty-bookmarks p {
    color: #666;
    margin-bottom: 30px;
    font-size: 16px;
    line-height: 1.6;
}

.browse-btn {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: #fff;
    padding: 15px 30px;
    border-radius: 30px;
    text-decoration: none;
    font-weight: 600;
    font-size: 16px;
    transition: all 0.3s;
    box-shadow: 0 5px 20px rgba(102,126,234,0.3);
}

.browse-btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 30px rgba(102,126,234,0.5);
}

.bookmarks-count {
    background: #fff;
    padding: 15px 25px;
    border-radius: 12px;
    margin-bottom: 25px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 12px;
    font-size: 16px;
    color: #555;
}

.bookmarks-count i {
    color: #667eea;
    font-size: 20px;
}

/* Import Modal */
.import-modal {
    display: none;
    position: fixed;
    z-index: 10000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.8);
    backdrop-filter: blur(5px);
}

.import-modal-content {
    background: #fff;
    margin: 5% auto;
    padding: 40px;
    border-radius: 15px;
    width: 90%;
    max-width: 500px;
    box-shadow: 0 10px 40px rgba(0,0,0,0.3);
    animation: slideDown 0.3s ease;
}

@keyframes slideDown {
    from {
        transform: translateY(-50px);
        opacity: 0;
    }
    to {
        transform: translateY(0);
        opacity: 1;
    }
}

.import-modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 25px;
}

.import-modal-header h2 {
    color: #667eea;
    font-size: 24px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.modal-close {
    background: none;
    border: none;
    font-size: 28px;
    color: #999;
    cursor: pointer;
    transition: all 0.3s;
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.modal-close:hover {
    color: #667eea;
    transform: rotate(90deg);
}

.import-options {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.import-option {
    padding: 20px;
    border: 2px solid #e0e0e0;
    border-radius: 12px;
    cursor: pointer;
    transition: all 0.3s;
    display: flex;
    align-items: center;
    gap: 15px;
}

.import-option:hover {
    border-color: #667eea;
    background: #f8f9fa;
}

.import-option i {
    font-size: 32px;
    color: #667eea;
}

.import-option-text h3 {
    font-size: 18px;
    margin-bottom: 5px;
    color: #333;
}

.import-option-text p {
    font-size: 13px;
    color: #666;
    margin: 0;
}

#fileInput {
    display: none;
}

.notification {
    position: fixed;
    top: 20px;
    right: 20px;
    background: #fff;
    padding: 15px 20px;
    border-radius: 8px;
    box-shadow: 0 5px 25px rgba(0,0,0,0.2);
    display: none;
    align-items: center;
    gap: 12px;
    z-index: 10001;
    animation: slideIn 0.3s ease;
}

@keyframes slideIn {
    from {
        transform: translateX(400px);
        opacity: 0;
    }
    to {
        transform: translateX(0);
        opacity: 1;
    }
}

.notification.success {
    border-left: 4px solid #00c853;
}

.notification.error {
    border-left: 4px solid #FF416C;
}

.notification i {
    font-size: 20px;
}

.notification.success i {
    color: #00c853;
}

.notification.error i {
    color: #FF416C;
}

/* ========== DARK MODE ========== */
body.dark-mode .bookmarks-container {
    background: transparent;
}

body.dark-mode .bookmarks-header h1 {
    color: #fff;
}

body.dark-mode .bookmarks-header h1 i {
    color: #00ff9d;
}

body.dark-mode .bookmark-card {
    background: rgba(255,255,255,0.05);
    box-shadow: 0 5px 15px rgba(0,255,157,0.1);
}

body.dark-mode .bookmark-card:hover {
    box-shadow: 0 15px 35px rgba(0,255,157,0.3);
}

body.dark-mode .bookmark-title {
    color: #fff;
}

body.dark-mode .bookmark-meta {
    color: #bbb;
}

body.dark-mode .bookmark-meta i {
    color: #00ff9d;
}

body.dark-mode .bookmarks-count {
    background: rgba(255,255,255,0.05);
    color: #eee;
}

body.dark-mode .bookmarks-count i {
    color: #00ff9d;
}

body.dark-mode .empty-bookmarks {
    background: transparent;
}

body.dark-mode .empty-bookmarks i {
    color: #444;
}

body.dark-mode .empty-bookmarks h3 {
    color: #fff;
}

body.dark-mode .empty-bookmarks p {
    color: #bbb;
}

body.dark-mode .browse-btn {
    background: linear-gradient(135deg, #00ff9d 0%, #0066ff 100%);
    box-shadow: 0 5px 20px rgba(0,255,157,0.3);
}

body.dark-mode .browse-btn:hover {
    box-shadow: 0 10px 30px rgba(0,255,157,0.5);
}

body.dark-mode .clear-all-btn {
    background: linear-gradient(135deg, #ff0066 0%, #cc0044 100%);
}

body.dark-mode .export-btn {
    background: linear-gradient(135deg, #00ff9d 0%, #00c853 100%);
}

body.dark-mode .import-btn {
    background: linear-gradient(135deg, #00ff9d 0%, #0066ff 100%);
}

body.dark-mode .import-modal-content {
    background: linear-gradient(45deg, #1a0033, #000);
    border: 1px solid rgba(0,255,157,0.2);
}

body.dark-mode .import-modal-header h2 {
    color: #00ff9d;
}

body.dark-mode .modal-close {
    color: #999;
}

body.dark-mode .modal-close:hover {
    color: #00ff9d;
}

body.dark-mode .import-option {
    border-color: rgba(255,255,255,0.1);
    background: rgba(255,255,255,0.02);
}

body.dark-mode .import-option:hover {
    border-color: #00ff9d;
    background: rgba(0,255,157,0.05);
}

body.dark-mode .import-option i {
    color: #00ff9d;
}

body.dark-mode .import-option-text h3 {
    color: #fff;
}

body.dark-mode .import-option-text p {
    color: #bbb;
}

body.dark-mode .notification {
    background: linear-gradient(45deg, #1a0033, #000);
    border: 1px solid rgba(0,255,157,0.2);
}

body.dark-mode .notification.success {
    border-left-color: #00ff9d;
}

body.dark-mode .notification.success i {
    color: #00ff9d;
}

/* ========== RESPONSIVE ========== */
@media (max-width: 768px) {
    .bookmarks-container {
        padding: 20px 0;
    }
    
    .bookmarks-grid {
        grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
        gap: 15px;
    }
    
    .bookmarks-header {
        flex-direction: column;
        align-items: flex-start;
        gap: 15px;
    }
    
    .bookmarks-header h1 {
        font-size: 24px;
    }
    
    .header-actions {
        width: 100%;
        flex-direction: column;
    }
    
    .action-btn {
        width: 100%;
        justify-content: center;
        padding: 12px 20px;
    }
    
    .bookmark-title {
        font-size: 12px;
        min-height: 32px;
    }
    
    .bookmark-info {
        padding: 10px 5px;
    }
    
    .bookmark-meta {
        font-size: 10px;
        gap: 5px;
    }
    
    .bookmarks-count {
        padding: 12px 15px;
        font-size: 14px;
        flex-wrap: wrap;
    }
    
    .empty-bookmarks {
        padding: 60px 20px;
    }
    
    .empty-bookmarks i {
        font-size: 60px;
        margin-bottom: 20px;
    }
    
    .empty-bookmarks h3 {
        font-size: 22px;
        margin-bottom: 12px;
    }
    
    .empty-bookmarks p {
        font-size: 14px;
        margin-bottom: 25px;
    }
    
    .browse-btn {
        padding: 12px 28px;
        font-size: 14px;
    }
    
    .remove-bookmark {
        width: 30px;
        height: 30px;
        top: 5px;
        right: 5px;
        font-size: 14px;
    }
    
    .import-modal-content {
        margin: 10% auto;
        padding: 30px 20px;
    }
    
    .import-option {
        padding: 15px;
    }
    
    .import-option i {
        font-size: 28px;
    }
}

@media (max-width: 480px) {
    .bookmarks-grid {
        grid-template-columns: repeat(3, 1fr);
        gap: 10px;
    }
    
    .bookmarks-header h1 {
        font-size: 20px;
    }
    
    .bookmark-title {
        font-size: 11px;
        min-height: 30px;
        padding: 0 2px;
    }
    
    .bookmark-meta {
        font-size: 9px;
    }
    
    .empty-bookmarks {
        padding: 50px 15px;
    }
    
    .empty-bookmarks i {
        font-size: 50px;
    }
    
    .empty-bookmarks h3 {
        font-size: 20px;
    }
    
    .empty-bookmarks p {
        font-size: 13px;
    }
    
    .browse-btn {
        padding: 10px 25px;
        font-size: 13px;
    }
}
</style>

<!-- Import Modal -->
<div id="importModal" class="import-modal">
    <div class="import-modal-content">
        <div class="import-modal-header">
            <h2><i data-lucide="upload"></i> Import Bookmarks</h2>
            <button class="modal-close" onclick="closeImportModal()">
                <i data-lucide="x"></i>
            </button>
        </div>
        <div class="import-options">
            <div class="import-option" onclick="document.getElementById('fileInput').click()">
                <i data-lucide="file-up"></i>
                <div class="import-option-text">
                    <h3>Import from File</h3>
                    <p>Upload a JSON file with your bookmarks</p>
                </div>
            </div>
            <div class="import-option" onclick="showTextImport()">
                <i data-lucide="clipboard"></i>
                <div class="import-option-text">
                    <h3>Import from Text</h3>
                    <p>Paste JSON text directly</p>
                </div>
            </div>
        </div>
        <input type="file" id="fileInput" accept=".json" onchange="handleFileImport(event)">
    </div>
</div>

<!-- Notification -->
<div id="notification" class="notification">
    <i data-lucide="check-circle"></i>
    <span id="notificationText"></span>
</div>

<main class="main-content">
    <div class="container">
        <div class="bookmarks-container">
            <div class="bookmarks-header">
                <h1><i data-lucide="bookmark"></i> My Bookmarks</h1>
                <div class="header-actions">
                    <button class="action-btn export-btn" onclick="exportBookmarks()" id="exportBtn" style="display: none;">
                        <i data-lucide="download"></i> Export
                    </button>
                    <button class="action-btn import-btn" onclick="openImportModal()">
                        <i data-lucide="upload"></i> Import
                    </button>
                    <button class="action-btn clear-all-btn" onclick="clearAllBookmarks()" id="clearAllBtn" style="display: none;">
                        <i data-lucide="trash-2"></i> Clear All
                    </button>
                </div>
            </div>
            
            <div class="bookmarks-count" id="bookmarksCount" style="display: none;">
                <i data-lucide="heart"></i>
                <span>You have <strong id="countNumber">0</strong> bookmarked anime</span>
            </div>
            
            <div class="bookmarks-grid" id="bookmarksGrid">
                
            </div>
        </div>
    </div>
</main>

<script>
// Get bookmarks from localStorage
function getBookmarks() {
    const bookmarks = localStorage.getItem('animeBookmarks');
    return bookmarks ? JSON.parse(bookmarks) : [];
}

// Remove bookmark
function removeBookmark(animeId) {
    if(confirm('Remove this anime from bookmarks?')) {
        let bookmarks = getBookmarks();
        bookmarks = bookmarks.filter(b => b.id != animeId);
        localStorage.setItem('animeBookmarks', JSON.stringify(bookmarks));
        loadBookmarks();
        showNotification('Bookmark removed successfully', 'success');
        
        // Dispatch event for other pages
        window.dispatchEvent(new Event('bookmarksChanged'));
    }
}

// Clear all bookmarks
function clearAllBookmarks() {
    if(confirm('Are you sure you want to clear all bookmarks? This cannot be undone!')) {
        localStorage.removeItem('animeBookmarks');
        loadBookmarks();
        showNotification('All bookmarks cleared', 'success');
        
        // Dispatch event for other pages
        window.dispatchEvent(new Event('bookmarksChanged'));
    }
}

// Export bookmarks
function exportBookmarks() {
    const bookmarks = getBookmarks();
    
    if(bookmarks.length === 0) {
        showNotification('No bookmarks to export', 'error');
        return;
    }
    
    const dataStr = JSON.stringify(bookmarks, null, 2);
    const dataBlob = new Blob([dataStr], {type: 'application/json'});
    
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `novadonghua_bookmarks_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    
    showNotification(`Exported ${bookmarks.length} bookmarks successfully`, 'success');
}

// Open import modal
function openImportModal() {
    document.getElementById('importModal').style.display = 'block';
    document.body.style.overflow = 'hidden';
    
    // Reinitialize Lucide icons in modal
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
}

// Close import modal
function closeImportModal() {
    document.getElementById('importModal').style.display = 'none';
    document.body.style.overflow = 'auto';
}

// Handle file import
function handleFileImport(event) {
    const file = event.target.files[0];
    
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = function(e) {
        try {
            const importedData = JSON.parse(e.target.result);
            importBookmarks(importedData);
        } catch (error) {
            showNotification('Invalid JSON file', 'error');
        }
    };
    reader.readAsText(file);
    
    event.target.value = '';
}

// Show text import
function showTextImport() {
    const jsonText = prompt('Paste your bookmarks JSON data here:');
    
    if (!jsonText) return;
    
    try {
        const importedData = JSON.parse(jsonText);
        importBookmarks(importedData);
    } catch (error) {
        showNotification('Invalid JSON format', 'error');
    }
}

// Import bookmarks
function importBookmarks(importedData) {
    if (!Array.isArray(importedData)) {
        showNotification('Invalid bookmark data format', 'error');
        return;
    }
    
    const action = confirm('Choose import method:\n\nOK = Merge with existing bookmarks\nCancel = Replace all bookmarks');
    
    let bookmarks = [];
    
    if (action) {
        bookmarks = getBookmarks();
        const existingIds = new Set(bookmarks.map(b => b.id));
        
        importedData.forEach(item => {
            if (!existingIds.has(item.id)) {
                bookmarks.push(item);
            }
        });
    } else {
        bookmarks = importedData;
    }
    
    localStorage.setItem('animeBookmarks', JSON.stringify(bookmarks));
    loadBookmarks();
    closeImportModal();
    showNotification(`Successfully imported ${importedData.length} bookmarks`, 'success');
    
    // Dispatch event for other pages
    window.dispatchEvent(new Event('bookmarksChanged'));
}

// Show notification
function showNotification(message, type = 'success') {
    const notification = document.getElementById('notification');
    const notificationText = document.getElementById('notificationText');
    const icon = notification.querySelector('i');
    
    notification.className = `notification ${type}`;
    
    icon.removeAttribute('class');
    icon.setAttribute('data-lucide', type === 'success' ? 'check-circle' : 'alert-circle');
    
    notificationText.textContent = message;
    notification.style.display = 'flex';
    
    // Reinitialize Lucide icons
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
    
    setTimeout(() => {
        notification.style.display = 'none';
    }, 3000);
}

// Helper function to get poster URL
function getPosterUrl(poster) {
    if(!poster) return '/uploads/default.jpg';
    if(poster.startsWith('http://') || poster.startsWith('https://')) {
        return poster;
    }
    return '/uploads/' + poster;
}

// Load and display bookmarks
function loadBookmarks() {
    const bookmarks = getBookmarks();
    const grid = document.getElementById('bookmarksGrid');
    const countDiv = document.getElementById('bookmarksCount');
    const countNumber = document.getElementById('countNumber');
    const clearBtn = document.getElementById('clearAllBtn');
    const exportBtn = document.getElementById('exportBtn');
    
    if(bookmarks.length === 0) {
        grid.innerHTML = `
            <div class="empty-bookmarks">
                <i data-lucide="bookmark"></i>
                <h3>No Bookmarks Yet</h3>
                <p>Start adding your favorite anime to bookmarks!</p>
                <a href="/" class="browse-btn">
                    <i data-lucide="search"></i> Browse Anime
                </a>
            </div>
        `;
        countDiv.style.display = 'none';
        clearBtn.style.display = 'none';
        exportBtn.style.display = 'none';
        
        // Initialize Lucide icons for empty state
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
        return;
    }
    
    countDiv.style.display = 'flex';
    clearBtn.style.display = 'flex';
    exportBtn.style.display = 'flex';
    countNumber.textContent = bookmarks.length;
    
    grid.innerHTML = bookmarks.map(anime => `
        <div class="bookmark-card">
            <button class="remove-bookmark" onclick="removeBookmark(${anime.id})" title="Remove bookmark">
                <i data-lucide="x"></i>
            </button>
            <a href="/anime/${anime.slug}" class="bookmark-link">
                <div class="bookmark-poster">
                    <img src="${getPosterUrl(anime.poster)}" 
                         alt="${anime.title}"
                         onerror="this.src='/uploads/default.jpg'">
                </div>
                <div class="bookmark-info">
                    <div class="bookmark-title">${anime.title}</div>
                    <div class="bookmark-meta">
                        <i data-lucide="calendar"></i>
                        <span>Added ${anime.bookmarkedAt}</span>
                    </div>
                </div>
            </a>
        </div>
    `).join('');
    
    // Initialize Lucide icons after rendering
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
}

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('importModal');
    if (event.target === modal) {
        closeImportModal();
    }
}

// Load bookmarks on page load
document.addEventListener('DOMContentLoaded', function() {
    loadBookmarks();
    
    // Initialize Lucide icons
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
});

// Listen for bookmark changes from other pages
window.addEventListener('bookmarksChanged', function() {
    loadBookmarks();
});
</script>

<?php require_once 'footer.php'; ?>