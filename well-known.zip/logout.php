<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logging out...</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .logout-message {
            background: white;
            padding: 30px;
            border-radius: 10px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="logout-message">
        <p>Logging out...</p>
    </div>
    
    <script type="module">
        import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
        import { getAuth, signOut } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";

        const firebaseConfig = {
            apiKey: "AIzaSyDgqpr976h-uGvfOCROX0V6cMaiWP1hOlc",
            authDomain: "login-signup-7cb63.firebaseapp.com",
            projectId: "login-signup-7cb63",
            storageBucket: "login-signup-7cb63.firebasestorage.app",
            messagingSenderId: "428131759010",
            appId: "1:428131759010:web:dcaed1cf0f280d885b78fb",
            measurementId: "G-8236JK3ZYL"
        };

        const app = initializeApp(firebaseConfig);
        const auth = getAuth(app);

        async function performLogout() {
            try {
                // Destroy PHP session
                await fetch('logout_session.php');
                
                // Sign out from Firebase
                await signOut(auth);
                
                // Clear all localStorage/sessionStorage
                localStorage.clear();
                sessionStorage.clear();
                
                // Redirect to login
                window.location.href = 'login.php';
            } catch (error) {
                console.error('Logout error:', error);
                // Force redirect anyway
                window.location.href = 'login.php';
            }
        }

        performLogout();
    </script>
</body>
</html>