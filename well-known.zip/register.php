<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - Yumestream</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        
        .container {
            background: white;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            width: 100%;
            max-width: 420px;
        }
        
        .logo {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .logo h1 {
            color: #667eea;
            font-size: 32px;
            margin-bottom: 5px;
        }
        
        .logo p {
            color: #666;
            font-size: 14px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 500;
            font-size: 14px;
        }
        
        input[type="email"],
        input[type="password"],
        input[type="text"] {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s;
        }
        
        input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 10px rgba(102,126,234,0.2);
        }
        
        .btn {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        
        .btn:hover:not(:disabled) {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }

        .btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }
        
        .btn-google {
            background: white;
            color: #333;
            border: 2px solid #e0e0e0;
            margin-bottom: 10px;
        }
        
        .btn-google:hover {
            background: #f8f9fa;
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }
        
        .alert {
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .alert-error {
            background: #fee;
            color: #c33;
            border: 1px solid #fcc;
        }
        
        .alert-success {
            background: #efe;
            color: #3c3;
            border: 1px solid #cfc;
        }
        
        .login-link {
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
            color: #666;
        }
        
        .login-link a {
            color: #667eea;
            text-decoration: none;
            font-weight: 600;
        }
        
        .login-link a:hover {
            text-decoration: underline;
        }
        
        .divider {
            text-align: center;
            margin: 20px 0;
            position: relative;
        }
        
        .divider::before {
            content: '';
            position: absolute;
            left: 0;
            top: 50%;
            width: 100%;
            height: 1px;
            background: #e0e0e0;
        }
        
        .divider span {
            background: white;
            padding: 0 10px;
            position: relative;
            color: #999;
            font-size: 13px;
        }

        .spinner {
            border: 2px solid #f3f3f3;
            border-top: 2px solid #667eea;
            border-radius: 50%;
            width: 16px;
            height: 16px;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .hidden {
            display: none;
        }

        .password-requirements {
            font-size: 12px;
            color: #666;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">
            <h1>Yumestream</h1>
            <p>Create your account to get started</p>
        </div>
        
        <div id="alertBox" class="hidden"></div>
        
        <!-- Google Sign Up Button -->
        <button type="button" class="btn btn-google" id="googleSignUp">
            <svg width="18" height="18" xmlns="http://www.w3.org/2000/svg"><g fill="none" fill-rule="evenodd"><path d="M17.6 9.2l-.1-1.8H9v3.4h4.8C13.6 12 13 13 12 13.6v2.2h3a8.8 8.8 0 0 0 2.6-6.6z" fill="#4285F4"/><path d="M9 18c2.4 0 4.5-.8 6-2.2l-3-2.2a5.4 5.4 0 0 1-8-2.9H1V13a9 9 0 0 0 8 5z" fill="#34A853"/><path d="M4 10.7a5.4 5.4 0 0 1 0-3.4V5H1a9 9 0 0 0 0 8l3-2.3z" fill="#FBBC05"/><path d="M9 3.6c1.3 0 2.5.4 3.4 1.3L15 2.3A9 9 0 0 0 1 5l3 2.4a5.4 5.4 0 0 1 5-3.7z" fill="#EA4335"/></g></svg>
            Sign up with Google
        </button>
        
        <div class="divider">
            <span>OR</span>
        </div>
        
        <!-- Email/Password Form -->
        <form id="signupForm">
            <div class="form-group">
                <label>Full Name</label>
                <input type="text" id="fullName" required placeholder="Enter your full name">
            </div>

            <div class="form-group">
                <label>Email</label>
                <input type="email" id="email" required placeholder="Enter your email">
            </div>
            
            <div class="form-group">
                <label>Password</label>
                <input type="password" id="password" required placeholder="Create a password">
                <div class="password-requirements">At least 6 characters</div>
            </div>

            <div class="form-group">
                <label>Confirm Password</label>
                <input type="password" id="confirmPassword" required placeholder="Confirm your password">
            </div>
            
            <button type="submit" class="btn" id="signupBtn">
                <span>Sign Up</span>
            </button>
        </form>
        
        <div class="login-link">
            Already have an account? <a href="login.php">Login here</a>
        </div>
    </div>

    <!-- Firebase SDK v12.6.0 -->
    <script type="module">
        import { initializeApp } from "https://www.gstatic.com/firebasejs/12.6.0/firebase-app.js";
        import { getAnalytics } from "https://www.gstatic.com/firebasejs/12.6.0/firebase-analytics.js";
        import { 
            getAuth, 
            createUserWithEmailAndPassword,
            signInWithPopup,
            GoogleAuthProvider,
            updateProfile
        } from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";

        // Firebase configuration
        const firebaseConfig = {
            apiKey: "AIzaSyDgqpr976h-uGvfOCROX0V6cMaiWP1hOlc",
            authDomain: "login-signup-7cb63.firebaseapp.com",
            projectId: "login-signup-7cb63",
            storageBucket: "login-signup-7cb63.firebasestorage.app",
            messagingSenderId: "428131759010",
            appId: "1:428131759010:web:dcaed1cf0f280d885b78fb",
            measurementId: "G-8236JK3ZYL"
        };

        // Initialize Firebase
        const app = initializeApp(firebaseConfig);
        const analytics = getAnalytics(app);
        const auth = getAuth(app);
        const googleProvider = new GoogleAuthProvider();

        // Get redirect URL from query parameter
        const urlParams = new URLSearchParams(window.location.search);
        const redirectUrl = urlParams.get('redirect') || '/';

        // DOM elements
        const signupForm = document.getElementById('signupForm');
        const signupBtn = document.getElementById('signupBtn');
        const googleSignUpBtn = document.getElementById('googleSignUp');
        const alertBox = document.getElementById('alertBox');
        const emailInput = document.getElementById('email');
        const passwordInput = document.getElementById('password');
        const confirmPasswordInput = document.getElementById('confirmPassword');
        const fullNameInput = document.getElementById('fullName');

        let isProcessing = false;

        // Show alert message
        function showAlert(message, type = 'error') {
            alertBox.className = `alert alert-${type}`;
            alertBox.innerHTML = `
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    ${type === 'error' ? '<circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/>' : '<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>'}
                </svg>
                ${message}
            `;
            alertBox.classList.remove('hidden');
            
            setTimeout(() => {
                alertBox.classList.add('hidden');
            }, 5000);
        }

        // Set loading state
        function setLoading(button, isLoading, defaultText = 'Sign Up') {
            if (isLoading) {
                button.disabled = true;
                const text = button.querySelector('span');
                if (text) text.textContent = 'Creating account...';
                const spinner = document.createElement('div');
                spinner.className = 'spinner';
                button.insertBefore(spinner, button.firstChild);
            } else {
                button.disabled = false;
                const spinner = button.querySelector('.spinner');
                if (spinner) spinner.remove();
                const text = button.querySelector('span');
                if (text) text.textContent = defaultText;
            }
        }

        // Handle successful authentication
        async function handleAuthSuccess(user) {
            if (isProcessing) return;
            isProcessing = true;

            try {
                showAlert('Account created! Redirecting...', 'success');
                
                // Get ID token to send to backend
                const idToken = await user.getIdToken();
                
                // Send token to PHP backend
                const response = await fetch('firebase_verify.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ 
                        idToken,
                        displayName: user.displayName || ''
                    })
                });

                const result = await response.json();
                
                if (result.success) {
                    // Redirect to the original page or index
                    setTimeout(() => {
                        window.location.href = redirectUrl;
                    }, 1000);
                } else {
                    throw new Error(result.message || 'Backend authentication failed');
                }
                
            } catch (error) {
                console.error('Backend auth error:', error);
                showAlert('Authentication failed: ' + error.message, 'error');
                isProcessing = false;
            }
        }

        // Email/Password Signup
        signupForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            if (isProcessing) return;

            const email = emailInput.value;
            const password = passwordInput.value;
            const confirmPassword = confirmPasswordInput.value;
            const fullName = fullNameInput.value;

            // Validate passwords match
            if (password !== confirmPassword) {
                showAlert('Passwords do not match!', 'error');
                return;
            }

            // Validate password length
            if (password.length < 6) {
                showAlert('Password must be at least 6 characters long', 'error');
                return;
            }

            setLoading(signupBtn, true);

            try {
                const userCredential = await createUserWithEmailAndPassword(auth, email, password);
                
                // Update user profile with display name
                await updateProfile(userCredential.user, {
                    displayName: fullName
                });

                await handleAuthSuccess(userCredential.user);
                
            } catch (error) {
                console.error('Signup error:', error);
                let errorMessage = 'Signup failed. Please try again.';
                
                switch (error.code) {
                    case 'auth/email-already-in-use':
                        errorMessage = 'An account with this email already exists.';
                        break;
                    case 'auth/invalid-email':
                        errorMessage = 'Invalid email address.';
                        break;
                    case 'auth/weak-password':
                        errorMessage = 'Password is too weak. Use at least 6 characters.';
                        break;
                    case 'auth/operation-not-allowed':
                        errorMessage = 'Email/password accounts are not enabled.';
                        break;
                }
                
                showAlert(errorMessage, 'error');
                setLoading(signupBtn, false);
            }
        });

        // Google Sign Up
        googleSignUpBtn.addEventListener('click', async () => {
            if (isProcessing) return;

            setLoading(googleSignUpBtn, true, 'Sign up with Google');
            
            try {
                const result = await signInWithPopup(auth, googleProvider);
                await handleAuthSuccess(result.user);
                
            } catch (error) {
                console.error('Google sign up error:', error);
                
                let errorMessage = 'Google sign up failed.';
                if (error.code === 'auth/popup-closed-by-user') {
                    errorMessage = 'Sign up cancelled.';
                } else if (error.code === 'auth/popup-blocked') {
                    errorMessage = 'Popup blocked. Please allow popups for this site.';
                } else if (error.code === 'auth/account-exists-with-different-credential') {
                    errorMessage = 'An account already exists with this email.';
                }
                
                showAlert(errorMessage, 'error');
                setLoading(googleSignUpBtn, false, 'Sign up with Google');
            }
        });
        
        // Check if user is already logged in - REMOVED AUTO-REDIRECT
        // Only check session state, don't auto-redirect
        onAuthStateChanged(auth, async (user) => {
            if (user && !isProcessing) {
                // Check if PHP session exists
                try {
                    const response = await fetch('check_login.php');
                    const data = await response.json();
                    
                    if (data.logged_in) {
                        // User is already logged in, redirect
                        window.location.href = redirectUrl;
                    }
                } catch (error) {
                    console.error('Session check error:', error);
                }
            }
        });
    </script>
</body>
</html>