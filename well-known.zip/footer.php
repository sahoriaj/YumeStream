<?php
// Get dynamic footer settings
$footer_logo = getSiteSetting('footer_logo', 'https://blogger.googleusercontent.com/img/a/AVvXsEiM-qT1Af7WlPoO55lrQ67eZ9EviqkgBjB5GwosWl-N3iK5Yp9zZpkRgzm4Yitl78EAFV2wvNNKAJ6TlmNp6i7slTpXylHiVZN8lnAptigt0KXkJUVqnFiX5GHofLIilFHit4sZTcu5Nam58cCp25WZ4yJJ5KR9jSTJzqbchhoUjmUxDg0uedGnvlh7C_ZF=w800');
$footer_quick = getMenuItems('footer_menu_quick');
$footer_info = getMenuItems('footer_menu_info');
$social_facebook = getSiteSetting('social_facebook', 'https://www.facebook.com/novadonghua');
$social_twitter = getSiteSetting('social_twitter', 'https://x.com/donghivenews');
$social_telegram = getSiteSetting('social_telegram', 'https://t.me/novadonghua');
$social_discord = getSiteSetting('social_discord', 'https://discord.gg/HYzb5uJBYg');

// Get code injection settings
$before_body_close = getSiteSetting('before_body_close', '');
$footer_code = getSiteSetting('footer_code', '');
?>

<footer class="site-footer">
    <div class="container">
        <div class="footer-grid">
            <!-- Logo and Description -->
            <div class="footer-section">
                <a href="/" class="footer-logo" aria-label="Nova Donghua">
                    <img
                        src="<?php echo htmlspecialchars($footer_logo); ?>"
                        alt="Nova Donghua"
                        width="150"
                        height="40"
                        loading="lazy"
                        onerror="this.src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTUwIiBoZWlnaHQ9IjQwIiB2aWV3Qm94PSIwIDAgMTUwIDQwIiBmaWxsPSJub25lIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxyZWN0IHdpZHRoPSIxNTAiIGhlaWdodD0iNDAiIGZpbGw9IiM2NjdlZWEiLz48dGV4dCB4PSI3NSIgeT0iMjUiIGZvbnQtZmFtaWx5PSJBcmlhbCIgZm9udC1zaXplPSIxNCIgZmlsbD0id2hpdGUiIHRleHQtYW5jaG9yPSJtaWRkbGUiPkxvZ288L3RleHQ+PC9zdmc+'"
                    />
                </a>
                <p class="footer-description">Your ultimate destination for streaming anime. Watch thousands of episodes and movies for free.</p>
            </div>
            
            <!-- Quick Links - Dynamic -->
            <div class="footer-section">
                <h3 class="footer-heading">
                    <i data-lucide="link"></i> Quick Links
                </h3>
                <ul class="footer-links">
                    <?php foreach($footer_quick as $item): ?>
                    <li>
                        <a href="<?php echo htmlspecialchars($item['url']); ?>" class="footer-link">
                            <i data-lucide="<?php echo htmlspecialchars($item['icon']); ?>"></i> 
                            <?php echo htmlspecialchars($item['label']); ?>
                        </a>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>
            
            <!-- Information - Dynamic -->
            <div class="footer-section">
                <h3 class="footer-heading">
                    <i data-lucide="info"></i> Information
                </h3>
                <ul class="footer-links">
                    <?php foreach($footer_info as $item): ?>
                    <li>
                        <a href="<?php echo htmlspecialchars($item['url']); ?>" class="footer-link">
                            <i data-lucide="<?php echo htmlspecialchars($item['icon']); ?>"></i> 
                            <?php echo htmlspecialchars($item['label']); ?>
                        </a>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>
            
            <!-- Social Links -->
            <div class="footer-section">
                <h3 class="footer-heading">
                    <i data-lucide="share-2"></i> Follow Us
                </h3>
                <div class="social-links">
                    <?php if(!empty($social_facebook)): ?>
                    <a href="<?php echo htmlspecialchars($social_facebook); ?>" 
                       aria-label="Facebook"
                       class="social-link"
                       target="_blank" rel="noopener noreferrer">
                        <i data-lucide="facebook"></i>
                    </a>
                    <?php endif; ?>

                    <?php if(!empty($social_twitter)): ?>
                    <a href="<?php echo htmlspecialchars($social_twitter); ?>" 
                       aria-label="Twitter"
                       class="social-link"
                       target="_blank" rel="noopener noreferrer">
                        <i data-lucide="twitter"></i>
                    </a>
                    <?php endif; ?>

                    <?php if(!empty($social_telegram)): ?>
                    <a href="<?php echo htmlspecialchars($social_telegram); ?>" 
                       aria-label="Telegram"
                       class="social-link"
                       target="_blank" rel="noopener noreferrer">
                        <i data-lucide="send"></i>
                    </a>
                    <?php endif; ?>

                    <?php if(!empty($social_discord)): ?>
                    <a href="<?php echo htmlspecialchars($social_discord); ?>" 
                       aria-label="Discord"
                       class="social-link"
                       target="_blank" rel="noopener noreferrer">
                        <i data-lucide="message-circle"></i>
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <div class="footer-bottom">
            <p><i data-lucide="copyright"></i> <?php echo date('Y'); ?> Nova Donghua. All rights reserved.</p>
        </div>
    </div>
</footer>

<?php 
// Output custom code before body close
if (!empty($before_body_close)) {
    echo "\n<!-- Custom Code Before Body Close -->\n";
    echo $before_body_close . "\n";
    echo "<!-- End Custom Code Before Body Close -->\n";
}
?>

<!-- Footer JavaScript - Load after page renders -->
<script src="/assets/footer-script.js" defer></script>
<script src="/assets/script.js" defer></script>

<?php 
// Output custom footer code
if (!empty($footer_code)) {
    echo "\n<!-- Custom Footer Code -->\n";
    echo $footer_code . "\n";
    echo "<!-- End Custom Footer Code -->\n";
}
?>
<script>
/* Ad Block Detection */
(function () {
  const n = document, o = n.head;
  const hidden = "pointer-events:none;height:1px;width:0;opacity:0;visibility:hidden;position:fixed;bottom:0;";
  const a = n.createElement("div"),
        s = n.createElement("div"),
        d = n.createElement("ins");

  a.id = "div-gpt-ad-3061307416813-0"; a.style = hidden;
  s.className = "textads banner-ads banner_ads ad-unit ad-zone ad-space adsbox ads"; s.style = hidden;
  d.className = "adsbygoogle"; d.style = "display:none;";

  const checkObj = { allowed: null, elements: [a, s, d] };

  this.checkAdsStatus = function (cb) {
    if (typeof cb !== "function") return;
    if (typeof checkObj.allowed === "boolean") return cb(checkObj);

    document.body.appendChild(a);
    document.body.appendChild(s);
    document.body.appendChild(d);

    setTimeout(() => {
      if (a.offsetHeight === 0 || s.offsetHeight === 0 || d.firstElementChild) {
        checkObj.allowed = false;
        cb(checkObj);
      } else {
        const script = n.createElement("script");
        script.src = "https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js";
        script.async = true;
        script.crossOrigin = "anonymous";

        script.onload = () => { checkObj.allowed = true; cb(checkObj); };
        script.onerror = () => { checkObj.allowed = false; cb(checkObj); };

        o.appendChild(script);
      }

      a.remove(); s.remove(); d.remove();
    }, 40);
  };
}).call(this);

function antiAdBlockerHandler() {
  window.checkAdsStatus(function (ads) {
    if (!ads.allowed) {
      console.log("%c[ADS]", "color:#d32f2f;", "Blocked");

      const icon = "<svg style='stroke:none;fill:currentColor!important' viewBox='0 0 24 24'><path d='M12.2 9L10.2 7H13C14.1 7 15 7.9 15 9V11.8L13 9.8V9H12.2M23 9V7H19C17.9 7 17 7.9 17 9V11C17 12.1 17.9 13 19 13H21V15H18.2L20.2 17H21C22.1 17 23 16.1 23 15V13C23 11.9 22.1 11 21 11H19V9H23M22.1 21.5L20.8 22.8L14.4 16.4C14.1 16.7 13.6 17 13 17H9V10.9L7 8.9V17H5V13H3V17H1V9C1 7.9 1.9 7 3 7H5.1L1.1 3L2.4 1.7L22.1 21.5M5 9H3V11H5V9M13 14.9L11 12.9V15H13V14.9Z'/></svg>";
      const html =
        `<div class='popSc'><div class='popBo'>${icon}<h2>Ad blocker detected!</h2>
        <div class='popCo'><p>We detected an ad blocker in your browser.<br>Please whitelist our website to support us.</p></div>
        </div></div>`;

      document.body.insertAdjacentHTML("beforeend", html);
    } else {
      console.log("%c[ADS]", "color:#43a047;", "Allowed");
    }
  });

  document.removeEventListener("DOMContentLoaded", antiAdBlockerHandler);
}

if (document.readyState === "complete" || document.readyState !== "loading") {
  antiAdBlockerHandler();
} else {
  document.addEventListener("DOMContentLoaded", antiAdBlockerHandler);
}

/* Automatic Sitemap Generation */
(function () {
  const INTERVAL = 10 * 60 * 1000;
  const KEY = "sitemap_last_gen";

  function shouldGenerate() {
    const last = localStorage.getItem(KEY);
    if (!last) return true;
    return Date.now() - parseInt(last) >= INTERVAL;
  }

  function generate() {
    if (!shouldGenerate()) return;
    fetch("/generate_sitemap_direct.php?auto=true")
      .then(r => r.json())
      .then(d => {
        if (d.success) {
          localStorage.setItem(KEY, Date.now().toString());
          console.log("Sitemap auto-generated:", d.timestamp);
        }
      })
      .catch(err => console.error("Sitemap generation failed:", err));
  }

  generate();
  setInterval(generate, INTERVAL);
})();

/* Lucide Icons Init */
document.addEventListener("DOMContentLoaded", () => {
  if (typeof lucide !== "undefined") lucide.createIcons();
});

window.addEventListener("load", () => {
  if (typeof lucide !== "undefined" && !window.iconsCreated) {
    lucide.createIcons();
    window.iconsCreated = true;
  }
});
</script>

</body>
</html>