<?php
header('Content-Type: text/html; charset=UTF-8');
require_once 'config.php';
require_once 'auth.php';

$genre = $_GET['genre'] ?? '';

// If no genre specified, show all genres list
if(empty($genre)) {
    // Get all unique genres
    $stmt = $pdo->query("SELECT DISTINCT genres FROM anime WHERE genres IS NOT NULL AND genres != ''");
    $allGenres = [];
    while($row = $stmt->fetch()) {
        $genres = explode(',', $row['genres']);
        foreach($genres as $g) {
            $g = trim($g);
            if(!empty($g) && !in_array($g, $allGenres)) {
                $allGenres[] = $g;
            }
        }
    }
    sort($allGenres);
    
    $page_title = "All Genres";
    $showGenresList = true;
    $animeList = [];
} else {
    // Get anime with this genre
    $stmt = $pdo->prepare("SELECT * FROM anime WHERE FIND_IN_SET(?, REPLACE(genres, ', ', ',')) > 0 ORDER BY id DESC");
    $stmt->execute([$genre]);
    $animeList = $stmt->fetchAll();
    
    $page_title = ucfirst($genre) . " Anime";
    $showGenresList = false;
}
require_once 'header.php';
?>

<style>
/* Lucide Icons */
[data-lucide] {
  width: 22px;
  height: 22px;
  stroke: currentColor;
  stroke-width: 2;
  fill: none;
  vertical-align: middle;
  display: inline-block;
  transition: transform .2s ease;
}

button:hover [data-lucide],
a:hover [data-lucide] {
  transform: scale(1.10);
}

.icon-sm [data-lucide] { width: 16px; height: 16px; }
.icon-md [data-lucide] { width: 18px; height: 18px; }
.icon-lg [data-lucide] { width: 26px; height: 26px; }

/* Genre Page Styles */
.genre-hero {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    padding: 60px 0;
    text-align: center;
    margin-bottom: 40px;
}

.genre-hero h1 {
    color: #fff;
    font-size: 42px;
    font-weight: 700;
    margin-bottom: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 15px;
}

.genre-hero p {
    color: rgba(255,255,255,0.9);
    font-size: 16px;
}

.breadcrumb {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 5px;
    font-size: 15px;
    background: #fff;
    color: #333;
    padding: 12px 20px;
    border-radius: 8px;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
    margin-bottom: 30px;
}

.breadcrumb a {
    color: #667eea;
    text-decoration: none;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 2px;
    transition: color 0.3s ease;
}

.breadcrumb a:hover {
    color: #764ba2;
}

.breadcrumb i {
    color: #999;
    font-size: 13px;
}

.breadcrumb span {
    color: #666;
    font-weight: 500;
}

.no-results {
    text-align: center;
    padding: 60px 20px;
}

.no-results i {
    font-size: 64px;
    color: #ccc;
    margin-bottom: 20px;
}

.no-results h3 {
    color: #666;
    font-size: 24px;
    margin-bottom: 10px;
}

.no-results p {
    color: #999;
    font-size: 16px;
}

/* Dark Mode */
body.dark-mode .genre-hero {
    background: linear-gradient(135deg, #1a0033 0%, #000 100%);
}

body.dark-mode .breadcrumb {
    background: linear-gradient(45deg, #1a0033, #000);
    color: #eee;
    box-shadow: 0 5px 20px rgba(0, 255, 157, 0.15);
}

body.dark-mode .breadcrumb a {
    color: #00ff9d;
}

body.dark-mode .breadcrumb a:hover {
    color: #00c3ff;
}

body.dark-mode .breadcrumb i {
    color: #00ff9d;
}

body.dark-mode .breadcrumb span {
    color: #ccc;
}

body.dark-mode .anime-card {
    background: rgba(255,255,255,0.05);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255,255,255,0.1);
}

body.dark-mode .anime-card:hover {
    box-shadow: 0 10px 30px rgba(0,255,157,0.2);
}

body.dark-mode .anime-card-title {
    color: #fff;
}

body.dark-mode .anime-card-meta {
    color: #aaa;
}

body.dark-mode .no-results h3 {
    color: #fff;
}

body.dark-mode .no-results p {
    color: #aaa;
}

/* Genres List Grid */
.genres-list-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
    gap: 20px;
    margin-bottom: 40px;
}

.genre-card {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: #fff;
    padding: 25px 20px;
    border-radius: 12px;
    text-decoration: none;
    text-align: center;
    font-weight: 600;
    font-size: 16px;
    transition: all 0.3s ease;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 10px;
    box-shadow: 0 5px 20px rgba(102,126,234,0.3);
}

.genre-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 30px rgba(102,126,234,0.5);
}

.genre-card i {
    font-size: 32px;
}

body.dark-mode .genre-card {
    background: linear-gradient(135deg, #1a0033 0%, #4100cd 100%);
    box-shadow: 0 5px 20px rgba(0,255,157,0.2);
}

body.dark-mode .genre-card:hover {
    box-shadow: 0 10px 30px rgba(0,255,157,0.4);
}

@media (max-width: 768px) {
    .genre-hero h1 {
        font-size: 28px;
    }
    
    .genres-list-grid {
        grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
        gap: 15px;
    }
    
/* ============================================
   STATUS RIBBON - TEXT PERFECTLY CENTERED (SHIFTED DOWN)
   ============================================ */

/* IMPORTANT: Make sure parent .anime-card has overflow: visible */
.anime-card {
  position: relative;
  overflow: visible; /* CRITICAL */
}

.badge-container {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 6;
  pointer-events: none;
  overflow: visible;
}

.status-badge {
  position: absolute;
  top: 12px;
  left: -25px;
  
  width: 130px;
  height: 24px;
  
  /* CENTERING WITH ADJUSTMENT */
  display: flex;
  align-items: center;
  justify-content: center;
  
  font-size: 9px;
  font-weight: 800;
  letter-spacing: 1.3px;
  text-transform: uppercase;
  color: #ffffff;
  text-shadow: 0 2px 4px rgba(0, 0, 0, 0.6);
  
  background: linear-gradient(135deg, #8b5cf6, #7c3aed);
  transform: rotate(-45deg);
  transform-origin: center center;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.4);
  
  padding: 0;
  padding-top: 2px; /* ✅ TEXT KO NICHE SHIFT */
  margin: 0;
  border-radius: 0;
  
  /* FORCE PROPER LINE HEIGHT */
  line-height: 1.2;
  
  /* Ensure text doesn't wrap */
  white-space: nowrap;
  overflow: visible;
}

/* Status colors */
.status-badge.ongoing {
  background: linear-gradient(135deg, #8b5cf6, #7c3aed);
}

.status-badge.completed {
  background: linear-gradient(135deg, #ef4444, #dc2626);
}

/* ============================================
   RESPONSIVE BREAKPOINTS
   ============================================ */

/* Large Desktop (1200px+) */
@media (min-width: 1200px) {
  .status-badge {
    top: 14px;
    left: -23px;
    width: 135px;
    height: 26px;
    font-size: 9.5px;
    padding-top: 2px;
  }
}

/* Desktop (992px - 1199px) */
@media (min-width: 992px) and (max-width: 1199px) {
  .status-badge {
    top: 12px;
    left: -25px;
    width: 130px;
    height: 24px;
    font-size: 9px;
    padding-top: 2px;
  }
}

/* Tablet (768px - 991px) */
@media (min-width: 768px) and (max-width: 991px) {
  .status-badge {
    top: 11px;
    left: -27px;
    width: 120px;
    height: 22px;
    font-size: 8.5px;
    letter-spacing: 1.1px;
    padding-top: 2px;
  }
}

/* Mobile Landscape / Small Tablet (481px - 767px) */
@media (min-width: 481px) and (max-width: 767px) {
  .status-badge {
    top: 10px;
    left: -29px;
    width: 115px;
    height: 21px;
    font-size: 8px;
    letter-spacing: 1px;
    padding-top: 1.5px;
  }
}

/* Mobile Portrait (376px - 480px) */
@media (min-width: 376px) and (max-width: 480px) {
  .status-badge {
    top: 9px;
    left: -31px;
    width: 110px;
    height: 20px;
    font-size: 7.5px;
    letter-spacing: 0.9px;
    padding-top: 1.5px;
  }
}

/* Small Mobile (321px - 375px) */
@media (min-width: 321px) and (max-width: 375px) {
  .status-badge {
    top: 8px;
    left: -33px;
    width: 105px;
    height: 19px;
    font-size: 7px;
    letter-spacing: 0.8px;
    padding-top: 1px;
  }
}

/* Very Small Mobile (< 320px) */
@media (max-width: 320px) {
  .status-badge {
    top: 7px;
    left: -35px;
    width: 100px;
    height: 18px;
    font-size: 6.5px;
    letter-spacing: 0.7px;
    padding-top: 1px;
  }
}

/* ============================================
   DYNAMIC ADJUSTMENT BASED ON CARD SIZE
   ============================================ */

/* For very small cards */
.anime-card[data-size="small"] .status-badge,
.anime-grid[data-grid-size="small"] .status-badge {
  left: -35px;
  width: 100px;
  height: 18px;
  font-size: 6.5px;
  padding-top: 1px;
}

/* For medium cards */
.anime-card[data-size="medium"] .status-badge,
.anime-grid[data-grid-size="medium"] .status-badge {
  left: -28px;
  width: 115px;
  height: 21px;
  font-size: 8px;
  padding-top: 1.5px;
}

/* For large cards */
.anime-card[data-size="large"] .status-badge,
.anime-grid[data-grid-size="large"] .status-badge {
  left: -23px;
  width: 135px;
  height: 26px;
  font-size: 9.5px;
  padding-top: 2px;
}
</style>

<main>
    <?php if($showGenresList): ?>
    <!-- ALL GENRES LIST -->
    <div class="genre-hero">
        <div class="container">
            <h1>
                <i data-lucide="folder"></i>
                Browse All Genres
            </h1>
            <p><?php echo count($allGenres); ?> genres available</p>
        </div>
    </div>

    <div class="container">
        <div class="breadcrumb">
            <a href="/"><i data-lucide="home"></i> Home</a>
            <i data-lucide="chevron-right"></i>
            <span>Genres</span>
        </div>

        <div class="genres-list-grid">
            <?php foreach($allGenres as $g): ?>
            <a href="/genre/<?php echo urlencode($g); ?>" class="genre-card">
                <i data-lucide="tag"></i>
                <span><?php echo htmlspecialchars($g); ?></span>
            </a>
            <?php endforeach; ?>
        </div>
    </div>

    <?php else: ?>
    <!-- SPECIFIC GENRE ANIME LIST -->
    <div class="genre-hero">
        <div class="container">
            <h1>
                <i data-lucide="tag"></i>
                <?php echo htmlspecialchars(ucfirst($genre)); ?>
            </h1>
            <p><?php echo count($animeList); ?> anime found</p>
        </div>
    </div>

    <div class="container">
        <div class="breadcrumb">
            <a href="/"><i data-lucide="home"></i> Home</a>
            <i data-lucide="chevron-right"></i>
            <a href="/genre"><i data-lucide="folder"></i> Genres</a>
            <i data-lucide="chevron-right"></i>
            <span><?php echo htmlspecialchars(ucfirst($genre)); ?></span>
        </div>

        <?php if(count($animeList) > 0): ?>
        <div class="anime-grid">
            <?php foreach($animeList as $anime): ?>
<?php 
// Simple link to anime details page
$cardLink = "/anime/" . $anime['slug'];
?>

<a href="<?php echo $cardLink; ?>" class="anime-card">
    <div class="anime-card-image">
        <img src="<?php echo getPosterUrl($anime['poster']); ?>" 
             alt="<?php echo htmlspecialchars($anime['title']); ?>"
             loading="lazy">
        
        <!-- Play Overlay -->
        <div class="play-overlay">
            <div class="play-icon">
                <i data-lucide="play"></i>
            </div>
        </div>
        
        <!-- Badge Container -->
        <div class="badge-container">
            <?php if(!empty($anime['status'])): ?>
            <span class="status-badge <?php echo strtolower($anime['status']); ?>">
                <i data-lucide="<?php echo $anime['status'] == 'ongoing' ? 'play-circle' : 'check-circle'; ?>"></i>
                <?php echo ucfirst($anime['status']); ?>
            </span>
            <?php endif; ?>
        </div>
        
        <!-- Hot/Feature Badge -->
        <?php if($anime['is_hot']): ?>
        <div class="feature-badge">
            <img src="assets/hot.gif" alt="HOT" class="badge-gif">
        </div>
        <?php endif; ?>
        
        <!-- Episode Badge -->
        <?php 
        $epStmt = $pdo->prepare("SELECT episode_number FROM episodes WHERE anime_id = ? ORDER BY episode_number DESC LIMIT 1");
        $epStmt->execute([$anime['id']]);
        $latestEp = $epStmt->fetch();
        if($latestEp): 
        ?>
        <div class="episode-badge">
            EP <?php echo $latestEp['episode_number']; ?>
        </div>
        <?php endif; ?>
    </div>
    
    <div class="anime-card-info">
        <h3 class="anime-card-title"><?php echo htmlspecialchars($anime['title']); ?></h3>
    </div>
</a>
<?php endforeach; ?>
        </div>
        <?php else: ?>
        <div class="no-results">
            <i data-lucide="inbox"></i>
            <h3>No Anime Found</h3>
            <p>We couldn't find any anime in the <?php echo htmlspecialchars($genre); ?> genre.</p>
        </div>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</main>

<?php require_once 'footer.php'; ?>