<?php
// ================================
// SET UTF-8 ENCODING FOR PHP
// ================================
ini_set('default_charset', 'UTF-8');
mb_internal_encoding('UTF-8');
mb_http_output('UTF-8');

// ================================
// BASIC CONFIGURATION
// ================================

// Database Configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'yumestre_am');
define('DB_PASS', 'SAHORIAJ88');
define('DB_NAME', 'yumestre_novadong_lol');

// Site Configuration
define('SITE_URL', 'https://yumestream.in');
define('SITE_NAME', 'Yumestream');

// Upload folder (LOCAL ONLY)
define('LOCAL_UPLOAD_PATH', __DIR__ . '/uploads/');
define('LOCAL_UPLOAD_URL', SITE_URL . '/uploads/');

// ================================
// DATABASE CONNECTION WITH UTF-8
// ================================

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );
    
    // FORCE UTF-8MB4 ENCODING
    $pdo->exec("SET NAMES utf8mb4");
    $pdo->exec("SET CHARACTER SET utf8mb4");
    $pdo->exec("SET character_set_connection=utf8mb4");
    $pdo->exec("SET character_set_client=utf8mb4");
    $pdo->exec("SET character_set_results=utf8mb4");
    
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// ================================
// HELPER FUNCTIONS
// ================================

function sanitize($data) {
    // Simple: just clean and trim - no HTML encoding
    return trim(strip_tags($data));
}

function createSlug($string) {
    // Handle UTF-8 characters properly in slugs
    $slug = mb_strtolower($string, 'UTF-8');
    $slug = preg_replace('/[^a-z0-9\s-]/u', '', $slug);
    $slug = preg_replace('/[\s-]+/', '-', $slug);
    return trim($slug, '-');
}

// ================================
// IMAGE UPLOAD SYSTEM (LOCAL ONLY)
// ================================

function uploadImage($file) {
    if (!isset($file['error']) || $file['error'] !== UPLOAD_ERR_OK) {
        return false;
    }

    $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    $filename = $file['name'];
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

    if (!in_array($ext, $allowed)) {
        return false;
    }

    if (!is_dir(LOCAL_UPLOAD_PATH)) {
        mkdir(LOCAL_UPLOAD_PATH, 0755, true);
    }

    $newname = uniqid() . '_' . time() . '.' . $ext;
    $destination = LOCAL_UPLOAD_PATH . $newname;

    if (move_uploaded_file($file['tmp_name'], $destination)) {
        return 'uploads/' . $newname; // Stored in DB
    }

    return false;
}

// Delete image from uploads/
function deleteImage($path) {
    $path = ltrim($path, '/');
    $fullPath = LOCAL_UPLOAD_PATH . basename($path);

    if (file_exists($fullPath)) {
        return @unlink($fullPath);
    }

    return false;
}

// ================================
// AUTO FIX OLD CDN URLs
// ================================

function removeOldCDN($value) {
    if (!$value) return $value;

    // All possible old CDN domains
    $oldCDNs = [
        'https://cdn.novadonghua.top/',
        'http://cdn.novadonghua.top/',
        'https://cdn.yumestream.in/',
        'http://cdn.yumestream.in/'
    ];

    foreach ($oldCDNs as $cdn) {
        if (strpos($value, $cdn) !== false) {
            return str_replace($cdn, 'uploads/', $value);
        }
    }

    return $value;
}

// ================================
// IMAGE URL BUILDER
// ================================

function getImageUrl($path, $default = 'uploads/default.jpg') {
    if (empty($path)) {
        return SITE_URL . '/' . $default;
    }

    // Auto-remove old CDN URLs
    $path = removeOldCDN($path);

    // External URL (IMDB, TMDB, etc.)
    if (filter_var($path, FILTER_VALIDATE_URL)) {
        return $path;
    }

    return SITE_URL . '/' . ltrim($path, '/');
}

// Backward compatibility
function getPosterUrl($poster) {
    return getImageUrl($poster, 'uploads/default.jpg');
}

// ================================
// SITE SETTINGS SYSTEM
// ================================

function getSiteSetting($key, $default = '') {
    global $pdo;

    try {
        $stmt = $pdo->prepare("SELECT setting_value FROM site_settings WHERE setting_key = ?");
        $stmt->execute([$key]);
        $result = $stmt->fetch();
        return $result ? $result['setting_value'] : $default;
    } catch(PDOException $e) {
        return $default;
    }
}

function setSiteSetting($key, $value) {
    global $pdo;

    try {
        $stmt = $pdo->prepare("
            INSERT INTO site_settings (setting_key, setting_value)
            VALUES (?, ?)
            ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)
        ");
        return $stmt->execute([$key, $value]);
    } catch(PDOException $e) {
        return false;
    }
}

function getMenuItems($menuKey) {
    $menu = getSiteSetting($menuKey, '[]');
    return json_decode($menu, true) ?: [];
}

// ================================
// MEMBERSHIP SYSTEM
// ================================

function getUserMembershipStatus($userId) {
    global $pdo;

    try {
        $stmt = $pdo->prepare("
            SELECT is_verified, membership_expires_at 
            FROM users 
            WHERE id = ? AND status = 'active'
        ");
        $stmt->execute([$userId]);
        $user = $stmt->fetch();

        if (!$user || $user['is_verified'] != 1) {
            return 'none';
        }

        if ($user['membership_expires_at'] === null) {
            return 'lifetime';
        }

        $expiry = strtotime($user['membership_expires_at']);
        return ($expiry > time()) ? 'active' : 'expired';

    } catch(PDOException $e) {
        return 'none';
    }
}

function getMembershipExpiryDate($userId) {
    global $pdo;

    try {
        $stmt = $pdo->prepare("SELECT membership_expires_at FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $user = $stmt->fetch();

        return $user ? $user['membership_expires_at'] : null;
    } catch(PDOException $e) {
        return null;
    }
}

function shouldShowAds() {
    if (!isset($_SESSION['user_id'])) {
        return true;
    }

    global $pdo;
    $userId = $_SESSION['user_id'];

    try {
        $stmt = $pdo->prepare("
            SELECT is_verified, membership_expires_at 
            FROM users 
            WHERE id = ? AND status = 'active'
        ");
        $stmt->execute([$userId]);
        $user = $stmt->fetch();

        if (!$user || $user['is_verified'] != 1) {
            return true;
        }

        if ($user['membership_expires_at'] === null) {
            return false;
        }

        return strtotime($user['membership_expires_at']) <= time();

    } catch(PDOException $e) {
        return true;
    }
}

function displayAd($adCode, $adPosition = '') {
    if (!shouldShowAds()) return;

    $pos = $adPosition ? ' ad-' . htmlspecialchars($adPosition, ENT_QUOTES, 'UTF-8') : '';
    echo "<div class='ad-container{$pos}'>$adCode</div>";
}

function displayAdFromSettings($key, $pos = '') {
    if (!shouldShowAds()) return;

    $ad = getSiteSetting($key, '');
    if ($ad) displayAd($ad, $pos);
}

function getMembershipBadge() {
    if (!isset($_SESSION['user_id'])) return '';

    global $pdo;
    $userId = $_SESSION['user_id'];

    try {
        $stmt = $pdo->prepare("
            SELECT is_verified, membership_expires_at 
            FROM users 
            WHERE id = ?
        ");
        $stmt->execute([$userId]);
        $user = $stmt->fetch();

        if (!$user || $user['is_verified'] != 1) {
            return '<span class="membership-badge free">Free</span>';
        }

        if ($user['membership_expires_at'] === null) {
            return '<span class="membership-badge lifetime">Lifetime</span>';
        }

        $expiry = strtotime($user['membership_expires_at']);
        $days = ceil(($expiry - time()) / 86400);

        return ($expiry > time())
            ? "<span class='membership-badge premium'>Premium ($days days)</span>"
            : "<span class='membership-badge expired'>Expired</span>";

    } catch(PDOException $e) {
        return '';
    }
}


// ================================
// START SESSION WITH UTF-8
// ================================
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ================================
// SET CONTENT TYPE HEADER
// ================================
if (!headers_sent()) {
    header('Content-Type: text/html; charset=UTF-8');
}
?>