<?php
// At the top - but NO require_auth.php
require_once 'config.php';
require_once 'auth.php';

// Check if logged in (but don't redirect)
$isLoggedIn = isLoggedIn();
if ($isLoggedIn) {
    $currentUser = getCurrentUser();
}

// Get dynamic settings
$header_logo = getSiteSetting('header_logo', 'https://blogger.googleusercontent.com/img/a/AVvXsEiM-qT1Af7WlPoO55lrQ67eZ9EviqkgBjB5GwosWl-N3iK5Yp9zZpkRgzm4Yitl78EAFV2wvNNKAJ6TlmNp6i7slTpXylHiVZN8lnAptigt0KXkJUVqnFiX5GHofLIilFHit4sZTcu5Nam58cCp25WZ4yJJ5KR9jSTJzqbchhoUjmUxDg0uedGnvlh7C_ZF=w800');
$header_menu = getMenuItems('header_menu');

// Get code injection settings
$header_code = getSiteSetting('header_code', '');
$after_body_open = getSiteSetting('after_body_open', '');

// ======== DEFAULT SEO CONFIG ========
$site_name = "Yumestream";
$default_description = "Watch the latest Chinese anime (Donghua) online in English subtitles and HD quality for free. Stay updated with new episodes daily.";
$default_title = "Yumestream- Watch Chinese Anime (Donghua) Online Free with English Sub";

// ======== PAGE DETECTION & CANONICAL ========
$current_page = basename($_SERVER['PHP_SELF']);
$canonical_url = "";

// Determine canonical URL
if ($current_page === '/watch/' && isset($slug) && !empty($slug)) {
    $canonical_url = "https://yumestream.in/watch/" . htmlspecialchars($slug);
} elseif ($current_page === '/anime/' && isset($_GET['slug'])) {
    $canonical_url = "https://yumestream.in/anime/" . htmlspecialchars($_GET['slug']);
} elseif ($current_page === 'index.php' || $_SERVER['REQUEST_URI'] === '/') {
    $canonical_url = "https://yumestream.in/";
}

// Fallback if no canonical URL set
if (empty($canonical_url)) {
    $canonical_url = "https://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
}

// ======== FALLBACK TITLE & DESCRIPTION ========
if (!isset($page_title) || empty($page_title)) {
    if ($current_page === 'index.php' || $_SERVER['REQUEST_URI'] === '/') {
        $page_title = $default_title;
    } else {
        $page_title = "Watch Chinese Anime Online"; // Don't use $site_name
    }
}

if (!isset($page_description) || empty($page_description)) {
    $page_description = $default_description;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<?php 
// Output custom header code
if (!empty($header_code)) {
    echo "\n<!-- Custom Header Code -->\n";
    echo $header_code . "\n";
    echo "<!-- End Custom Header Code -->\n";
}

// Header Ad Script
if (shouldShowAds()) {
    $headerAdCode = getSiteSetting('ad_header', '');
    if (!empty($headerAdCode)) {
        echo "\n<!-- Header Ad Code -->\n";
        echo $headerAdCode . "\n";
        echo "<!-- End Header Ad Code -->\n";
    }
}
?>
<!-- Favicon -->
<!-- Apple Icons -->
<link rel="apple-touch-icon" sizes="180x180" href="/logo/apple-touch-icon.png">

<!-- Standard Favicons -->
<link rel="icon" type="image/png" sizes="32x32" href="/logo/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/logo/favicon-16x16.png">
<link rel="icon" href="/logo/favicon.ico">

<!-- Android Chrome Icons -->
<link rel="icon" type="image/png" sizes="192x192" href="/logo/android-chrome-192x192.png">
<link rel="icon" type="image/png" sizes="512x512" href="/logo/android-chrome-512x512.png">

<title><?php echo htmlspecialchars($page_title); ?></title>
<meta name="description" content="<?php echo htmlspecialchars($page_description); ?>">
<meta name="robots" content="index, follow">
<link rel="canonical" href="<?php echo htmlspecialchars($canonical_url); ?>">

<!-- Open Graph -->
<meta property="og:type" content="website">
<meta property="og:site_name" content="<?php echo htmlspecialchars($site_name); ?>">
<meta property="og:title" content="<?php echo htmlspecialchars($page_title); ?>">
<meta property="og:description" content="<?php echo htmlspecialchars($page_description); ?>">
<meta property="og:url" content="<?php echo htmlspecialchars($canonical_url); ?>">
<meta property="og:image" content="https://yumestream.in/logo.jpg">

<!-- Twitter Card -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="<?php echo htmlspecialchars($page_title); ?>">
<meta name="twitter:description" content="<?php echo htmlspecialchars($page_description); ?>">
<meta name="twitter:image" content="https://yumestream.in/logo.jpg">

<meta name="author" content=Yumestream Team">

<!-- Preconnect hints -->
<link rel="preconnect" href="https://unpkg.com">

<?php $cssVersion = time(); ?>

<!-- Preload main CSS -->
<link rel="preload" href="https://sahoriaj.github.io/YumeStream/main.css?v=<?php echo $cssVersion; ?>" as="style">

<!-- Load main CSS without blocking -->
<link rel="stylesheet" href="https://sahoriaj.github.io/YumeStream/main.css?v=<?php echo $cssVersion; ?>" media="print" onload="this.media='all'">

<!-- No-JS fallback -->
<noscript>
    <link rel="stylesheet" href="https://sahoriaj.github.io/YumeStream/main.css?v=<?php echo $cssVersion; ?>">
</noscript>

<!-- Lucide Icons (deferred - no longer blocking) -->
<script src="https://unpkg.com/lucide@latest" defer></script>

</head>

<body>
<?php 
// Output custom code after body open
if (!empty($after_body_open)) {
    echo "\n<!-- Custom Code After Body Open -->\n";
    echo $after_body_open . "\n";
    echo "<!-- End Custom Code After Body Open -->\n";
}
?>

<!-- Header -->
<header class="site-header">
  <div class="header-container">
    <!-- Menu Toggle -->
    <div class="nav-toggle" id="navToggle">
      <i data-lucide="menu"></i>
    </div>

    <!-- Logo -->
    <a href="/" class="logo" aria-label="Yumestream">
      <img
        src="<?php echo htmlspecialchars($header_logo); ?>"
        alt="Yumestream"
        width="150"
        height="40"
        loading="lazy"
        onerror="this.src='https://via.placeholder.com/150x40?text=Logo'"
      />
    </a>

    <!-- Right Controls -->
    <div class="header-controls">
      <!-- Dark Mode Switch -->
      <label class="theme-switch">
        <input type="checkbox" id="themeToggle" aria-label="Toggle dark mode">
        <span class="slider round"></span>
        <i class="sun-icon" data-lucide="sun"></i>
        <i class="moon-icon" data-lucide="moon"></i>
      </label>

      <!-- Search Toggle -->
      <button class="search-toggle" id="searchToggle" aria-label="Toggle search">
        <i data-lucide="search"></i>
      </button>
    </div>
  </div>
</header>

<!-- Right Slide Menu - Dynamic -->
<nav class="nav-menu" id="navMenu">
  <ul>
    <?php foreach($header_menu as $item): ?>
    <li>
      <a href="<?php echo htmlspecialchars($item['url']); ?>">
        <i data-lucide="<?php echo htmlspecialchars($item['icon']); ?>"></i>
        <?php echo htmlspecialchars($item['label']); ?>
      </a>
    </li>
    <?php endforeach; ?>
  </ul>
</nav>

<!-- Search Overlay (Hidden by default) -->
<div class="search-overlay" id="searchOverlay">
    <div class="search-overlay-content">
        <div class="search-box">
            <div class="search-box-inner">
                <input type="text" id="liveSearch" placeholder="Search..." autocomplete="off">
                <button class="search-close" id="searchClose" aria-label="Close search">
                    <i data-lucide="x"></i>
                </button>
            </div>
        </div>
        <div class="search-results" id="searchResults"></div>
    </div>
</div>

<script>
// Search Toggle Functionality
document.addEventListener('DOMContentLoaded', function() {
  const searchToggle = document.getElementById('searchToggle');
  const searchOverlay = document.getElementById('searchOverlay');
  const searchClose = document.getElementById('searchClose');
  const searchInput = document.getElementById('liveSearch');

  // Open search overlay
  if (searchToggle) {
    searchToggle.addEventListener('click', function() {
      searchOverlay.classList.add('active');
      // Focus on input after animation
      setTimeout(() => {
        searchInput.focus();
      }, 300);
    });
  }

  // Close search overlay
  if (searchClose) {
    searchClose.addEventListener('click', function() {
      searchOverlay.classList.remove('active');
    });
  }

  // Close on overlay click (not on content)
  if (searchOverlay) {
    searchOverlay.addEventListener('click', function(e) {
      if (e.target === searchOverlay) {
        searchOverlay.classList.remove('active');
      }
    });
  }

  // Close on Escape key
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && searchOverlay.classList.contains('active')) {
      searchOverlay.classList.remove('active');
    }
  });

  // Initialize Lucide icons for dynamically added elements
  if (typeof lucide !== 'undefined') {
    lucide.createIcons();
  }
});
</script>
<script>
document.addEventListener("DOMContentLoaded", function () {
    lucide.createIcons();
});
</script>

<div class="social-banners">  
  <!-- Telegram Banner -->  
  <div class="telegram-banner">  
    <div class="banner-text">Stay updated with latest donghua releases!</div>  
    <a href="https://t.me/novadonghua" target="_blank" class="telegram-btn">  
      <svg xmlns="http://www.w3.org/2000/svg" class="icon" viewBox="0 0 24 24" fill="currentColor">
        <path d="M9.999 15.2L9.89 19.293c.4 0 .574-.172.782-.379l1.874-1.801 3.884 2.845c.712.393 1.22.186 1.405-.659l2.547-11.936c.26-1.194-.43-1.66-1.178-1.368L3.82 9.787c-1.163.454-1.146 1.106-.198 1.4l3.959 1.233 9.178-5.803c.432-.262.827-.117.502.145" />
      </svg>
      Join our Telegram Channel  
    </a>  
  </div>  
</div>  
  
<style>  
.social-banners {  
  display: flex;  
  flex-direction: column;  
  align-items: center;  
  gap: 10px;  
  margin: 10px 0;  
}  
  
.banner-text {
  font-size: 17px;
  color: crimson;     /* Text will stay crimson in both light & dark mode */
  margin-bottom: 8px;
  font-weight: 500;
  text-align: center;
}
  
.telegram-banner {  
  display: flex;  
  flex-direction: column;  
  align-items: center;  
  padding: 2px 50px;  
}  
  
.telegram-btn {  
  display: inline-flex;  
  align-items: center;  
  justify-content: center;  
  gap: 10px;  
  padding: 12px 28px;  
  font-size: 17px;  
  font-weight: 600;  
  color: #fff;  
  border-radius: 28px;  
  text-decoration: none;  
  transition: background 0.3s, box-shadow 0.3s;  
  margin-bottom: 16px;  
  background: linear-gradient(90deg, #4f8aff 0%, #28e0e3 100%);  
  box-shadow: 0 4px 18px rgba(40,224,227,0.15);  
}  
  
.telegram-btn:hover {  
  background: linear-gradient(90deg, #28e0e3 0%, #4f8aff 100%);  
  box-shadow: 0 6px 24px rgba(40,224,227,0.25);  
}  
  
.icon {  
  width: 20px;  
  height: 20px;  
  fill: currentColor;  
  vertical-align: middle;  
}  
</style>
</body>
</html>