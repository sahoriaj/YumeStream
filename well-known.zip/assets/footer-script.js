// Load footer scripts after page load
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', loadFooterScripts);
} else {
  loadFooterScripts();
}

function loadFooterScripts() {
  // Footer initialization
  console.log('Footer loaded');
}