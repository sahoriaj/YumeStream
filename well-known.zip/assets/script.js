/* ============================================================
   SITEMAP AUTO GEN
   ============================================================ */
(function () {
  const INTERVAL = 10 * 60 * 1000;
  const KEY = "sitemap_last_gen";

  function shouldGen() {
    const last = localStorage.getItem(KEY);
    if (!last) return true;
    return Date.now() - parseInt(last) >= INTERVAL;
  }

  function generate() {
    if (!shouldGen()) return;

    fetch("/generate_sitemap_direct.php?auto=true")
      .then(r => r.json())
      .then(d => {
        if (d.success) {
          localStorage.setItem(KEY, Date.now().toString());
          console.log("Sitemap auto-generated:", d.timestamp);
        }
      })
      .catch(err => console.error("Sitemap error:", err));
  }

  generate();
  setInterval(generate, INTERVAL);
})();

/* ============================================================
   FOOTER INITIALIZATION
   ============================================================ */
function loadFooterScripts() {
  console.log("Footer loaded");
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", loadFooterScripts);
} else {
  loadFooterScripts();
}

/* ============================================================
   LUCIDE ICONS
   ============================================================ */
function reinitializeLucideIcons() {
  if (typeof lucide !== "undefined") {
    lucide.createIcons();
  }
}

document.addEventListener("DOMContentLoaded", () => {
  if (typeof lucide !== "undefined") {
    lucide.createIcons();
  }
});

window.addEventListener("load", () => {
  if (typeof lucide !== "undefined") {
    lucide.createIcons();
  }
});

/* ============================================================
   DARK MODE
   ============================================================ */
document.addEventListener("DOMContentLoaded", function () {
  const themeToggle = document.getElementById("themeToggle");
  const body = document.body;

  if (localStorage.getItem("theme") === "dark") {
    body.classList.add("dark-mode");
    if (themeToggle) themeToggle.checked = true;
  }

  if (themeToggle) {
    themeToggle.addEventListener("change", () => {
      const dark = themeToggle.checked;
      body.classList.toggle("dark-mode", dark);
      localStorage.setItem("theme", dark ? "dark" : "light");
    });
  }
});

/* ============================================================
   NAV MENU
   ============================================================ */
document.addEventListener("DOMContentLoaded", function () {
  const navToggle = document.getElementById("navToggle");
  const navMenu = document.getElementById("navMenu");

  if (navToggle && navMenu) {
    navToggle.addEventListener("click", function (e) {
      e.stopPropagation();
      navMenu.classList.toggle("active");
      reinitializeLucideIcons();
    });

    document.addEventListener("click", function (e) {
      if (!navMenu.contains(e.target) && !navToggle.contains(e.target)) {
        navMenu.classList.remove("active");
      }
    });
  }
});

/* ============================================================
   LIVE SEARCH
   ============================================================ */
document.addEventListener("DOMContentLoaded", function () {
  const searchInput = document.getElementById("liveSearch");
  const searchResults = document.getElementById("searchResults");

  if (!searchInput || !searchResults) return;

  let searchTimeout;
  let abortController;

  searchInput.addEventListener("input", function () {
    clearTimeout(searchTimeout);
    if (abortController) abortController.abort();

    const query = this.value.trim();
    if (query.length < 2) {
      searchResults.style.display = "none";
      return;
    }

    searchTimeout = setTimeout(() => {
      abortController = new AbortController();

      fetch("search.php?q=" + encodeURIComponent(query), {
        signal: abortController.signal,
      })
        .then(res => res.json())
        .then(data => {
          if (data.length > 0) {
            searchResults.innerHTML = data.map(a => `
              <a href="/anime/${a.slug}" class="search-result-item">
                <img src="${a.poster || '/uploads/default.jpg'}" 
                     alt="${a.title}" loading="lazy">
                <div class="search-result-info">
                  <h4>${a.title}</h4>
                  <p>${(a.synopsis || "").slice(0, 100)}...</p>
                </div>
              </a>
            `).join("");

            searchResults.style.display = "block";
            reinitializeLucideIcons();
          } else {
            searchResults.innerHTML =
              '<div style="padding:20px;text-align:center;">No results found</div>';
            searchResults.style.display = "block";
          }
        })
        .catch(err => {
          if (err.name !== "AbortError") console.error("Search error:", err);
        });
    }, 300);
  });

  document.addEventListener("click", function (e) {
    if (!searchInput.contains(e.target) && !searchResults.contains(e.target)) {
      searchResults.style.display = "none";
    }
  });
});

/* ============================================================
   GLOBAL IMAGE ERROR HANDLING
   ============================================================ */
document.addEventListener("DOMContentLoaded", function () {
  document.addEventListener("error", function (e) {
    if (e.target.tagName === "IMG") {
      e.target.src = "/uploads/default.jpg";
    }
  }, true);
});
