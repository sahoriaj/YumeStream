<?php
require_once 'config.php';

// Pagination settings
$itemsPerPage = 15;
$currentPage = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$offset = ($currentPage - 1) * $itemsPerPage;

// Get total count
$totalCount = $pdo->query("SELECT COUNT(*) FROM anime")->fetchColumn();
$totalPages = ceil($totalCount / $itemsPerPage);

// Get anime with pagination
$stmt = $pdo->prepare("SELECT * FROM anime ORDER BY update_date DESC LIMIT ? OFFSET ?");
$stmt->execute([$itemsPerPage, $offset]);
$animeList = $stmt->fetchAll();

// Helper function to get latest episode number
function getLatestEpisodeNumber($pdo, $anime_id) {
    $stmt = $pdo->prepare("SELECT MAX(episode_number) FROM episodes WHERE anime_id = ?");
    $stmt->execute([$anime_id]);
    return $stmt->fetchColumn();
}

// Helper function to get latest episode slug
function getLatestEpisodeSlug($pdo, $anime_id) {
    $stmt = $pdo->prepare("SELECT slug FROM episodes WHERE anime_id = ? ORDER BY episode_number DESC LIMIT 1");
    $stmt->execute([$anime_id]);
    $result = $stmt->fetchColumn();
    return $result ? $result : null;
}

$page_title = 'All Anime - Yumestream';
require_once 'header.php';
?>
<style>
/* Main Content Styling */
.main-content {
    min-height: 100vh;
    padding: 2rem 0;
}

.container {
    max-width: 1400px;
    margin: 0 auto;
    padding: 0 20px;
}

/* Page Header */
.page-header {
    margin-bottom: 30px;
}

.page-header h1 {
    font-size: 28px;
    font-weight: 700;
    color: #1f2937;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 10px;
}

body.dark-mode .page-header h1 {
    color: #ffffff;
}

/* ============================================
   STATUS RIBBON - TEXT PERFECTLY CENTERED (SHIFTED DOWN)
   ============================================ */

/* IMPORTANT: Make sure parent .anime-card has overflow: visible */
.anime-card {
  position: relative;
  overflow: visible; /* CRITICAL */
}

.badge-container {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 6;
  pointer-events: none;
  overflow: visible;
}

.status-badge {
  position: absolute;
  top: 12px;
  left: -25px;
  
  width: 130px;
  height: 24px;
  
  /* CENTERING WITH ADJUSTMENT */
  display: flex;
  align-items: center;
  justify-content: center;
  
  font-size: 9px;
  font-weight: 800;
  letter-spacing: 1.3px;
  text-transform: uppercase;
  color: #ffffff;
  text-shadow: 0 2px 4px rgba(0, 0, 0, 0.6);
  
  background: linear-gradient(135deg, #8b5cf6, #7c3aed);
  transform: rotate(-45deg);
  transform-origin: center center;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.4);
  
  padding: 0;
  padding-top: 2px; /* ✅ TEXT KO NICHE SHIFT */
  margin: 0;
  border-radius: 0;
  
  /* FORCE PROPER LINE HEIGHT */
  line-height: 1.2;
  
  /* Ensure text doesn't wrap */
  white-space: nowrap;
  overflow: visible;
}

/* Status colors */
.status-badge.ongoing {
  background: linear-gradient(135deg, #8b5cf6, #7c3aed);
}

.status-badge.completed {
  background: linear-gradient(135deg, #ef4444, #dc2626);
}

/* ============================================
   RESPONSIVE BREAKPOINTS
   ============================================ */

/* Large Desktop (1200px+) */
@media (min-width: 1200px) {
  .status-badge {
    top: 14px;
    left: -23px;
    width: 135px;
    height: 26px;
    font-size: 9.5px;
    padding-top: 2px;
  }
}

/* Desktop (992px - 1199px) */
@media (min-width: 992px) and (max-width: 1199px) {
  .status-badge {
    top: 12px;
    left: -25px;
    width: 130px;
    height: 24px;
    font-size: 9px;
    padding-top: 2px;
  }
}

/* Tablet (768px - 991px) */
@media (min-width: 768px) and (max-width: 991px) {
  .status-badge {
    top: 11px;
    left: -27px;
    width: 120px;
    height: 22px;
    font-size: 8.5px;
    letter-spacing: 1.1px;
    padding-top: 2px;
  }
}

/* Mobile Landscape / Small Tablet (481px - 767px) */
@media (min-width: 481px) and (max-width: 767px) {
  .status-badge {
    top: 10px;
    left: -29px;
    width: 115px;
    height: 21px;
    font-size: 8px;
    letter-spacing: 1px;
    padding-top: 1.5px;
  }
}

/* Mobile Portrait (376px - 480px) */
@media (min-width: 376px) and (max-width: 480px) {
  .status-badge {
    top: 9px;
    left: -31px;
    width: 110px;
    height: 20px;
    font-size: 7.5px;
    letter-spacing: 0.9px;
    padding-top: 1.5px;
  }
}

/* Small Mobile (321px - 375px) */
@media (min-width: 321px) and (max-width: 375px) {
  .status-badge {
    top: 8px;
    left: -33px;
    width: 105px;
    height: 19px;
    font-size: 7px;
    letter-spacing: 0.8px;
    padding-top: 1px;
  }
}

/* Very Small Mobile (< 320px) */
@media (max-width: 320px) {
  .status-badge {
    top: 7px;
    left: -35px;
    width: 100px;
    height: 18px;
    font-size: 6.5px;
    letter-spacing: 0.7px;
    padding-top: 1px;
  }
}

/* ============================================
   DYNAMIC ADJUSTMENT BASED ON CARD SIZE
   ============================================ */

/* For very small cards */
.anime-card[data-size="small"] .status-badge,
.anime-grid[data-grid-size="small"] .status-badge {
  left: -35px;
  width: 100px;
  height: 18px;
  font-size: 6.5px;
  padding-top: 1px;
}

/* For medium cards */
.anime-card[data-size="medium"] .status-badge,
.anime-grid[data-grid-size="medium"] .status-badge {
  left: -28px;
  width: 115px;
  height: 21px;
  font-size: 8px;
  padding-top: 1.5px;
}

/* For large cards */
.anime-card[data-size="large"] .status-badge,
.anime-grid[data-grid-size="large"] .status-badge {
  left: -23px;
  width: 135px;
  height: 26px;
  font-size: 9.5px;
  padding-top: 2px;
}

/* Pagination Styles */
.pagination-container {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 10px;
    margin: 40px 0 60px;
    flex-wrap: wrap;
    padding: 0 20px;
}

.pagination-btn {
    padding: 10px 20px;
    background: transparent;
    border: 1px solid #e5e7eb;
    color: #374151;
    text-decoration: none;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 500;
    transition: all 0.3s ease;
    white-space: nowrap;
    cursor: pointer;
}

.pagination-btn:hover:not(.disabled):not(.active) {
    background: #f3f4f6;
    border-color: #d1d5db;
    transform: translateY(-2px);
}

.pagination-btn.active {
    background: #f97316;
    color: white;
    border-color: #f97316;
    font-weight: 700;
    cursor: default;
}

.pagination-btn.disabled {
    opacity: 0.4;
    cursor: not-allowed;
    pointer-events: none;
}

/* Dark mode pagination */
body.dark-mode .pagination-btn {
    border-color: #374151;
    color: #e5e7eb;
}

body.dark-mode .pagination-btn:hover:not(.disabled):not(.active) {
    background: #374151;
    border-color: #4b5563;
}

body.dark-mode .pagination-btn.active {
    background: #f97316;
    color: white;
    border-color: #f97316;
}

/* Responsive Design */
@media (max-width: 480px) {
    
    .pagination-btn {
        padding: 8px 12px;
        font-size: 13px;
    }
    
    .pagination-container {
        gap: 6px;
    }
    
    .page-header h1 {
        font-size: 24px;
    }
}
</style>

<main class="main-content">
    <div class="container">
        
        <div class="page-header">
            <h1>
                <i data-lucide="grid-3x3" style="width:24px;height:24px;"></i>
                All Anime
            </h1>
        </div>

        <div class="anime-grid">
            <?php foreach($animeList as $anime): ?>
                <?php 
                $latestEpisode = getLatestEpisodeNumber($pdo, $anime['id']);
                $latestEpisodeSlug = getLatestEpisodeSlug($pdo, $anime['id']);
                $cardLink = $latestEpisodeSlug ? "https://yumestream.in/watch/" . $latestEpisodeSlug : "https://yumestream.in/anime/" . $anime['slug'];
                ?>
                <a href="<?php echo $cardLink; ?>" class="anime-card">
                    <div class="anime-card-image">
                        <img src="<?php echo getPosterUrl($anime['poster']); ?>" 
                             alt="<?php echo htmlspecialchars($anime['title']); ?>"
                             loading="lazy"
                             onerror="this.src='uploads/default.jpg'">
                        
                        <div class="play-overlay">
                            <div class="play-icon">
                                <i data-lucide="play"></i>
                            </div>
                        </div>
                        
                        <div class="badge-container">
    <span class="status-badge <?php echo $anime['status']; ?>">
        <?php echo ucfirst($anime['status']); ?>
    </span>
</div>
                        
      <?php if($anime['is_hot']): ?>
    <span class="feature-badge hot">
        <i data-lucide="flame" class="badge-icon"></i>
    </span>
<?php elseif($anime['is_new']): ?>
    <span class="feature-badge new">
        <i data-lucide="sparkles" class="badge-icon"></i>
    </span>
<?php endif; ?>
                        
                        <?php if($latestEpisode): ?>
                            <span class="episode-badge">
                                Ep <?php echo $latestEpisode; ?>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="anime-card-info">
                        <div class="anime-card-title"><?php echo htmlspecialchars($anime['title']); ?></div>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>

        <!-- Pagination -->
        <?php if($totalPages > 1): ?>
        <div class="pagination-container">
            <!-- First Page -->
            <a href="?page=1" class="pagination-btn <?php echo $currentPage == 1 ? 'disabled' : ''; ?>">
                front page
            </a>
            
            <!-- Previous Page -->
            <a href="?page=<?php echo max(1, $currentPage - 1); ?>" class="pagination-btn <?php echo $currentPage == 1 ? 'disabled' : ''; ?>">
                Previous Page
            </a>
            
            <!-- Current Page Number -->
            <span class="pagination-btn active">
                <?php echo $currentPage; ?>/<?php echo $totalPages; ?>
            </span>
            
            <!-- Next Page -->
            <a href="?page=<?php echo min($totalPages, $currentPage + 1); ?>" class="pagination-btn <?php echo $currentPage == $totalPages ? 'disabled' : ''; ?>">
                Next page
            </a>
            
            <!-- Last Page -->
            <a href="?page=<?php echo $totalPages; ?>" class="pagination-btn <?php echo $currentPage == $totalPages ? 'disabled' : ''; ?>">
                Last page
            </a>
        </div>
        <?php endif; ?>
    </div>
</main>

<?php require_once 'footer.php'; ?>