<?php
session_start();

// If user is already logged in, redirect to homepage
if(isset($_SESSION['user_id']) && isset($_SESSION['logged_in'])) {
    header('Location: /');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Yumestream</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .login-container {
            background: #fff;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
            width: 450px;
            max-width: 90%;
        }
        
        .login-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 40px;
            text-align: center;
            color: #fff;
        }
        
        .login-header h1 {
            font-size: 32px;
            margin-bottom: 10px;
        }
        
        .login-header p {
            opacity: 0.9;
        }
        
        .login-form {
            padding: 40px;
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .form-group label i {
            color: #667eea;
        }
        
        .form-group input {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 15px;
            transition: all 0.3s;
        }
        
        .form-group input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 10px rgba(102,126,234,0.2);
        }
        
        .error {
            background: #fee;
            color: #c33;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            display: none;
        }
        
        .error.active {
            display: flex;
        }
        
        .success {
            background: #efe;
            color: #3c3;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            display: none;
        }
        
        .success.active {
            display: flex;
        }
        
        .btn {
            width: 100%;
            padding: 15px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #fff;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        
        .btn:hover:not(:disabled) {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(102,126,234,0.4);
        }
        
        .btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }
        
        .divider {
            text-align: center;
            margin: 25px 0;
            position: relative;
        }
        
        .divider::before {
            content: '';
            position: absolute;
            left: 0;
            top: 50%;
            width: 100%;
            height: 1px;
            background: #e0e0e0;
        }
        
        .divider span {
            background: #fff;
            padding: 0 15px;
            position: relative;
            color: #666;
            font-size: 14px;
        }
        
        .social-login {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        
        .social-btn {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            background: #fff;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            font-size: 15px;
            font-weight: 600;
            color: #333;
        }
        
        .social-btn:hover {
            border-color: #667eea;
            background: #f8f9ff;
        }
        
        .social-btn i {
            font-size: 18px;
        }
        
        .google-btn i {
            color: #DB4437;
        }
        
        .form-footer {
            text-align: center;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #e0e0e0;
        }
        
        .form-footer a {
            color: #667eea;
            text-decoration: none;
            font-weight: 600;
        }
        
        .form-footer a:hover {
            text-decoration: underline;
        }
        
        .back-home {
            text-align: center;
            margin-top: 15px;
        }
        
        .back-home a {
            color: #666;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
        }
        
        .back-home a:hover {
            color: #667eea;
        }
        
        .loading {
            display: none;
        }
        
        .loading.active {
            display: inline-block;
            width: 16px;
            height: 16px;
            border: 2px solid #fff;
            border-top-color: transparent;
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <h1><i class="fas fa-tv"></i> Yumestream </h1>
            <p>Welcome Back!</p>
        </div>
        <div class="login-form">
            <div class="error" id="errorMsg">
                <i class="fas fa-exclamation-circle"></i>
                <span id="errorText"></span>
            </div>
            
            <div class="success" id="successMsg">
                <i class="fas fa-check-circle"></i>
                <span id="successText"></span>
            </div>
            
            <div class="social-login">
                <button class="social-btn google-btn" id="googleSignIn">
                    <i class="fab fa-google"></i>
                    <span>Continue with Google</span>
                    <span class="loading"></span>
                </button>
            </div>
            
            <div class="divider">
                <span>OR</span>
            </div>
            
            <form id="emailLoginForm">
                <div class="form-group">
                    <label><i class="fas fa-envelope"></i> Email</label>
                    <input type="email" id="email" name="email" required>
                </div>
                
                <div class="form-group">
                    <label><i class="fas fa-lock"></i> Password</label>
                    <input type="password" id="password" name="password" required>
                </div>
                
                <button type="submit" class="btn" id="emailLoginBtn">
                    <i class="fas fa-sign-in-alt"></i>
                    <span>Login with Email</span>
                    <span class="loading"></span>
                </button>
            </form>
            
            <div class="form-footer">
                <p>Don't have an account? <a href="register.php">Sign Up</a></p>
                <p style="margin-top: 10px;"><a href="forgot-password.php">Forgot Password?</a></p>
            </div>
            
            <div class="back-home">
                <a href="/">
                    <i class="fas fa-arrow-left"></i> Back to Home
                </a>
            </div>
        </div>
    </div>

 <script type="module">
    import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
    import { getAuth, signInWithEmailAndPassword, signInWithPopup, GoogleAuthProvider, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";

    const firebaseConfig = {
        apiKey: "AIzaSyDgqpr976h-uGvfOCROX0V6cMaiWP1hOlc",
        authDomain: "login-signup-7cb63.firebaseapp.com",
        projectId: "login-signup-7cb63",
        storageBucket: "login-signup-7cb63.firebasestorage.app",
        messagingSenderId: "428131759010",
        appId: "1:428131759010:web:dcaed1cf0f280d885b78fb",
        measurementId: "G-8236JK3ZYL"
    };

    const app = initializeApp(firebaseConfig);
    const auth = getAuth(app);
    const googleProvider = new GoogleAuthProvider();

    const errorMsg = document.getElementById('errorMsg');
    const errorText = document.getElementById('errorText');
    const successMsg = document.getElementById('successMsg');
    const successText = document.getElementById('successText');

    // IMMEDIATELY sign out any existing session on login page load
    const currentUser = auth.currentUser;
    if (currentUser) {
        await signOut(auth);
    }

    function showError(message) {
        errorText.textContent = message;
        errorMsg.classList.add('active');
        successMsg.classList.remove('active');
        setTimeout(() => {
            errorMsg.classList.remove('active');
        }, 5000);
    }

    function showSuccess(message) {
        successText.textContent = message;
        successMsg.classList.add('active');
        errorMsg.classList.remove('active');
    }

    async function verifyWithBackend(user) {
        try {
            const idToken = await user.getIdToken();
            
            const response = await fetch('firebase_verify.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    idToken: idToken,
                    displayName: user.displayName || user.email.split('@')[0]
                })
            });

            const data = await response.json();
            
            if (data.success) {
                showSuccess('Login successful! Redirecting...');
                setTimeout(() => {
                    window.location.href = '/';
                }, 1000);
            } else {
                showError(data.message || 'Authentication failed');
            }
        } catch (error) {
            console.error('Verification error:', error);
            showError('Failed to verify authentication');
        }
    }

    // REMOVE onAuthStateChanged - no auto-login at all
    // This prevents automatic redirect after logout

    // Google Sign In
    document.getElementById('googleSignIn').addEventListener('click', async function() {
        const btn = this;
        const loading = btn.querySelector('.loading');
        
        btn.disabled = true;
        loading.classList.add('active');
        
        try {
            const result = await signInWithPopup(auth, googleProvider);
            await verifyWithBackend(result.user);
        } catch (error) {
            console.error('Google sign in error:', error);
            let errorMessage = 'Failed to sign in with Google';
            
            if (error.code === 'auth/popup-closed-by-user') {
                errorMessage = 'Sign in cancelled';
            } else if (error.code === 'auth/popup-blocked') {
                errorMessage = 'Popup was blocked. Please allow popups for this site.';
            }
            
            showError(errorMessage);
            btn.disabled = false;
            loading.classList.remove('active');
        }
    });

    // Email/Password Login
    document.getElementById('emailLoginForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const btn = document.getElementById('emailLoginBtn');
        const loading = btn.querySelector('.loading');
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        
        btn.disabled = true;
        loading.classList.add('active');
        
        try {
            const userCredential = await signInWithEmailAndPassword(auth, email, password);
            await verifyWithBackend(userCredential.user);
        } catch (error) {
            console.error('Email sign in error:', error);
            let errorMessage = 'Failed to sign in';
            
            if (error.code === 'auth/user-not-found') {
                errorMessage = 'No account found with this email';
            } else if (error.code === 'auth/wrong-password') {
                errorMessage = 'Incorrect password';
            } else if (error.code === 'auth/invalid-email') {
                errorMessage = 'Invalid email address';
            } else if (error.code === 'auth/too-many-requests') {
                errorMessage = 'Too many failed attempts. Please try again later.';
            } else if (error.code === 'auth/invalid-credential') {
                errorMessage = 'Invalid email or password';
            }
            
            showError(errorMessage);
            btn.disabled = false;
            loading.classList.remove('active');
        }
    });
</script>
</body>
</html>