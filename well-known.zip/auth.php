<?php
// auth.php - Authentication Functions (Firebase Compatible)
require_once 'config.php';

// Check if user is logged in (works with Firebase or legacy)
function isLoggedIn() {
    return isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true;
}

// Check if user is admin
function isAdmin() {
    return isLoggedIn() && isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

// Get current user info
function getCurrentUser() {
    if (!isLoggedIn()) {
        return null;
    }
    
    return [
        'id' => $_SESSION['user_id'] ?? null,
        'username' => $_SESSION['username'] ?? null,
        'email' => $_SESSION['email'] ?? null,
        'role' => $_SESSION['role'] ?? 'user',
        'full_name' => $_SESSION['full_name'] ?? '',
        'firebase_uid' => $_SESSION['firebase_uid'] ?? null
    ];
}

// Require login - redirect if not logged in
function requireLogin($redirectUrl = 'login.php') {
    if (!isLoggedIn()) {
        header('Location: ' . $redirectUrl);
        exit();
    }
}

// Require admin - redirect if not admin
function requireAdmin($redirectUrl = 'index.php') {
    if (!isAdmin()) {
        header('Location: ' . $redirectUrl);
        exit();
    }
}

// Check login via AJAX
function checkLoginAjax() {
    header('Content-Type: application/json');
    echo json_encode([
        'logged_in' => isLoggedIn(),
        'user' => getCurrentUser()
    ]);
    exit();
}

// Legacy function for backward compatibility
function loginUser($username, $password) {
    global $pdo;
    
    try {
        // Only allow login for users without Firebase UID (legacy users)
        $stmt = $pdo->prepare("SELECT * FROM users WHERE (username = ? OR email = ?) AND (firebase_uid IS NULL OR firebase_uid = '') LIMIT 1");
        $stmt->execute([$username, $username]);
        $user = $stmt->fetch();
        
        if (!$user) {
            return ['success' => false, 'message' => 'Please use Firebase login'];
        }
        
        if ($user['status'] !== 'active') {
            return ['success' => false, 'message' => 'Account is inactive'];
        }
        
        if (!password_verify($password, $user['password'])) {
            return ['success' => false, 'message' => 'Invalid credentials'];
        }
        
        // Update last login
        $stmt = $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
        $stmt->execute([$user['id']]);
        
        // Set session
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['full_name'] = $user['full_name'];
        $_SESSION['logged_in'] = true;
        
        return ['success' => true, 'message' => 'Login successful'];
        
    } catch(PDOException $e) {
        return ['success' => false, 'message' => 'Login failed: ' . $e->getMessage()];
    }
}

// Legacy logout function
function logoutUser() {
    session_unset();
    session_destroy();
    return ['success' => true, 'message' => 'Logged out successfully'];
}

// Legacy register function (deprecated - use Firebase signup instead)
function registerUser($username, $email, $password, $fullName = '') {
    return ['success' => false, 'message' => 'Please use Firebase signup'];
}
?>