<?php
/**
 * AUTOMATIC SITEMAP GENERATOR
 * This file includes automatic generation via cron job
 * Multiple setup methods included
 */

require_once 'config.php';

class AutoSitemapGenerator {
    private $pdo;
    private $baseUrl;
    private $urls = [];
    private $logFile;
    private $lockFile;
    
    public function __construct($pdo, $baseUrl) {
        $this->pdo = $pdo;
        $this->baseUrl = rtrim($baseUrl, '/');
        $this->logFile = __DIR__ . '/sitemap_generation.log';
        $this->lockFile = __DIR__ . '/sitemap.lock';
    }
    
    /**
     * Check if enough time has passed since last generation
     */
    private function shouldGenerate() {
        $xmlFile = __DIR__ . '/sitemap.xml';
        
        if (!file_exists($xmlFile)) {
            return true; // Generate if doesn't exist
        }
        
        $lastModified = filemtime($xmlFile);
        $minutesSince = (time() - $lastModified) / 60;
        
        return $minutesSince >= 10; // Generate if 10+ minutes old
    }
    
    /**
     * Acquire lock to prevent concurrent generation
     */
    private function acquireLock() {
        if (file_exists($this->lockFile)) {
            $lockAge = time() - filemtime($this->lockFile);
            if ($lockAge < 300) { // Lock expires after 5 minutes
                return false;
            }
        }
        
        file_put_contents($this->lockFile, getmypid());
        return true;
    }
    
    /**
     * Release lock
     */
    private function releaseLock() {
        if (file_exists($this->lockFile)) {
            unlink($this->lockFile);
        }
    }
    
    /**
     * Log message
     */
    private function log($message) {
        $timestamp = date('Y-m-d H:i:s');
        $logMessage = "[{$timestamp}] {$message}\n";
        file_put_contents($this->logFile, $logMessage, FILE_APPEND | LOCK_EX);
    }
    
    /**
     * Generate sitemap automatically
     */
    public function autoGenerate() {
        // Check if generation is needed
        if (!$this->shouldGenerate()) {
            $this->log("Skipped: Last generation was less than 10 minutes ago");
            return false;
        }
        
        // Try to acquire lock
        if (!$this->acquireLock()) {
            $this->log("Skipped: Another generation is in progress");
            return false;
        }
        
        try {
            $this->log("Starting automatic sitemap generation");
            
            // Collect URLs
            $this->collectURLs();
            $this->log("Collected " . count($this->urls) . " URLs");
            
            // Generate files
            $this->saveXML();
            $this->saveHTML();
            
            $this->log("Generated sitemap successfully (" . count($this->urls) . " URLs)");
            
            $this->releaseLock();
            return true;
            
        } catch (Exception $e) {
            $this->log("ERROR: " . $e->getMessage());
            $this->releaseLock();
            return false;
        }
    }
    
    /**
     * Manual generation (original functionality)
     */
    public function generate() {
        echo "Starting sitemap generation...\n";
        
        $this->collectURLs();
        echo "Collected " . count($this->urls) . " URLs\n";
        
        $this->saveXML();
        $this->saveHTML();
        
        echo "Done! Files created:\n";
        echo "- sitemap.xml (" . filesize(__DIR__ . '/sitemap.xml') . " bytes)\n";
        echo "- sitemap.html (" . filesize(__DIR__ . '/sitemap.html') . " bytes)\n";
        
        $this->log("Manual generation completed (" . count($this->urls) . " URLs)");
    }
    
    private function collectURLs() {
        $this->urls = [];
        
        // Homepage
        $this->addURL('/', '1.0', 'daily', date('Y-m-d'));
        
        // Static pages
        $this->addURL('/bookmarks.php', '0.8', 'weekly', date('Y-m-d'));
        $this->addURL('/search.php', '0.9', 'daily', date('Y-m-d'));
        $this->addURL('/login.php', '0.6', 'monthly', date('Y-m-d'));
        $this->addURL('/signup.php', '0.6', 'monthly', date('Y-m-d'));
        
        // Anime pages
        try {
            $stmt = $this->pdo->query("
                SELECT slug, title 
                FROM anime 
                WHERE slug IS NOT NULL AND slug != ''
                ORDER BY id DESC
            ");
            
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $this->addURL('/anime/' . $row['slug'], '0.8', 'weekly', date('Y-m-d'));
            }
            
        } catch (PDOException $e) {
            $this->log("ERROR fetching anime: " . $e->getMessage());
        }
        
        // Episode pages
        try {
            $stmt = $this->pdo->query("
                SELECT e.slug 
                FROM episodes e 
                JOIN anime a ON e.anime_id = a.id 
                WHERE e.slug IS NOT NULL AND e.slug != ''
                ORDER BY e.id DESC
            ");
            
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $this->addURL('/watch/' . $row['slug'], '0.7', 'monthly', date('Y-m-d'));
            }
            
        } catch (PDOException $e) {
            $this->log("ERROR fetching episodes: " . $e->getMessage());
        }
    }
    
    private function addURL($path, $priority, $changefreq, $lastmod) {
        $this->urls[] = [
            'loc' => $this->baseUrl . $path,
            'priority' => $priority,
            'changefreq' => $changefreq,
            'lastmod' => $lastmod
        ];
    }
    
    private function saveXML() {
        $xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        $xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
        
        foreach ($this->urls as $url) {
            $xml .= '  <url>' . "\n";
            $xml .= '    <loc>' . htmlspecialchars($url['loc'], ENT_XML1, 'UTF-8') . '</loc>' . "\n";
            $xml .= '    <lastmod>' . $url['lastmod'] . '</lastmod>' . "\n";
            $xml .= '    <changefreq>' . $url['changefreq'] . '</changefreq>' . "\n";
            $xml .= '    <priority>' . $url['priority'] . '</priority>' . "\n";
            $xml .= '  </url>' . "\n";
        }
        
        $xml .= '</urlset>';
        
        $xmlFile = __DIR__ . '/sitemap.xml';
        file_put_contents($xmlFile, $xml, LOCK_EX);
        chmod($xmlFile, 0644);
    }
    
    private function saveHTML() {
        $grouped = $this->groupURLs();
        
        $html = '<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sitemap - ' . htmlspecialchars(SITE_NAME) . '</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 40px 20px;
        }
        .container { max-width: 1200px; margin: 0 auto; }
        .header {
            background: white;
            padding: 40px;
            border-radius: 15px;
            text-align: center;
            margin-bottom: 30px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
        }
        .header h1 { font-size: 36px; color: #333; margin-bottom: 10px; }
        .header p { color: #666; font-size: 16px; }
        .stats {
            background: white;
            padding: 30px;
            border-radius: 15px;
            margin-bottom: 30px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            text-align: center;
        }
        .stat-item h3 { font-size: 32px; color: #667eea; margin-bottom: 5px; }
        .stat-item p { color: #666; font-size: 14px; }
        .section {
            background: white;
            padding: 30px;
            border-radius: 15px;
            margin-bottom: 25px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
        }
        .section h2 {
            font-size: 24px;
            color: #333;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #667eea;
        }
        .url-list { list-style: none; }
        .url-item {
            padding: 12px 0;
            border-bottom: 1px solid #f0f0f0;
        }
        .url-item:last-child { border-bottom: none; }
        .url-item a {
            color: #667eea;
            text-decoration: none;
            font-weight: 500;
        }
        .url-item a:hover { color: #764ba2; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🗺️ ' . htmlspecialchars(SITE_NAME) . ' Sitemap</h1>
            <p>Complete list of all pages • Auto-updated every 10 minutes</p>
        </div>
        
        <div class="stats">
            <div class="stat-item">
                <h3>' . count($this->urls) . '</h3>
                <p>Total Pages</p>
            </div>
            <div class="stat-item">
                <h3>' . count($grouped['Anime']) . '</h3>
                <p>Anime</p>
            </div>
            <div class="stat-item">
                <h3>' . count($grouped['Episodes']) . '</h3>
                <p>Episodes</p>
            </div>
            <div class="stat-item">
                <h3>' . date('M d, Y H:i') . '</h3>
                <p>Last Updated</p>
            </div>
        </div>';
        
        foreach ($grouped as $category => $items) {
            if (empty($items)) continue;
            
            $html .= '<div class="section">
                <h2>' . htmlspecialchars($category) . ' (' . count($items) . ')</h2>
                <ul class="url-list">';
            
            foreach (array_slice($items, 0, 100) as $item) {
                $title = $this->extractTitle($item['loc']);
                $html .= '<li class="url-item">
                    <a href="' . htmlspecialchars($item['loc']) . '">' . htmlspecialchars($title) . '</a>
                </li>';
            }
            
            if (count($items) > 100) {
                $html .= '<li class="url-item" style="color: #999;">... and ' . (count($items) - 100) . ' more</li>';
            }
            
            $html .= '</ul></div>';
        }
        
        $html .= '</div></body></html>';
        
        $htmlFile = __DIR__ . '/sitemap.html';
        file_put_contents($htmlFile, $html, LOCK_EX);
        chmod($htmlFile, 0644);
    }
    
    private function groupURLs() {
        $grouped = [
            'Main Pages' => [],
            'Anime' => [],
            'Episodes' => []
        ];
        
        foreach ($this->urls as $url) {
            if (strpos($url['loc'], '/anime/') !== false) {
                $grouped['Anime'][] = $url;
            } elseif (strpos($url['loc'], '/watch') !== false) {
                $grouped['Episodes'][] = $url;
            } else {
                $grouped['Main Pages'][] = $url;
            }
        }
        
        return $grouped;
    }
    
    private function extractTitle($url) {

    $path = parse_url($url, PHP_URL_PATH);
    $path = trim($path, '/');

    // Home
    if ($path === '') {
        return 'Home';
    }

    $parts = explode('/', $path);

    // /anime/slug
    if ($parts[0] === 'anime' && isset($parts[1])) {
        return ucwords(str_replace('-', ' ', $parts[1]));
    }

    // /watch/slug
    if ($parts[0] === 'watch' && isset($parts[1])) {
        return ucwords(str_replace('-', ' ', $parts[1]));
    }

    // /genre/name
    if ($parts[0] === 'genre' && isset($parts[1])) {
        return 'Genre: ' . ucwords(str_replace('-', ' ', $parts[1]));
    }

    // /sub-category/name
    if ($parts[0] === 'sub-category' && isset($parts[1])) {
        return 'Category: ' . ucwords(str_replace('-', ' ', $parts[1]));
    }

    // /az-list/A
    if ($parts[0] === 'az-list' && isset($parts[1])) {
        return 'A–Z: ' . strtoupper($parts[1]);
    }

    // Direct pages like /about, /contact
    return ucwords(str_replace('-', ' ', $parts[0]));
}

}
// ============================================================================
// EXECUTION LOGIC
// ============================================================================

$isCLI = (php_sapi_name() === 'cli');

try {
    $generator = new AutoSitemapGenerator($pdo, SITE_URL);
    
    // Check if this is an automatic trigger (via cron or ajax)
    if (isset($_GET['auto']) && $_GET['auto'] === 'true') {
        // Silent automatic generation
        header('Content-Type: application/json');
        $result = $generator->autoGenerate();
        echo json_encode([
            'success' => $result,
            'timestamp' => date('Y-m-d H:i:s')
        ]);
        exit;
    }
    
    // Manual execution
    if ($isCLI) {
        echo "\n=================================\n";
        echo "  AUTOMATIC SITEMAP GENERATOR\n";
        echo "=================================\n\n";
        $generator->generate();
        echo "\n✓ Success! Sitemap generated.\n\n";
    } else {
        $generator->generate();
        
        echo '<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="refresh" content="2;url=/sitemap.xml">
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .box {
            background: white;
            padding: 40px;
            border-radius: 15px;
            text-align: center;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
        }
        h1 { color: #333; margin-bottom: 20px; }
        p { color: #666; margin: 10px 0; }
        .success { color: #4caf50; font-size: 48px; margin-bottom: 20px; }
        .links { margin-top: 30px; }
        .links a {
            display: inline-block;
            margin: 0 10px;
            padding: 10px 20px;
            background: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 8px;
        }
    </style>
</head>
<body>
    <div class="box">
        <div class="success">✓</div>
        <h1>Sitemap Generated Successfully!</h1>
        <p><strong>Auto-generation enabled:</strong> Updates every 10 minutes</p>
        <p>Total URLs: ' . count($generator->urls ?? []) . '</p>
        <p>Redirecting to sitemap.xml in 2 seconds...</p>
        <div class="links">
            <a href="/sitemap.xml">View XML</a>
            <a href="/sitemap.html">View HTML</a>
            <a href="/sitemap_generator.php">Dashboard</a>
        </div>
    </div>
</body>
</html>';
    }
    
} catch (Exception $e) {
    if ($isCLI) {
        echo "\n✗ ERROR: " . $e->getMessage() . "\n\n";
    } else {
        echo "ERROR: " . $e->getMessage();
    }
}
?>